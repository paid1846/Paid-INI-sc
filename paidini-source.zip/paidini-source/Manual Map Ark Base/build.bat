@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

REM ============================================================================
REM  paidini - build both targets (restructured layout)
REM  DLL + injector both land in Ark base\Injector\Ark Base Loader\
REM  so the injector finds paidini.dll next to itself.
REM
REM  Incremental: each source compiles to its own .obj in build\bat_obj and is
REM  only recompiled when it (or a header it depends on) changes. The source
REM  list and dependency rules live in build_deps.ps1.
REM
REM  Usage: build.bat [rebuild]
REM    rebuild  - force full recompile of everything
REM ============================================================================

REM ---- Already inside a VS developer prompt? Skip the slow vcvarsall --------
if defined VSCMD_VER goto have_env

REM ---- Find vcvarsall --------------------------------------------------------
set VCVARS=
 
for /f "usebackq tokens=*" %%i in (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products * -requires Microsoft.VisualCpp.Tools.HostX64.TargetX64 -property installationPath 2^>nul`) do (
    if exist "%%i\VC\Auxiliary\Build\vcvarsall.bat" set VCVARS=%%i\VC\Auxiliary\Build\vcvarsall.bat
)

if not defined VCVARS (
    for %%p in (
        "%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat"
        "%ProgramFiles%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat"
        "%ProgramFiles%\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"
        "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvarsall.bat"
        "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvarsall.bat"
        "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"
    ) do ( if exist %%p set VCVARS=%%p )
)

if not defined VCVARS (
    echo [!] Visual Studio not found. Install VS 2019 or 2022 with C++ workload.
    pause & exit /b 1
)

call "%VCVARS%" x64 >nul 2>nul

:have_env

REM ---- Paths (new structure) -------------------------------------------------
set CLIENT=Ark base\Client
set LOADERDIR=Ark base\Injector\Ark Base Loader
set MINHOOK=Ark base\Minhook\minhook
set EU4SDK=!CLIENT!\EU4 SDK
REM ---- Past Owl menu framework (its ImGui 1.91.3 replaces Client\ImGui) ----
set PASTOWL=%~dp0..\Past owl menu 1
set FW=!PASTOWL!\framework
set IMGUI=!PASTOWL!\thirdparty\imgui
set FREETYPE=!PASTOWL!\thirdparty\freetype

if not exist "!IMGUI!\imgui.cpp" (
    echo [!] Missing Past Owl ImGui at !IMGUI! - check the PASTOWL path above
    pause & exit /b 1
)
if not exist "!MINHOOK!\include\MinHook.h" (
    echo [!] Missing MinHook at Ark base\Minhook\minhook
    pause & exit /b 1
)
if exist "!CLIENT!\Menu IMGUI" (
    echo [!] Duplicate "!CLIENT!\Menu IMGUI" still present - delete it, only ImGui is used
    pause & exit /b 1
)

set DLL_OUT=!LOADERDIR!\paidini.dll
set EXE_OUT=!LOADERDIR!\injector.exe
set OBJ=build\bat_obj
if not exist "!OBJ!" mkdir "!OBJ!"

set FORCE=
if /i "%~1"=="rebuild" set FORCE=-Force

REM ---- Work out which sources are stale --------------------------------------
set BD_STALE=
set BD_LINK=
for /f "usebackq tokens=1,2 delims==" %%a in (`powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "build_deps.ps1" -ObjDir "!OBJ!" -DllOut "!DLL_OUT!" !FORCE!`) do set BD_%%a=%%b
if not defined BD_STALE (
    echo [!] build_deps.ps1 failed - falling back to full rebuild
    powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "build_deps.ps1" -ObjDir "!OBJ!" -DllOut "!DLL_OUT!" -Force >nul
    set BD_STALE=all
    set BD_LINK=1
)

REM ---- Compile stale DLL sources ---------------------------------------------
REM  /MP = multiprocessor compile; /O2 = max speed; /fp:fast allows FP
REM  reassociation; /DWIN32_LEAN_AND_MEAN trims windows.h bloat on every TU.
REM  Pass EXTRA_OPT=/GL + EXTRA_LINK=/LTCG manually for a release squeeze
REM  (use "build.bat rebuild" after changing them).
REM  /Zc:threadSafeInit- : the DLL is manually mapped, so its TLS is never set
REM  up. Thread-safe "magic statics" check a TLS epoch and would silently skip
REM  constructing function-local statics (null std containers -> crashes).
if "!BD_STALE!"=="0" (
    echo [=] paidini.dll sources up-to-date
) else (
    echo [*] Compiling !BD_STALE! paidini.dll source^(s^)...
    REM Half the logical cores (min 1), so the PC stays usable while building.
    set /a BD_JOBS=%NUMBER_OF_PROCESSORS%/2
    if !BD_JOBS! LSS 1 set BD_JOBS=1
    cl /nologo /c /MP!BD_JOBS! /EHsc /O2 /fp:fast /MT /std:c++20 /Zc:threadSafeInit- /DNDEBUG /DWIN32_LEAN_AND_MEAN /DPASTOWL_INGAME %EXTRA_OPT% ^
       /I"!CLIENT!" /I"!CLIENT!\Client Manager" /I"!MINHOOK!\include" /I"!EU4SDK!" /I"!FW!" /I"!IMGUI!" /I"!IMGUI!\backends" /I"!FREETYPE!\include" ^
       /Fo"!OBJ!\\" @"!OBJ!\compile.rsp"
    if errorlevel 1 ( echo. & echo [!] DLL build FAILED. & goto cleanup )
)

REM ---- Link DLL --------------------------------------------------------------
if "!BD_LINK!"=="1" (
    echo [*] Linking paidini.dll...
    link /nologo /DLL /INCREMENTAL:NO /OPT:REF /OPT:ICF %EXTRA_LINK% /OUT:"!DLL_OUT!" ^
       @"!OBJ!\link.rsp" d3d11.lib dxgi.lib d3dcompiler.lib user32.lib gdi32.lib
    if errorlevel 1 ( echo. & echo [!] DLL link FAILED. & goto cleanup )
    del /q "!LOADERDIR!\paidini.exp" "!LOADERDIR!\paidini.lib" 2>nul
    echo [+] !DLL_OUT!
) else (
    echo [=] !DLL_OUT! up-to-date
)

REM ---- Build injector (CONSOLE = separate conhost window like Ghost) --------
set BUILD_EXE=1
if not defined FORCE if exist "!EXE_OUT!" (
    for /f "usebackq delims=" %%s in (`powershell -NoProfile -NonInteractive -Command "if ((Get-Item -LiteralPath '!LOADERDIR!\injector.cpp').LastWriteTimeUtc -le (Get-Item -LiteralPath '!EXE_OUT!').LastWriteTimeUtc) { 0 } else { 1 }"`) do set BUILD_EXE=%%s
)

if "!BUILD_EXE!"=="0" (
    echo [=] !EXE_OUT! up-to-date
) else (
    echo [*] Building injector.exe...
    cl /nologo /EHsc /O1 /Os /Gy /GS- /MD /DNDEBUG /W3 /Fo"!OBJ!\\" ^
       "!LOADERDIR!\injector.cpp" ^
       /link /INCREMENTAL:NO /OPT:REF /OPT:ICF /SUBSYSTEM:CONSOLE /OUT:"!EXE_OUT!" ^
       kernel32.lib ntdll.lib advapi32.lib user32.lib gdi32.lib
    if errorlevel 1 ( echo. & echo [!] Injector build FAILED. & goto cleanup )
    echo [+] !EXE_OUT!
)

echo.
echo [+] Done. DLL + exe are side-by-side in !LOADERDIR!

:cleanup
REM ---- Remove stray intermediates from older non-incremental builds ---------
del /q *.obj *.exp *.lib 2>nul

pause

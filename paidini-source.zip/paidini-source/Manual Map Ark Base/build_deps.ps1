﻿# Decides which DLL sources need recompiling. Called by build.bat.
# Writes <ObjDir>\compile.rsp (stale sources) and <ObjDir>\link.rsp (all objs),
# prints "STALE=<n>" and "LINK=<0|1>".
param([string]$ObjDir, [string]$DllOut, [switch]$Force)
$ErrorActionPreference = 'Stop'

$root   = $PSScriptRoot
$client = Join-Path $root 'Ark base\Client'
$mh     = Join-Path $root 'Ark base\Minhook\minhook'
$po     = (Join-Path $PSScriptRoot '..\Past owl menu 1')
$fw     = Join-Path $po 'framework'
$imgui  = Join-Path $po 'thirdparty\imgui'

function Newest([string[]]$paths, [string]$filter, [switch]$Recurse) {
    $t = [datetime]::MinValue
    foreach ($p in $paths) {
        foreach ($f in Get-ChildItem -LiteralPath $p -Filter $filter -File -Recurse:$Recurse) {
            if ($f.LastWriteTimeUtc -gt $t) { $t = $f.LastWriteTimeUtc }
        }
    }
    $t
}

# Flag/list changes invalidate everything.
$toolT   = @((Get-Item (Join-Path $root 'build.bat')).LastWriteTimeUtc, (Get-Item $PSCommandPath).LastWriteTimeUtc) | Measure-Object -Maximum | ForEach-Object Maximum
$imguiH  = Newest @($imgui, (Join-Path $imgui 'backends')) '*.h'
$fwH     = [datetime](@($imguiH, (Newest @($fw) '*.h' -Recurse)) | Measure-Object -Maximum).Maximum
$clientH = [datetime](@($fwH, (Newest @($client) '*.h' -Recurse)) | Measure-Object -Maximum).Maximum
$mhH     = Newest @($mh) '*.h' -Recurse

$groups = @(
    @{ Dep = $clientH; Src = @('DllMain.cpp', 'Logger\Logger.cpp', 'EU4 SDK\SDK.cpp') | ForEach-Object { Join-Path $client $_ } }
    @{ Dep = $imguiH;  Src = @('imgui.cpp', 'imgui_draw.cpp', 'imgui_tables.cpp', 'imgui_widgets.cpp', 'backends\imgui_impl_win32.cpp', 'backends\imgui_impl_dx11.cpp') | ForEach-Object { Join-Path $imgui $_ } }
    @{ Dep = $fwH;     Src = @('gui.cpp', 'data\fonts_data.cpp', 'data\embedded_images.cpp') +
        (@('blur', 'config', 'draw', 'fonts', 'stb_implementation', 'texture') | ForEach-Object { "helpers\$_.cpp" }) +
        (@('blackout', 'button', 'checkbox', 'child', 'colorpicker', 'config_button', 'config_field', 'config_info', 'curve',
           'draw_segment', 'dropdown', 'helpers', 'init_keybinds', 'keybind', 'notify', 'popup', 'search', 'seperator',
           'slider', 'subtab_section', 'tab_button', 'text_field', 'weapon_checkbox', 'weapon_info', 'window') | ForEach-Object { "widgets\$_.cpp" }) |
        ForEach-Object { Join-Path $fw $_ } }
    @{ Dep = $mhH;     Src = @('buffer.c', 'hook.c', 'trampoline.c', 'hde\hde64.c') | ForEach-Object { Join-Path $mh "src\$_" } }
)

$stale = @(); $objs = @(); $newestObj = [datetime]::MinValue
foreach ($g in $groups) {
    foreach ($s in $g.Src) {
        $sf  = Get-Item -LiteralPath $s
        $obj = Join-Path $ObjDir ($sf.BaseName + '.obj')
        $objs += $obj
        $need = $Force -or -not (Test-Path -LiteralPath $obj)
        if (-not $need) {
            $ot = (Get-Item -LiteralPath $obj).LastWriteTimeUtc
            $need = ($sf.LastWriteTimeUtc -gt $ot) -or ($g.Dep -gt $ot) -or ($toolT -gt $ot)
            if ($ot -gt $newestObj) { $newestObj = $ot }
        }
        if ($need) { $stale += $s }
    }
}

$dupes = $objs | Group-Object | Where-Object Count -gt 1
if ($dupes) { throw "Duplicate obj names: $($dupes.Name -join ', ')" }

Set-Content -LiteralPath (Join-Path $ObjDir 'compile.rsp') -Encoding ascii -Value ($stale | ForEach-Object { "`"$_`"" })
Set-Content -LiteralPath (Join-Path $ObjDir 'link.rsp')    -Encoding ascii -Value ($objs  | ForEach-Object { "`"$_`"" })

$link = $stale.Count -gt 0 -or -not (Test-Path -LiteralPath $DllOut) -or ($newestObj -gt (Get-Item -LiteralPath $DllOut).LastWriteTimeUtc)
"STALE=$($stale.Count)"
"LINK=$([int]$link)"

#pragma once
#include <Windows.h>
#include "MinHook.h"

// ============================================================================
//  HookLibrary - thin MinHook wrapper for the paidini base.
//  Returns false (instead of crashing or lying) when MinHook refuses.
// ============================================================================
class HookLibrary
{
public:
    static bool Hook(void* target, void* detour, void** orig)
    {
        if (!target || !detour || !orig) return false;
        if (MH_CreateHook(target, detour, orig) != MH_OK) return false;
        if (MH_EnableHook(target) != MH_OK)
        {
            MH_RemoveHook(target);
            return false;
        }
        return true;
    }

    static bool Unhook(void* target)
    {
        if (!target) return true;
        MH_DisableHook(target);
        return MH_RemoveHook(target) == MH_OK;
    }
};

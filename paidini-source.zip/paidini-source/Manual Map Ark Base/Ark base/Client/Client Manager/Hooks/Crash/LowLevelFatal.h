#pragma once
#include <Global.h>
#include <Hooks/Hook/HookBase.h>
#include <Hooks/Hook lib/HookLibrary.h>
#include <Modules/Notifications/Notifications.h>
#include <cstdarg>

// ============================================================================
// LowLevelFatal — swallow UE4's fatal-error path so the game does not die.
//
// FError::LowLevelFatal is the funnel every unrecoverable engine error goes
// through: a failed assertion, a missing/mismatched asset, a bad cook, a
// cross-map package collision. ARK ships with content from every map in the
// same package set, and joining or leaving a level can walk into a package
// that references something the current map never cooked. The engine notices,
// calls LowLevelFatal, and takes the process down with it.
//
// Returning from here instead of forwarding to the original means the engine
// keeps running past the complaint. This is not a repair — the object that
// tripped the assert is still wrong — but for a transient level-transition
// error the streaming pass that follows recreates the state anyway, so
// surviving the moment is the whole fix.
//
// WHY THIS WAS DOING NOTHING
//   pExecute = Memory->PatternScan(Signature)[0];
// PatternScan returns a std::vector, and indexing [0] on an EMPTY vector is
// undefined behaviour — it read garbage, handed the garbage to MinHook, and
// the hook quietly failed. Nothing logged, and HookManager::HookAll() discards
// the bool that Hook() returns, so a total failure looked identical to success.
// The hook was in the registry the whole time and had never once installed.
//
// Now: the scan result is checked, several candidate patterns are tried, and
// every outcome is logged. Whether this is armed is visible in debug.log on
// the very first line it prints.
// ============================================================================
class LowLevelFatal : public HookBase
{
public:
    // Tried in order, first match wins. The first is the exact prologue; the
    // rest are progressively shorter so a compiler/build change that shifts the
    // tail still resolves. Anything that matches more than one address is
    // rejected as ambiguous rather than guessed at.
    static inline const char* Signatures[] =
    {
        "4C 89 44 24 ? 4C 89 4C 24 ? 53 55 56 57 B8 ? ? ? ? E8 ? ? ? ? 48 2B E0 48 8B 05 ? ? ? ? 48 33 C4 48 89 84 24 ? ? ? ? 49 8B D8 48 8D AC 24 ? ? ? ? 8B F2",
        "4C 89 44 24 ? 4C 89 4C 24 ? 53 55 56 57 B8 ? ? ? ? E8 ? ? ? ? 48 2B E0 48 8B 05 ? ? ? ? 48 33 C4 48 89 84 24 ? ? ? ? 49 8B D8",
        "4C 89 44 24 ? 4C 89 4C 24 ? 53 55 56 57 B8 ? ? ? ? E8 ? ? ? ? 48 2B E0",
    };

    static inline void* pExecute = nullptr;
    static inline bool  Armed    = false;
    static inline int   Swallowed = 0;

    static inline void (*oExecute)(const char* File, int Line, const wchar_t* Format, ...) = 0;

    static void Execute(const char* File, int Line, const wchar_t* Format, ...)
    {
        Swallowed++;

        // Report WHAT was swallowed. A bare "crash avoided" told us nothing about
        // which asset or assert tripped, and that is exactly the information
        // needed to tell a harmless transition warning from a real problem.
        // Bounded, and never forwards to the original.
        wchar_t msg[512] = {};
        if (Format)
        {
            va_list args;
            va_start(args, Format);
            const int n = _vsnwprintf_s(msg, _countof(msg), _countof(msg) - 1, Format, args);
            va_end(args);
            if (n < 0) msg[0] = L'\0';
        }

        char narrow[512] = {};
        if (msg[0])
        {
            const int n = WideCharToMultiByte(CP_UTF8, 0, msg, -1, narrow, sizeof(narrow) - 1, nullptr, nullptr);
            if (n <= 0) narrow[0] = '\0';
        }

        LOG("NATIVE GAME CRASH AVOIDED (#%d) at %s:%d - %s",
            Swallowed,
            (File && !MemBadPtr((void*)File, 1)) ? File : "?",
            Line,
            narrow[0] ? narrow : "(no message)");

        // On-screen flag, bottom-left: short toast, details stay in debug.log.
        // Truncated so one pathological assert can't stretch across the screen.
        std::string why = narrow[0] ? narrow : "(no message)";
        if (why.size() > 80) why.resize(80);
        Notifications::Push("Crash avoided (#" + std::to_string(Swallowed) + ") - " + why);
        return;
    }

    bool Hook() override
    {
        if (!Memory)
        {
            LOG("LowLevelFatal: NOT ARMED - MemoryManager unavailable");
            return false;
        }

        int used = -1;
        for (int i = 0; i < (int)_countof(Signatures); i++)
        {
            // Ask for a few results so an ambiguous pattern can be detected
            // instead of silently binding to whichever address came first.
            auto r = Memory->PatternScan(Signatures[i], 4);
            if (r.empty())
            {
                LOG("LowLevelFatal: signature %d no match", i);
                continue;
            }
            if (r.size() > 1)
            {
                LOG("LowLevelFatal: signature %d ambiguous (%zu matches) - skipping", i, r.size());
                continue;
            }
            pExecute = r[0];
            used = i;
            break;
        }

        if (!pExecute)
        {
            LOG("LowLevelFatal: NOT ARMED - no signature matched. Engine fatal errors will still kill the game.");
            return false;
        }

        if (!HookLibrary::Hook(pExecute, Execute, reinterpret_cast<LPVOID*>(&oExecute)))
        {
            LOG("LowLevelFatal: NOT ARMED - MinHook refused target %p (signature %d)", pExecute, used);
            pExecute = nullptr;
            return false;
        }

        Armed = true;
        LOG("LowLevelFatal: ARMED via signature %d at %p - engine fatal errors will be swallowed", used, pExecute);
        return true;
    }

    bool Unhook() override
    {
        if (!pExecute) return true;   // never armed → nothing to undo
        const bool ok = HookLibrary::Unhook(pExecute);
        LOG("LowLevelFatal: unhook %s (swallowed %d fatal error(s) this session)",
            ok ? "ok" : "FAILED", Swallowed);
        pExecute = nullptr;
        Armed = false;
        return ok;
    }
};

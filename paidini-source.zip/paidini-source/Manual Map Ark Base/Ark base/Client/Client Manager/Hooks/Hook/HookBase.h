#pragma once
#include <Manager/MemoryManager.h>

// ============================================================================
//  HookBase - minimal hook interface for the paidini base.
//  A hook owns one target: Hook() installs, Unhook() removes. Both report
//  success so callers (and the log) can tell armed from dead.
// ============================================================================
class HookBase
{
public:
    virtual ~HookBase() = default;
    virtual bool Hook()   = 0;
    virtual bool Unhook() = 0;
};

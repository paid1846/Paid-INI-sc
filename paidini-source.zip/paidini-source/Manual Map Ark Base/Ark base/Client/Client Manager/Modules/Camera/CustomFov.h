#pragma once
#include <Global.h>

// ============================================================================
//  Custom FOV - pins the local PlayerCameraManager's FOV to the menu value.
//  While the player is aiming (targeting) the lock is released so scopes /
//  spyglass zoom still work. Offsets verified against the Store build.
// ============================================================================

namespace CustomFov
{
    constexpr uintptr_t kDefaultFOV   = 0x498;   // APlayerCameraManager::DefaultFOV
    constexpr uintptr_t kLockedFOV    = 0x49C;   // APlayerCameraManager::LockedFOV
    constexpr uintptr_t kCurrentFOV   = 0x518;   // camera cache POV.FOV
    constexpr uintptr_t kLockFlags    = 0x1480;  // bit 0 = FOV locked
    constexpr uintptr_t kTargetFlags  = 0x1260;  // AShooterCharacter bit 0 = bIsTargeting

    inline APlayerCameraManager* s_cam      = nullptr;
    inline float                 s_origFov  = 0.f;
    inline bool                  s_active   = false;

    template <typename T> inline T& At(void* base, uintptr_t off)
    {
        return *reinterpret_cast<T*>(reinterpret_cast<uint8_t*>(base) + off);
    }

    inline void Release()
    {
        if (s_active && s_cam)
        {
            At<float>(s_cam, kDefaultFOV) = s_origFov;
            At<float>(s_cam, kLockedFOV)  = 0.f;
            At<uint8_t>(s_cam, kLockFlags) &= ~1;
        }
        s_active = false;
        s_cam    = nullptr;
    }

    // Call every frame from the game thread; wrap in SEH (reads live game objects).
    inline void Apply()
    {
        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        APlayerCameraManager* cam = pc ? pc->PlayerCameraManager : nullptr;

        if (!Settings::Ini::CustomFOV || !cam)
        {
            if (cam == s_cam) Release();
            else { s_active = false; s_cam = nullptr; }
            return;
        }

        if (!s_active || cam != s_cam)
        {
            s_cam     = cam;
            s_origFov = At<float>(cam, kDefaultFOV);
            s_active  = true;
        }

        const bool targeting = pc->AcknowledgedPawn &&
            (At<uint8_t>(pc->AcknowledgedPawn, kTargetFlags) & 1);
        if (targeting)
        {
            At<uint8_t>(cam, kLockFlags) &= ~1;
            return;
        }

        const float fov = Settings::Ini::FOVValue;
        if (At<float>(cam, kDefaultFOV) != fov) At<float>(cam, kDefaultFOV) = fov;
        if (At<float>(cam, kLockedFOV)  != fov) At<float>(cam, kLockedFOV)  = fov;
        if (At<float>(cam, kCurrentFOV) != fov) At<float>(cam, kCurrentFOV) = fov;
        if (!(At<uint8_t>(cam, kLockFlags) & 1)) At<uint8_t>(cam, kLockFlags) |= 1;
    }
}

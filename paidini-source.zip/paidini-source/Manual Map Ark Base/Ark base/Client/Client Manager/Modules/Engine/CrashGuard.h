#pragma once
// ============================================================================
// CrashGuard - keeps ARK's own UI bugs from closing the game, and records any
// crash precisely enough to patch it from debug.log alone.
//
// 1. UI GUARD
//    Every crash dump on this machine that is ARK's fault (not an injected
//    DLL's) is the same family: a UMG widget still pointing at something that
//    has gone - an inventory entry whose item was just moved (tooltip /
//    DataListPanel refresh, ShooterGame+0x2E95F0, 28 + 30 Sep) or a list entry
//    no longer in the window (ClickedSecondaryButton -> empty widget path,
//    ShooterGame+0x1951EB7, 1 + 3 Oct). Both arrive through ProcessEvent, which
//    we already hook. Every ProcessEvent whose function belongs to a widget
//    class (anything deriving from UMG's Visual / Widget / UserWidget) runs
//    under SEH: an access violation drops that one UI action and the game
//    carries on. Nested calls are each guarded, so the innermost widget call
//    is what gets dropped. Gameplay, network and engine functions are NOT
//    wrapped - only UI, where an abandoned call leaves nothing half-done.
//
// 2. CRASH LOG
//    A vectored exception handler sees every hard fault first (access
//    violation, illegal instruction, divide by zero, stack-buffer overrun,
//    heap corruption) and writes one line per unique crash site to debug.log:
//    the module + offset, read/write address, the UFunction ProcessEvent was
//    running on that thread (class.function), and the ShooterGame return
//    addresses on the stack. It never handles anything - it only records - so
//    behaviour is unchanged. It allocates no memory (a crash inside the heap
//    must not deadlock in the logger): names come straight out of GNames,
//    text is formatted on the stack and written with WriteFile.
//
// Both are switched off on eject.
// ============================================================================
#include <Windows.h>
#include <cstdio>
#include <cstring>
#include <unordered_map>
#include <Global.h>
#include "Logger/Logger.h"

namespace CrashGuard
{
    inline bool Valid(const void* p) { const uintptr_t v = reinterpret_cast<uintptr_t>(p); return v > 0x10000 && v < 0x7FFFFFFFFFFF; }

    // ---- heap-free object names --------------------------------------------------------
    // GNames: global -> chunk table -> 16384 entry pointers per chunk; an entry
    // is int32 index (bit 0 = wide), pad, hash next, then the ANSI name.
    inline const char* NameOf(const void* obj)
    {
        if (!Valid(obj) || !FName::GNames) return "?";
        const int32_t idx = *reinterpret_cast<const int32_t*>(reinterpret_cast<uintptr_t>(obj) + 0x18);
        if (idx < 0 || idx >= 128 * 16384) return "?";
        const uintptr_t table = *reinterpret_cast<const uintptr_t*>(FName::GNames);
        if (table < 0x10000) return "?";
        const uintptr_t chunk = reinterpret_cast<const uintptr_t*>(table)[idx / 16384];
        if (chunk < 0x10000) return "?";
        const uintptr_t e = reinterpret_cast<const uintptr_t*>(chunk)[idx % 16384];
        if (e < 0x10000 || (*reinterpret_cast<const int32_t*>(e) & 1)) return "?";
        return reinterpret_cast<const char*>(e + 0x10);
    }

    // ---- 1. UI guard -------------------------------------------------------------------
    inline SRWLOCK g_lock = SRWLOCK_INIT;
    inline std::unordered_map<const void*, bool> g_isUi;
    inline volatile LONG g_caught = 0;

    inline bool ComputeIsUi(const UFunction* fn)
    {
        const UObject* owner = reinterpret_cast<const UObject*>(fn)->Outer;
        if (!Valid(owner)) return false;
        int depth = 0;
        for (const UStruct* s = reinterpret_cast<const UStruct*>(owner); Valid(s) && depth < 32; s = s->SuperField, depth++)
        {
            const char* n = NameOf(s);
            if (!strcmp(n, "UserWidget") || !strcmp(n, "Widget") || !strcmp(n, "Visual")) return true;
        }
        return false;
    }

    inline bool IsUiFunction(const UFunction* fn)
    {
        if (!Valid(fn)) return false;
        AcquireSRWLockShared(&g_lock);
        auto it = g_isUi.find(fn);
        const bool known = it != g_isUi.end();
        const bool v = known && it->second;
        ReleaseSRWLockShared(&g_lock);
        if (known) return v;
        bool ui = false;
        __try { ui = ComputeIsUi(fn); }
        __except (EXCEPTION_EXECUTE_HANDLER) { ui = false; }
        AcquireSRWLockExclusive(&g_lock);
        if (g_isUi.size() < 200000) g_isUi.emplace(fn, ui);
        ReleaseSRWLockExclusive(&g_lock);
        return ui;
    }

    // ---- 2. crash log ------------------------------------------------------------------
    inline char      g_logPath[MAX_PATH] = {};
    inline uintptr_t g_sgBase = 0, g_sgEnd = 0;
    inline PVOID     g_veh = nullptr;
    inline volatile LONG g_logged = 0;
    inline uintptr_t g_seen[64] = {};
    inline volatile LONG g_seenN = 0;

    // The function ProcessEvent is running, per thread (set by the hook).
    inline volatile DWORD     g_peThread = 0;
    inline const void* volatile g_peFn = nullptr;
    inline const void* volatile g_peObj = nullptr;

    inline void RawLog(const char* text)
    {
        if (!g_logPath[0]) return;
        HANDLE h = CreateFileA(g_logPath, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (h == INVALID_HANDLE_VALUE) return;
        SYSTEMTIME st; GetLocalTime(&st);
        char line[1400];
        const int n = sprintf_s(line, "[%02d:%02d:%02d] %s\r\n", st.wHour, st.wMinute, st.wSecond, text);
        DWORD w = 0;
        if (n > 0) WriteFile(h, line, (DWORD)n, &w, nullptr);
        CloseHandle(h);
    }

    inline void Where(uintptr_t a, char* out, size_t cap)
    {
        if (a >= g_sgBase && a < g_sgEnd) { sprintf_s(out, cap, "ShooterGame+0x%llX", (unsigned long long)(a - g_sgBase)); return; }
        HMODULE m = nullptr;
        char name[MAX_PATH] = {};
        if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, reinterpret_cast<LPCSTR>(a), &m) && m &&
            GetModuleFileNameA(m, name, MAX_PATH))
        {
            const char* base = strrchr(name, '\\'); base = base ? base + 1 : name;
            sprintf_s(out, cap, "%s+0x%llX", base, (unsigned long long)(a - reinterpret_cast<uintptr_t>(m)));
            return;
        }
        sprintf_s(out, cap, "0x%llX (no module - injected code)", (unsigned long long)a);
    }

    inline LONG CALLBACK Handler(PEXCEPTION_POINTERS ep)
    {
        const DWORD code = ep->ExceptionRecord->ExceptionCode;
        if (code != EXCEPTION_ACCESS_VIOLATION && code != EXCEPTION_ILLEGAL_INSTRUCTION && code != EXCEPTION_INT_DIVIDE_BY_ZERO &&
            code != 0xC0000409 /*stack buffer overrun*/ && code != 0xC0000374 /*heap corruption*/ && code != EXCEPTION_PRIV_INSTRUCTION)
            return EXCEPTION_CONTINUE_SEARCH;
        const uintptr_t rip = ep->ContextRecord->Rip;
        if (g_logged >= 40) return EXCEPTION_CONTINUE_SEARCH;
        // one line per crash site
        for (LONG i = 0; i < g_seenN && i < 64; i++) if (g_seen[i] == rip) return EXCEPTION_CONTINUE_SEARCH;
        const LONG slot = InterlockedIncrement(&g_seenN) - 1;
        if (slot < 64) g_seen[slot] = rip;
        InterlockedIncrement(&g_logged);

        __try
        {
            char where[300], line[1300];
            Where(rip, where, sizeof(where));
            const char* acc = "";
            char accBuf[64] = {};
            if (code == EXCEPTION_ACCESS_VIOLATION && ep->ExceptionRecord->NumberParameters >= 2)
            {
                const ULONG_PTR kind = ep->ExceptionRecord->ExceptionInformation[0], addr = ep->ExceptionRecord->ExceptionInformation[1];
                sprintf_s(accBuf, "%s 0x%llX", kind == 0 ? "read" : kind == 1 ? "write" : "execute", (unsigned long long)addr);
                acc = accBuf;
            }
            char pe[200] = "-";
            if (g_peThread == GetCurrentThreadId() && g_peFn)
            {
                const UObject* fn = reinterpret_cast<const UObject*>(g_peFn);
                sprintf_s(pe, "%s.%s on %s", NameOf(fn->Outer), NameOf(fn), NameOf(g_peObj ? reinterpret_cast<const UObject*>(g_peObj)->Class : nullptr));
            }
            sprintf_s(line, "[CrashLog] code 0x%08lX at %s %s | ProcessEvent: %s | thread %lu", code, where, acc, pe, GetCurrentThreadId());
            RawLog(line);

            // ShooterGame / module return addresses on the stack
            char stk[900] = "[CrashLog]   stack:";
            size_t len = strlen(stk);
            const uintptr_t* sp = reinterpret_cast<const uintptr_t*>(ep->ContextRecord->Rsp);
            int found = 0;
            for (int i = 0; i < 512 && found < 12; i++)
            {
                const uintptr_t v = sp[i];
                if (v >= g_sgBase && v < g_sgEnd)
                {
                    len += sprintf_s(stk + len, sizeof(stk) - len, " SG+0x%llX", (unsigned long long)(v - g_sgBase));
                    found++;
                }
            }
            RawLog(stk);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        return EXCEPTION_CONTINUE_SEARCH;
    }

    inline void Install()
    {
        if (g_veh) return;
        HMODULE sg = GetModuleHandleW(nullptr);
        g_sgBase = reinterpret_cast<uintptr_t>(sg);
        const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(sg);
        const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS64*>(g_sgBase + dos->e_lfanew);
        g_sgEnd = g_sgBase + nt->OptionalHeader.SizeOfImage;
        const std::string path = Logger::GetLogFolder() + "debug.log";
        strncpy_s(g_logPath, path.c_str(), _TRUNCATE);
        g_veh = AddVectoredExceptionHandler(1, Handler);
        Logger::Log("[CrashGuard] armed: UI functions run guarded, crash sites go to this log (ShooterGame %p-%p)",
                    reinterpret_cast<void*>(g_sgBase), reinterpret_cast<void*>(g_sgEnd));
    }

    inline void Uninstall()
    {
        if (g_veh) { RemoveVectoredExceptionHandler(g_veh); g_veh = nullptr; }
        if (g_caught) Logger::Log("[CrashGuard] UI faults caught this session: %ld", (long)g_caught);
    }
}

#pragma once
#include <Windows.h>
#include <string>
#include <vector>
// framework ImGui (1.91.3) via include dirs, NOT Client/ImGui
#include "imgui.h"

// ============================================================================
//  Notifications - bottom-left toast queue for the paidini base.
//
//  Thread-safe: Push() may be called from any thread (e.g. the crash guard
//  fires on whatever game thread tripped the fatal). Draw() must be called
//  once per frame from the Present hook. Toasts live 5s, fade over the last
//  1s, stack upward from the bottom-left corner. Capped at 5 — oldest drops.
// ============================================================================
namespace Notifications
{
    struct Toast
    {
        std::string text;
        ImU32       color   = IM_COL32(80, 255, 80, 255);
        float       born    = 0.f;   // Now() at push
    };

    inline SRWLOCK s_lock = SRWLOCK_INIT;
    inline std::vector<Toast> s_toasts;

    // Wall clock, not ImGui::GetTime(): the overlay skips ImGui frames while
    // the menu is closed and idle, and ImGui's clock stops with them.
    inline float Now() { return (float)(GetTickCount64() % 100000000ull) / 1000.f; }

    inline bool Any()
    {
        AcquireSRWLockShared(&s_lock);
        const bool any = !s_toasts.empty();
        ReleaseSRWLockShared(&s_lock);
        return any;
    }

    inline void Push(const std::string& text, ImU32 color = IM_COL32(80, 255, 80, 255))
    {
        Toast t;
        t.text  = text;
        t.color = color;
        t.born  = Now();

        AcquireSRWLockExclusive(&s_lock);
        s_toasts.push_back(std::move(t));
        while (s_toasts.size() > 5)
            s_toasts.erase(s_toasts.begin());
        ReleaseSRWLockExclusive(&s_lock);
    }

    inline void Clear()
    {
        AcquireSRWLockExclusive(&s_lock);
        s_toasts.clear();
        ReleaseSRWLockExclusive(&s_lock);
    }

    // Copy under lock, draw without it — never holds the lock across ImGui.
    inline void Draw()
    {
        AcquireSRWLockShared(&s_lock);
        std::vector<Toast> copy = s_toasts;
        ReleaseSRWLockShared(&s_lock);
        if (copy.empty()) return;

        constexpr float kLife = 5.f;
        constexpr float kFade = 1.f;
        const float now = Now();

        bool expired = false;
        ImDrawList* dl = ImGui::GetForegroundDrawList();
        const ImVec2 pad(10.f, 10.f);
        float y = ImGui::GetIO().DisplaySize.y - pad.y;

        // Oldest at the bottom, newest stacked above it.
        for (size_t i = 0; i < copy.size(); i++)
        {
            const Toast& t = copy[i];
            const float age = now - t.born;
            if (age >= kLife) { expired = true; continue; }

            float alpha = 1.f;
            if (age > kLife - kFade)
                alpha = (kLife - age) / kFade;

            const ImVec2 ts = ImGui::CalcTextSize(t.text.c_str());
            y -= ts.y + 6.f;

            const ImU32 bg = IM_COL32(10, 10, 10, (int)(200 * alpha));
            dl->AddRectFilled(ImVec2(pad.x - 4.f, y - 3.f),
                              ImVec2(pad.x + ts.x + 4.f, y + ts.y + 3.f), bg, 3.f);

            const ImU32 fg = (t.color & 0x00FFFFFF) | ((ImU32)(255 * alpha) << 24);
            const ImU32 sh = IM_COL32(0, 0, 0, (int)(255 * alpha));
            const ImVec2 pos(pad.x, y);
            dl->AddText(ImVec2(pos.x + 1.f, pos.y + 1.f), sh, t.text.c_str());
            dl->AddText(pos, fg, t.text.c_str());
        }

        // Lazily prune expired toasts so the queue doesn't grow stale.
        if (expired)
        {
            AcquireSRWLockExclusive(&s_lock);
            for (size_t i = 0; i < s_toasts.size();)
            {
                if (now - s_toasts[i].born >= kLife)
                    s_toasts.erase(s_toasts.begin() + i);
                else
                    i++;
            }
            ReleaseSRWLockExclusive(&s_lock);
        }
    }
}

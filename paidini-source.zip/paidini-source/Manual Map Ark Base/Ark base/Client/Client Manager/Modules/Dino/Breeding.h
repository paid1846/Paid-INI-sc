#pragma once
// ============================================================================
// Breeding - the Dino tab's breeding features, on one scan of the level:
//
//   Auto Saddle              saddles your tribe's grown, unsaddled dinos
//   Auto Imprint             does a baby's imprint care the moment it is due
//   Auto Name                names your tribe's unnamed dinos
//   Auto Claim               claims unclaimed dinos (fresh babies)
//   Auto Neuter              neuters / spays your tribe's dinos
//   Auto Level               levels each dino's stats to the points you set
//   Auto Clone               clones the nearest dino at a cloning chamber
//   Auto Fill Cloning Chamber  puts your element shards into the chamber
//   Auto Pickup Eggs         picks up fertilized eggs on the ground
//   Auto Transfer Eggs       puts your fertilized eggs into an incubator
//   Auto Hatch Eggs          hatches the eggs in your incubators
//
// Ported from ArkHoles (Modules/Exploits/Breeding.h). Every offset below was
// re-read through reflection on the live Store build (v962.2) and matches.
//
// MULTI-USE is AShooterPlayerController::ServerMultiUse(ForObject, UseIndex):
//   122    Claim            - on a dino whose TargetingTeam is 2000000000
//   139    Baby cuddle      - imprint care. PET: just this. FOOD: the food the
//                             baby wants (BabyCuddleFood) must be in hotbar
//                             slot 9 first (ServerAddItemToSlot). WALK: no use
//                             index does it; you walk the baby.
//   77391  Neuter / spay
//   100    Pick up          - on a dropped fertilized egg
// The server drops a multi-use within 0.35 s of the last, so they are queued
// and sent one per 0.45 s, longest-waiting target first.
//
// RENAME is ServerNotifyEditText with the dino's DinoID1/2. LEVEL is
// ServerRequestLevelUp(status component, stat); a point counts once the dino's
// ExtraCharacterLevel actually rises. SADDLE is open inventory, transfer with
// equip, then ServerEquipToRemoteInventory with the id it gets inside.
// EGGS / SHARDS go into an EggIncubator_C / TekCloningChamber_C with
// ServerTransferToRemoteInventory.
//
// CLONE is ServerProcessNetExecCommand(chamber, "Clone", params with the dino
// in ObjParam1). HATCH is learned: the first hatch you do by hand (net exec or
// multi-use on the incubator) is caught in the ProcessEvent pre-hook and sent
// again from then on.
//
// Differences from the source: UFunctions / names come from EngineRefs (no
// FindObject / FindClass / FName(string) scans at runtime), the dino check
// walks the class chain, positions come from the root's Bounds (+0x118), and
// the outbound catch and the name-box swallow run in our ProcessEvent hook.
//
// THREADING: Tick on the game thread, from DrawHUD; OnPreEvent from the
// ProcessEvent hook (game thread).
// ============================================================================
#include <Global.h>
#include <CheatSettings.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <cstring>
#include <cmath>
#include <algorithm>
#include "Client Manager/Modules/Engine/EngineRefs.h"

class Breeding
{
private:
    // ---- offsets (verified live) ---------------------------------------------
    static constexpr uintptr_t OFF_ROOT           = 0x0268;   // AActor::RootComponent
    static constexpr uintptr_t OFF_BOUNDS_ORIGIN  = 0x0118;   // USceneComponent::Bounds
    static constexpr uintptr_t OFF_BOUNDS_EXTENT  = 0x0124;
    static constexpr uintptr_t OFF_TEAM           = 0x0230;   // AActor::TargetingTeam
    static constexpr uintptr_t OFF_CHAR_MESH      = 0x0510;   // ACharacter::Mesh
    static constexpr uintptr_t OFF_CHAR_INV       = 0x0D20;   // APrimalCharacter::MyInventoryComponent
    static constexpr uintptr_t OFF_STATUS_COMP    = 0x0D10;   // MyCharacterStatusComponent
    static constexpr uintptr_t OFF_EXTRA_LEVEL    = 0x06D0;   // status ExtraCharacterLevel (uint16)
    static constexpr uintptr_t OFF_CONT_INV       = 0x0AF8;   // PrimalStructureItemContainer::MyInventoryComponent
    static constexpr uintptr_t OFF_INV_ITEMS      = 0x0118;
    static constexpr uintptr_t OFF_INV_EQUIPPED   = 0x0128;
    static constexpr uintptr_t OFF_INV_ACCESS     = 0x0498;   // MaxInventoryAccessDistance
    static constexpr uintptr_t OFF_ITEM_FLAGS53   = 0x0053;
    static constexpr uint8_t   BIT_NOT_REAL       = 0x02 | 0x10;
    static constexpr uintptr_t OFF_ITEM_EQUIPTYPE = 0x0172;   // MyEquipmentType
    static constexpr uint8_t   kEquipSaddle       = 5;
    static constexpr uintptr_t OFF_ITEM_OWNERS    = 0x0088;   // EquipRequiresExplicitOwnerClasses
    static constexpr uintptr_t OFF_ITEM_OWNER_TAGS = 0x0098;  // EquipRequiresExplicitOwnerTags
    static constexpr uintptr_t OFF_ACTOR_CUSTOMTAG = 0x01B8;
    static constexpr uintptr_t OFF_ITEM_ID        = 0x0210;
    static constexpr uintptr_t OFF_ITEM_QTY       = 0x05F8;
    static constexpr uintptr_t OFF_DINO_SADDLE    = 0x13B0;   // SaddleItemClass
    static constexpr uintptr_t OFF_SADDLE_ITEMID  = 0x1BD8 + 0x10;   // SaddleStruct.ItemId
    static constexpr uintptr_t OFF_DINO_NAME      = 0x12E0;   // TamedName
    static constexpr uintptr_t OFF_DINO_BABYFLAGS = 0x1504;   // bIsBaby
    static constexpr uint8_t   BIT_IS_BABY        = 0x40;
    static constexpr uintptr_t OFF_DINO_ID1       = 0x1820;
    static constexpr uintptr_t OFF_DINO_ID2       = 0x1824;
    static constexpr uintptr_t OFF_CUDDLE_TIME    = 0x1E88;   // BabyNextCuddleTime
    static constexpr uintptr_t OFF_CUDDLE_TYPE    = 0x1E90;   // 0 pet, 1 food, 2 walk
    static constexpr uintptr_t OFF_CUDDLE_FOOD    = 0x1E98;
    static constexpr uintptr_t OFF_NEUTERED       = 0x1EDB;
    static constexpr uint8_t   BIT_NEUTERED       = 0x02;
    static constexpr uintptr_t OFF_PREVENT_NEUTER = 0x1EF3;
    static constexpr uint8_t   BIT_PREVENT_NEUTER = 0x02;
    static constexpr uintptr_t OFF_NETWORK_TIME   = 0x0598;   // AShooterGameState
    static constexpr uintptr_t OFF_CHAMBER_BUSY   = 0x0E9C;   // bIsCloning
    static constexpr uintptr_t OFF_CHAMBER_RANGE  = 0x0EC8;   // CloningSearchRange
    static constexpr uintptr_t OFF_CHAMBER_SHARDS = 0x0EBC;   // ReplicatedShards

    static constexpr int32_t kUnclaimedTeam = 2000000000;

    static constexpr int32_t kUseClaim  = 122;
    static constexpr int32_t kUseCuddle = 139;
    static constexpr int32_t kUseNeuter = 77391;
    static constexpr int32_t kUsePickup = 100;
    static constexpr int32_t kCuddleSlot = 9;

    static constexpr const char* kShardClass = "PrimalItemResource_ElementShard_C";

    // ---- tuning ------------------------------------------------------------
    static constexpr uint64_t kScanMs         = 250;
    static constexpr float    kScanCm         = 6000.f;
    static constexpr float    kUseReachCm     = 360.f;    // server: half-extent + 360 cm
    static constexpr float    kUseMarginCm    = 40.f;
    static constexpr uint64_t kMultiUseGapMs  = 450;      // server: one per 0.35 s
    static constexpr float    kPickupRangeCm  = 320.f;
    static constexpr uint64_t kLevelWaitMs    = 1500;
    static constexpr uint64_t kRetryMs        = 2000;
    static constexpr uint64_t kResendMs       = 500;
    static constexpr uint64_t kStationGapMs   = 1000;
    static constexpr uint64_t kSaddleRetryMs  = 300;
    static constexpr uint64_t kStatusMs       = 5000;
    static constexpr float    kRangeMarginCm  = 30.f;
    static constexpr float    kDefaultRangeCm = 300.f;
    static constexpr float    kMinSaneRangeCm = 50.f;
    static constexpr float    kMaxSaneRangeCm = 5000.f;

public:
    static constexpr int kLevelStats = 8;
    static constexpr const char* kLevelNames[kLevelStats] = {
        "Health", "Stamina", "Oxygen", "Food", "Weight", "Melee Damage", "Movement Speed", "Crafting Skill"
    };
    static constexpr uint8_t kLevelStatIndex[kLevelStats] = { 0, 1, 3, 4, 7, 8, 9, 11 };

private:
    static bool Valid(const void* p)
    {
        const uintptr_t v = reinterpret_cast<uintptr_t>(p);
        return v > 0x10000 && v < 0x7FFFFFFFFFFF;
    }

    template <typename T>
    static T* At(const void* base, uintptr_t off)
    {
        return reinterpret_cast<T*>(reinterpret_cast<uintptr_t>(base) + off);
    }

    static const std::string& NameOf(UClass* cls)
    {
        static const std::string kEmpty;
        if (!Valid(cls)) return kEmpty;
        static std::unordered_map<void*, std::string> s_names;
        auto it = s_names.find(cls);
        if (it != s_names.end()) return it->second;
        return s_names.emplace(cls, reinterpret_cast<UObject*>(cls)->GetName()).first->second;
    }

    static bool Has(const std::string& s, const char* n) { return s.find(n) != std::string::npos; }

    // Class-chain check (AActor::IsDino uses FindClass).
    static bool IsDino(const UObject* o)
    {
        static std::unordered_map<void*, bool> s_cache;
        auto it = s_cache.find(o->Class);
        if (it != s_cache.end()) return it->second;
        bool yes = false;
        int depth = 0;
        for (UStruct* s = o->Class; Valid(s) && depth < 24; s = s->SuperField, depth++)
            if (s->GetName() == "PrimalDinoCharacter") { yes = true; break; }
        s_cache.emplace(o->Class, yes);
        return yes;
    }

    struct V3 { float x, y, z; };
    static void* RootOf(const void* a) { void* r = *At<void*>(a, OFF_ROOT); return Valid(r) ? r : nullptr; }
    static V3 Center(const void* comp) { return *At<V3>(comp, OFF_BOUNDS_ORIGIN); }
    static float Dist(const V3& a, const V3& b)
    {
        const float dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
        return sqrtf(dx * dx + dy * dy + dz * dz);
    }

    // Separate and noinline, no STL in scope (C2712).
    __declspec(noinline) static void Call(void* obj, UFunction* f, void* parms)
    {
        if (!f || !obj) return;
        __try { UObject::ProcessEvent(obj, f, parms); }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    __declspec(noinline) static bool IsAlive(void* actor)
    {
        UFunction* f = EngineRefs::g_refs.charIsAlive;
        if (!f) return true;
        __try
        {
            struct { bool ReturnValue; } p{ false };
            UObject::ProcessEvent(actor, f, &p);
            return p.ReturnValue;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    static inline bool s_sending = false;   // our own sends, for OnPreEvent
    static void MultiUse(UObject* pc, UObject* target, int32_t index)
    {
        struct { UObject* ForObject; int32_t UseIndex; int32_t _pad; } p{ target, index, 0 };
        s_sending = true;
        Call(pc, EngineRefs::g_refs.pcServerMultiUse, &p);
        s_sending = false;
    }

    static void Transfer(UObject* pc, UObject* destInv, uint64_t itemId, int32_t qty, bool equip)
    {
        struct {
            UObject* InventoryComp; uint64_t ItemId;
            bool bAlsoTryToEquip; uint8_t _pad[3];
            int32_t RequestedQuantity;
        } p{};
        p.InventoryComp = destInv; p.ItemId = itemId; p.bAlsoTryToEquip = equip; p.RequestedQuantity = qty;
        Call(pc, EngineRefs::g_refs.pcTransferToRemoteInv, &p);
    }

    // ---- what one scan sees ------------------------------------------------
    struct Dino
    {
        AActor*  actor  = nullptr;
        float    dist   = 0.f;
        float    radius = 0.f;    // bounding-box half-extent, the server's reach adds it
        float    minExt = 0.f;    // smallest mesh half-extent
        int32_t  team   = 0;
        bool     baby   = false;
    };

    static bool InUseReach(const Dino& d, float wantCm = 0.f)
    {
        float reach = d.radius + kUseReachCm - kUseMarginCm;
        if (wantCm > 0.f && wantCm < reach) reach = wantCm;
        return d.dist <= reach;
    }
    struct Station
    {
        AActor*  actor = nullptr;
        UObject* inv   = nullptr;
        float    dist  = 0.f;
        float    reach = 0.f;
    };

    static inline std::vector<Dino>    s_dinos;
    static inline std::vector<AActor*> s_eggs;
    static inline std::vector<Station> s_incubators;
    static inline std::vector<Station> s_chambers;
    static inline std::vector<Station> s_cloneChambers;   // within Auto Clone's range

    static float ReachCm(UObject* inv)
    {
        float r = *At<float>(inv, OFF_INV_ACCESS);
        if (!(r >= kMinSaneRangeCm) || r > kMaxSaneRangeCm) r = kDefaultRangeCm;
        return r - kRangeMarginCm;
    }

    static void Scan(AActor* localActor)
    {
        s_dinos.clear(); s_eggs.clear(); s_incubators.clear(); s_chambers.clear(); s_cloneChambers.clear();
        float cloneCm = Settings::Dino::AutoClone ? Settings::Dino::AutoCloneRange * 100.f : 0.f;
        if (cloneCm > 30000.f) cloneCm = 30000.f;
        const float limitCm = cloneCm + 2000.f > kScanCm ? cloneCm + 2000.f : kScanCm;
        UWorld* world = UWorld::Get();
        if (!world || !Valid(world->PersistentLevel)) return;
        void* lr = RootOf(localActor);
        if (!lr) return;
        const V3 me = Center(lr);

        TArray<AActor*>& actors = world->PersistentLevel->Actors;
        const int count = actors.Count();
        if (count <= 0 || count > 400000) return;
        for (int i = 0; i < count; ++i)
        {
            AActor* a = actors[i];
            if (!Valid(a) || a == localActor) continue;
            void* r = RootOf(a);
            if (!r) continue;
            const float d = Dist(Center(r), me);
            if (!(d < limitCm)) continue;
            const UObject* ao = reinterpret_cast<const UObject*>(a);

            if (IsDino(ao))
            {
                if (!IsAlive(a)) continue;
                Dino dn;
                dn.actor  = a;
                dn.dist   = d;
                const V3 re = *At<V3>(r, OFF_BOUNDS_EXTENT);
                dn.radius = sqrtf(re.x * re.x + re.y * re.y + re.z * re.z);
                {
                    // The MESH's bounds, as the server's reach test reads them.
                    void* mesh = *At<void*>(a, OFF_CHAR_MESH);
                    const V3 e = Valid(mesh) ? *At<V3>(mesh, OFF_BOUNDS_EXTENT) : re;
                    float m = e.x < e.y ? e.x : e.y;
                    dn.minExt = m < e.z ? m : e.z;
                }
                dn.team  = *At<int32_t>(a, OFF_TEAM);
                dn.baby  = (*At<uint8_t>(a, OFF_DINO_BABYFLAGS) & BIT_IS_BABY) != 0;
                s_dinos.push_back(dn);
                continue;
            }
            const std::string& n = NameOf(ao->Class);
            if (Has(n, "FertilizedEgg"))
            {
                if (d <= kPickupRangeCm) s_eggs.push_back(a);
                continue;
            }
            const bool incubator = n == "EggIncubator_C";
            const bool chamber   = n == "TekCloningChamber_C";
            if (!incubator && !chamber) continue;
            UObject* inv = *At<UObject*>(a, OFF_CONT_INV);
            if (!Valid(inv)) continue;
            const float reach = ReachCm(inv);
            if (chamber && d <= cloneCm) s_cloneChambers.push_back({ a, inv, d, reach });
            if (!(d <= reach)) continue;
            (incubator ? s_incubators : s_chambers).push_back({ a, inv, d, reach });
        }
    }

    // ---- per-target timers -------------------------------------------------
    enum Act { ActSaddle, ActImprint, ActName, ActClaim, ActNeuter, ActClone, ActHatch, ActEgg, ActCount };

    static bool Due(void* target, Act act, uint64_t now, uint64_t gapMs)
    {
        static std::unordered_map<uint64_t, uint64_t> s_last;
        const uint64_t key = (reinterpret_cast<uint64_t>(target) << 4) ^ static_cast<uint64_t>(act);
        uint64_t& last = s_last[key];
        if (now - last < gapMs) return false;
        last = now;
        return true;
    }

    static bool ItemDue(uint64_t itemId, uint64_t now)
    {
        static std::unordered_map<uint64_t, uint64_t> s_sent;
        uint64_t& last = s_sent[itemId];
        if (now - last < kResendMs) return false;
        last = now;
        return true;
    }

    static inline int s_count[ActCount + 3] = {};
    enum { CntLevel = ActCount, CntShards, CntEggsIn };

    // ---- the multi-use queue -----------------------------------------------
    struct UseWant
    {
        UObject* target;
        int32_t  index;
        Act      act;
        UObject* slotInv  = nullptr;   // imprint food: into hotbar slot 9 first
        uint64_t slotItem = 0;
    };
    static inline std::vector<UseWant> s_want;

    static inline std::unordered_map<void*, uint64_t> s_claimedAt;   // for swallowing the name box
    static constexpr uint64_t kClaimNameBoxMs = 15000;
    static inline std::unordered_map<uint64_t, uint64_t> s_useLast;

    static uint64_t UseKey(const void* t, Act a) { return (reinterpret_cast<uint64_t>(t) << 4) ^ static_cast<uint64_t>(a); }

    static void Want(const UseWant& w, uint64_t now)
    {
        auto it = s_useLast.find(UseKey(w.target, w.act));
        if (it != s_useLast.end() && now - it->second < kRetryMs) return;
        s_want.push_back(w);
    }

    static void FlushUses(UObject* pc, uint64_t now)
    {
        static uint64_t s_lastUse = 0;
        if (s_want.empty() || now - s_lastUse < kMultiUseGapMs) { s_want.clear(); return; }
        const UseWant* pick = nullptr;
        uint64_t oldest = UINT64_MAX;
        for (const UseWant& w : s_want)
        {
            auto it = s_useLast.find(UseKey(w.target, w.act));
            const uint64_t last = it == s_useLast.end() ? 0 : it->second;
            if (last < oldest) { oldest = last; pick = &w; }
        }
        if (pick)
        {
            if (pick->slotInv && pick->slotItem)
            {
                struct { uint64_t ItemId; int32_t SlotIndex; int32_t _pad; } p{ pick->slotItem, kCuddleSlot, 0 };
                Call(pick->slotInv, EngineRefs::g_refs.invAddItemToSlot, &p);
            }
            MultiUse(pc, pick->target, pick->index);
            if (pick->act == ActClaim) s_claimedAt[pick->target] = now;
            s_useLast[UseKey(pick->target, pick->act)] = now;
            s_lastUse = now;
            ++s_count[pick->act];
        }
        s_want.clear();
    }

    // ---- why each feature is idle (status line) -----------------------------
    struct Why
    {
        int mine = 0, babies = 0, unclaimed = 0;
        int imprintDue = 0, imprintWalk = 0, imprintNoFood = 0, imprintFar = 0;
        int neuterable = 0, neuterFar = 0;
        int saddleNeed = 0, saddleNoFit = 0, saddleHas = 0, saddleFar = 0, saddlesMine = 0, saddleEquipping = 0;
        int unnamed = 0;
        int levelReady = 0, levelNoPoints = 0;
        int eggsGround = 0, eggsMine = 0, shardsMine = 0;
    };
    static inline Why s_why;

    // ---- your inventory ------------------------------------------------------
    struct Item { UObject* obj; uint64_t id; int32_t qty; };

    static void MyItems(AActor* localActor, std::vector<Item>& out)
    {
        out.clear();
        UObject* inv = *At<UObject*>(localActor, OFF_CHAR_INV);
        if (!Valid(inv)) return;
        const TArray<UObject*>& items = *At<TArray<UObject*>>(inv, OFF_INV_ITEMS);
        const int n = items.Count();
        if (n <= 0 || n > 20000) return;
        for (int i = 0; i < n; ++i)
        {
            UObject* it = items.Data()[i];
            if (!Valid(it)) continue;
            if (*At<uint8_t>(it, OFF_ITEM_FLAGS53) & BIT_NOT_REAL) continue;
            out.push_back({ it, *At<uint64_t>(it, OFF_ITEM_ID), *At<int32_t>(it, OFF_ITEM_QTY) });
        }
    }

    // ---- learned requests (clone, hatch) -----------------------------------
    struct Learned
    {
        bool    netExec   = false;
        uint8_t block[0x50] = {};   // forActor, CommandName, ExecParams (string zeroed)
        int     dinoSlot  = -1;     // ObjParam index holding the dino (clone)
        int32_t multiUse  = -1;     // or a multi-use index (hatch)
    };
    static inline Learned s_clone, s_hatch;

    static const Station* Nearest(const std::vector<Station>& list)
    {
        const Station* best = nullptr;
        for (const Station& s : list) if (!best || s.dist < best->dist) best = &s;
        return best;
    }

    static bool IsMine(const Dino& d, int32_t localTribeID)
    {
        return localTribeID > 0 && d.team == localTribeID;
    }

    static bool FStringEmpty(AActor* a, uintptr_t off)
    {
        const FString& s = *At<FString>(a, off);
        return s.Count() <= 1 || !s.IsValid();
    }

    static bool FStringEquals(AActor* a, uintptr_t off, const std::wstring& w)
    {
        const FString& s = *At<FString>(a, off);
        if (!s.IsValid() || s.Count() <= 1) return w.empty();
        return w == s.wc_str();
    }

    // ---- the features --------------------------------------------------------
    static void DoSaddle(UObject* pc, int32_t tribe, const std::vector<Item>& mine, uint64_t now)
    {
        using E = Settings::Dino;
        for (const Item& it : mine)
            if (*At<uint8_t>(it.obj, OFF_ITEM_EQUIPTYPE) == kEquipSaddle) ++s_why.saddlesMine;
        float saddleCm = E::AutoSaddleReach * 100.f;
        if (saddleCm < 100.f) saddleCm = 100.f;

        // ONE saddle per dino (by DinoID1/2), then equip attempts on the id it
        // gets inside the dino.
        struct SaddleState { uint64_t itemId = 0; uint64_t givenAt = 0; uint64_t lastUse = 0; int uses = 0; bool accepted = false; };
        static std::unordered_map<uint64_t, uint64_t> s_given;   // saddle ItemId -> when sent
        static std::unordered_map<uint64_t, SaddleState> s_state;
        static std::unordered_map<void*, uint64_t> s_opened;     // inventory -> last open
        auto openInv = [&](UObject* inv)
        {
            uint64_t& opened = s_opened[inv];
            if (now - opened <= 10000) return;
            struct { UObject* InventoryComp; } vp{ inv };
            Call(pc, EngineRefs::g_refs.pcViewRemoteInv, &vp);
            struct { UObject* forInventory; bool bInventoryItems; bool bIsFirstSpawn; uint8_t _pad[6]; } rp{ inv, true, false };
            Call(pc, EngineRefs::g_refs.pcRequestActorItems, &rp);
            rp.bInventoryItems = false;
            Call(pc, EngineRefs::g_refs.pcRequestActorItems, &rp);
            opened = now;
        };
        auto equip = [&](UObject* inv, uint64_t itemId)
        {
            struct { UObject* InventoryComp; uint64_t ItemId; } ep{ inv, itemId };
            Call(pc, EngineRefs::g_refs.pcEquipToRemoteInv, &ep);
        };
        auto saddleIn = [&](UObject* inv, uintptr_t listOff) -> uint64_t
        {
            const TArray<UObject*>& items = *At<TArray<UObject*>>(inv, listOff);
            const int n = items.Count();
            if (n <= 0 || n > 20000) return 0;
            for (int i = 0; i < n; ++i)
            {
                UObject* it = items.Data()[i];
                if (!Valid(it) || (*At<uint8_t>(it, OFF_ITEM_FLAGS53) & BIT_NOT_REAL)) continue;
                if (*At<uint8_t>(it, OFF_ITEM_EQUIPTYPE) == kEquipSaddle) return *At<uint64_t>(it, OFF_ITEM_ID);
            }
            return 0;
        };

        // Nearest first.
        static std::vector<const Dino*> order;
        order.clear();
        for (const Dino& d : s_dinos) order.push_back(&d);
        std::sort(order.begin(), order.end(), [](const Dino* a, const Dino* b) { return a->dist < b->dist; });
        for (const Dino* dp : order)
        {
            const Dino& d = *dp;
            if (!IsMine(d, tribe) || d.baby) continue;
            UObject* dinoInv = *At<UObject*>(d.actor, OFF_CHAR_INV);
            if (!Valid(dinoInv)) continue;
            const uint64_t key = (static_cast<uint64_t>(*At<uint32_t>(d.actor, OFF_DINO_ID1)) << 32) |
                                 *At<uint32_t>(d.actor, OFF_DINO_ID2);
            if (*At<uint64_t>(d.actor, OFF_SADDLE_ITEMID) != 0 ||
                Valid(*At<UClass*>(d.actor, OFF_DINO_SADDLE)) ||
                saddleIn(dinoInv, OFF_INV_EQUIPPED) != 0)
            {
                ++s_why.saddleHas;
                auto it = s_state.find(key);
                if (it != s_state.end() && it->second.itemId)
                    Logger::Log("[Breeding] saddled %s at %.1f m", NameOf(reinterpret_cast<UObject*>(d.actor)->Class).c_str(), d.dist / 100.f);
                if (it != s_state.end()) s_state.erase(it);
                continue;
            }
            // Server reach: |you - dino| - dino mesh min extent <= its inventory
            // access distance (1.5 m slack so none the server would take is skipped).
            float access = *At<float>(dinoInv, OFF_INV_ACCESS);
            if (!(access > 50.f) || access > 10000.f) access = kDefaultRangeCm;
            if (d.dist > d.radius + saddleCm || d.dist - d.minExt > access + 150.f) { ++s_why.saddleFar; continue; }

            SaddleState& st = s_state[key];
            const uint64_t seen = saddleIn(dinoInv, OFF_INV_ITEMS);
            uint64_t inside = seen;
            if (!inside && st.itemId)
            {
                bool stillMine = false;
                for (const Item& it : mine) if (it.id == st.itemId) { stillMine = true; break; }
                if (stillMine && now - st.givenAt > 400) st = SaddleState{};   // refused - free to retry
                else if (!stillMine && !st.accepted)
                {
                    st.accepted = true;
                    Logger::Log("[Breeding] server took a saddle for %s at %.1f m", NameOf(reinterpret_cast<UObject*>(d.actor)->Class).c_str(), d.dist / 100.f);
                }
                else inside = st.itemId;
            }
            if (inside)
            {
                ++s_why.saddleEquipping;
                if (!seen)
                {
                    // Not in the client's copy yet: ask for its items again.
                    static std::unordered_map<void*, uint64_t> s_refreshed;
                    uint64_t& refreshed = s_refreshed[dinoInv];
                    if (now - refreshed >= 700)
                    {
                        struct { UObject* forInventory; bool bInventoryItems; bool bIsFirstSpawn; uint8_t _pad[6]; } rp{ dinoInv, true, false };
                        Call(pc, EngineRefs::g_refs.pcRequestActorItems, &rp);
                        refreshed = now;
                    }
                    continue;
                }
                if (st.uses >= 40 || now - st.lastUse < kSaddleRetryMs) continue;
                if (st.uses == 0)
                    Logger::Log("[Breeding] saddle is inside %s at %.1f m - equipping", NameOf(reinterpret_cast<UObject*>(d.actor)->Class).c_str(), d.dist / 100.f);
                equip(dinoInv, inside);
                st.lastUse = now;
                if (++st.uses == 40)
                    Logger::Log("[Breeding] saddle inside %s would not equip after 40 tries - giving up on it",
                                NameOf(reinterpret_cast<UObject*>(d.actor)->Class).c_str());
                ++s_count[ActSaddle];
                continue;
            }
            ++s_why.saddleNeed;
            // A saddle that fits: owner class or owner tag.
            const Item* fit = nullptr;
            const UObject* dinoObj = reinterpret_cast<const UObject*>(d.actor);
            const FName& dinoTag = *At<FName>(d.actor, OFF_ACTOR_CUSTOMTAG);
            for (const Item& it : mine)
            {
                if (*At<uint8_t>(it.obj, OFF_ITEM_EQUIPTYPE) != kEquipSaddle) continue;
                auto g = s_given.find(it.id);
                if (g != s_given.end() && now - g->second < 400) continue;
                const TArray<UClass*>& owners = *At<TArray<UClass*>>(it.obj, OFF_ITEM_OWNERS);
                const int n = owners.Count();
                for (int k = 0; k < n && k < 64 && !fit; ++k)
                    if (Valid(owners.Data()[k]) && dinoObj->IsA(owners.Data()[k])) fit = &it;
                const TArray<FName>& tags = *At<TArray<FName>>(it.obj, OFF_ITEM_OWNER_TAGS);
                const int nt = tags.Count();
                for (int k = 0; k < nt && k < 64 && !fit; ++k)
                    if (tags.Data()[k].ComparisonIndex == dinoTag.ComparisonIndex && tags.Data()[k].Number == dinoTag.Number &&
                        dinoTag.ComparisonIndex > 0) fit = &it;
                if (fit) break;
            }
            if (!fit)
            {
                ++s_why.saddleNoFit;
                static uint64_t s_lastNoFit = 0;
                if (now - s_lastNoFit > 10000)
                {
                    s_lastNoFit = now;
                    Logger::Log("[Breeding] no saddle on you fits %s", NameOf(dinoObj->Class).c_str());
                }
                continue;
            }
            // Open, saddle in, equip - one frame, in that order.
            openInv(dinoInv);
            Transfer(pc, dinoInv, fit->id, 1, true);
            equip(dinoInv, fit->id);
            st.itemId  = fit->id;
            st.givenAt = now;
            s_given[fit->id] = now;
            st.lastUse = now;
            st.uses    = 0;
            ++s_count[ActSaddle];
        }
    }

    static void DoImprint(AActor* localActor, int32_t tribe, const std::vector<Item>& mine, uint64_t now)
    {
        UWorld* world = UWorld::Get();
        UObject* gs = world ? reinterpret_cast<UObject*>(world->GameState) : nullptr;
        if (!Valid(gs)) return;
        const double netNow = *At<double>(gs, OFF_NETWORK_TIME);
        for (const Dino& d : s_dinos)
        {
            if (!IsMine(d, tribe) || !d.baby) continue;
            const double due = *At<double>(d.actor, OFF_CUDDLE_TIME);
            if (!(due > 0.0) || !(netNow > due)) continue;
            ++s_why.imprintDue;
            if (!InUseReach(d)) { ++s_why.imprintFar; continue; }
            const uint8_t type = *At<uint8_t>(d.actor, OFF_CUDDLE_TYPE);
            if (type == 2) { ++s_why.imprintWalk; continue; }   // walk: no use index does it
            UseWant w{ reinterpret_cast<UObject*>(d.actor), kUseCuddle, ActImprint };
            if (type == 1)
            {
                UClass* food = *At<UClass*>(d.actor, OFF_CUDDLE_FOOD);
                const Item* have = nullptr;
                for (const Item& it : mine)
                    if (Valid(food) && it.obj->IsA(food)) { have = &it; break; }
                if (!have)
                {
                    ++s_why.imprintNoFood;
                    static uint64_t s_lastNoFood = 0;
                    if (now - s_lastNoFood > 10000)
                    {
                        s_lastNoFood = now;
                        Logger::Log("[Breeding] imprint wants %s - none in your inventory", Valid(food) ? NameOf(food).c_str() : "?");
                    }
                    continue;
                }
                w.slotInv  = *At<UObject*>(localActor, OFF_CHAR_INV);
                w.slotItem = have->id;
            }
            Want(w, now);
        }
    }

    static void DoName(UObject* pc, int32_t tribe, uint64_t now)
    {
        using E = Settings::Dino;
        char name[64];
        memcpy(name, E::AutoNameText, sizeof(name));
        name[63] = 0;
        if (!name[0]) return;
        static std::string  s_src;
        static std::wstring s_wide;
        if (s_src != name)
        {
            s_src  = name;
            s_wide.assign(s_src.begin(), s_src.end());
        }
        const float range = E::AutoNameRange * 100.f;
        for (const Dino& d : s_dinos)
        {
            if (!IsMine(d, tribe) || d.dist > range) continue;
            const bool unnamed = FStringEmpty(d.actor, OFF_DINO_NAME);
            if (!unnamed && (!E::AutoNameOverwrite || FStringEquals(d.actor, OFF_DINO_NAME, s_wide))) continue;
            ++s_why.unnamed;
            if (!Due(d.actor, ActName, now, kRetryMs * 2)) continue;
            struct {
                FString  TextToUse;
                bool     checkedBox; uint8_t _pad[7];
                UClass*  ForObjectClass;
                uint32_t ExtraID1, ExtraID2;
                UObject* ForObject;
            } p{};
            p.TextToUse      = FString(s_wide.c_str());
            p.checkedBox     = false;
            p.ForObjectClass = reinterpret_cast<UObject*>(d.actor)->Class;
            p.ExtraID1       = *At<uint32_t>(d.actor, OFF_DINO_ID1);
            p.ExtraID2       = *At<uint32_t>(d.actor, OFF_DINO_ID2);
            p.ForObject      = reinterpret_cast<UObject*>(d.actor);
            Call(pc, EngineRefs::g_refs.pcNotifyEditText, &p);
            ++s_count[ActName];
        }
    }

    static void DoClaim(uint64_t now)
    {
        for (const Dino& d : s_dinos)
        {
            if (d.team != kUnclaimedTeam) continue;
            ++s_why.unclaimed;
            if (!InUseReach(d)) continue;
            Want({ reinterpret_cast<UObject*>(d.actor), kUseClaim, ActClaim }, now);
        }
    }

    static void DoNeuter(int32_t tribe, uint64_t now)
    {
        const float range = Settings::Dino::AutoNeuterRange * 100.f;
        for (const Dino& d : s_dinos)
        {
            if (!IsMine(d, tribe)) continue;
            if (*At<uint8_t>(d.actor, OFF_NEUTERED) & BIT_NEUTERED) continue;
            if (*At<uint8_t>(d.actor, OFF_PREVENT_NEUTER) & BIT_PREVENT_NEUTER) continue;
            ++s_why.neuterable;
            if (!InUseReach(d, range)) { ++s_why.neuterFar; continue; }
            Want({ reinterpret_cast<UObject*>(d.actor), kUseNeuter, ActNeuter }, now);
        }
    }

    // The client's own "+" button test, off replicated experience.
    __declspec(noinline) static bool CanLevel(UObject* status, uint8_t stat)
    {
        UFunction* f = EngineRefs::g_refs.statusCanLevelUp;
        if (!f) return true;   // unknown: let the server decide
        __try {
            struct { uint8_t Stat; bool bCheckExperience; bool ReturnValue; } p{ stat, true, false };
            UObject::ProcessEvent(status, f, &p);
            return p.ReturnValue;
        } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // One request per dino at a time; counted once the level actually rises.
    static void DoLevel(UObject* pc, int32_t tribe, uint64_t now)
    {
        if (!s_levelLoaded) LoadLevels();
        auto& s_state = s_level;
        for (const Dino& d : s_dinos)
        {
            if (!IsMine(d, tribe) || d.dist > kScanCm) continue;
            UObject* status = *At<UObject*>(d.actor, OFF_STATUS_COMP);
            if (!Valid(status)) continue;
            const uint64_t key = (static_cast<uint64_t>(*At<uint32_t>(d.actor, OFF_DINO_ID1)) << 32) |
                                 *At<uint32_t>(d.actor, OFF_DINO_ID2);
            LevelState& st = s_state[key];
            const uint16_t lvl = *At<uint16_t>(status, OFF_EXTRA_LEVEL);

            if (st.pendingStat >= 0)
            {
                if (lvl > st.levelAtSend)
                {
                    ++st.applied[st.pendingStat];
                    st.pendingStat = -1;
                    s_levelDirty   = true;
                    s_levelSaveAt  = now + 2000;   // batched: one write per burst
                }
                else if (now - st.sentAt > kLevelWaitMs) st.pendingStat = -1;   // refused - try later
                else continue;
            }

            int pick = -1;
            bool wantsMore = false;
            for (int s = 0; s < kLevelStats; ++s)
            {
                int want = Settings::Dino::AutoLevelPoints[s];
                if (want < 0) want = 0;
                if (want > 255) want = 255;
                if (st.applied[s] >= want) continue;
                wantsMore = true;
                if (CanLevel(status, kLevelStatIndex[s])) { pick = s; break; }
            }
            if (!wantsMore) continue;
            if (pick < 0) { ++s_why.levelNoPoints; continue; }
            ++s_why.levelReady;

            struct { UObject* forStatusComp; uint8_t ValueType; uint8_t _pad[7]; } p{};
            p.forStatusComp = status;
            p.ValueType     = kLevelStatIndex[pick];
            Call(pc, EngineRefs::g_refs.pcRequestLevelUp, &p);
            st.pendingStat = pick;
            st.levelAtSend = lvl;
            st.sentAt      = now;
            ++s_count[CntLevel];
        }
    }

    static void DoFillChamber(UObject* pc, const std::vector<Item>& mine, uint64_t now)
    {
        const Station* c = Nearest(s_chambers);
        for (const Item& it : mine)
        {
            if (NameOf(it.obj->Class) != kShardClass || it.qty <= 0) continue;
            ++s_why.shardsMine;
            if (!c || !ItemDue(it.id, now)) continue;
            Transfer(pc, c->inv, it.id, it.qty, false);
            ++s_count[CntShards];
        }
    }

    static void DoTransferEggs(UObject* pc, const std::vector<Item>& mine, uint64_t now)
    {
        const Station* inc = Nearest(s_incubators);
        for (const Item& it : mine)
        {
            if (!Has(NameOf(it.obj->Class), "Fertilized") || it.qty <= 0) continue;
            ++s_why.eggsMine;
            if (!inc || !ItemDue(it.id, now)) continue;
            Transfer(pc, inc->inv, it.id, it.qty, false);
            ++s_count[CntEggsIn];
        }
    }

    static void DoPickupEggs(uint64_t now)
    {
        for (AActor* egg : s_eggs)
            Want({ reinterpret_cast<UObject*>(egg), kUsePickup, ActEgg }, now);
    }

    __declspec(noinline) static void SendLearned(UObject* pc, const Learned& l, AActor* forActor, AActor* dino)
    {
        uint8_t block[sizeof(l.block)];
        memcpy(block, l.block, sizeof(block));
        *reinterpret_cast<AActor**>(block) = forActor;
        if (dino && l.dinoSlot >= 0)
            *reinterpret_cast<AActor**>(block + 0x10 + 0x18 + l.dinoSlot * 8) = dino;
        s_sending = true;
        Call(pc, EngineRefs::g_refs.pcNetExecCommand, block);
        s_sending = false;
    }

    // Built-in clone: ServerProcessNetExecCommand(chamber, "Clone", ObjParam1 = dino).
    static bool CloneCommandKnown() { return EngineRefs::g_refs.nameClone > 0; }

    __declspec(noinline) static void SendCloneCommand(UObject* pc, AActor* chamber, AActor* dino)
    {
        uint8_t block[0x50] = {};
        *reinterpret_cast<AActor**>(block) = chamber;
        *reinterpret_cast<int32_t*>(block + 0x08)  = EngineRefs::g_refs.nameClone;   // FName ComparisonIndex
        *reinterpret_cast<int32_t*>(block + 0x0C)  = 0;                             // Number
        *reinterpret_cast<AActor**>(block + 0x10 + 0x18) = dino;                    // ObjParam1
        s_sending = true;
        Call(pc, EngineRefs::g_refs.pcNetExecCommand, block);
        s_sending = false;
    }

    static void DoClone(UObject* pc, int32_t tribe, uint64_t now)
    {
        if (!s_clone.netExec && s_clone.multiUse < 0 && !CloneCommandKnown()) return;
        for (const Station& c : s_cloneChambers)
        {
            if (*At<uint8_t>(c.actor, OFF_CHAMBER_BUSY)) continue;   // cloning already
            float searchCm = *At<float>(c.actor, OFF_CHAMBER_RANGE);
            if (!(searchCm > 100.f) || searchCm > 10000.f) searchCm = 1500.f;
            void* cr = RootOf(c.actor);
            if (!cr) continue;
            const V3 at = Center(cr);
            const Dino* best = nullptr;
            float bestCm = searchCm;
            for (const Dino& d : s_dinos)
            {
                if (!IsMine(d, tribe) || d.baby) continue;
                void* dr = RootOf(d.actor);
                if (!dr) continue;
                const float cm = Dist(Center(dr), at);
                if (cm < bestCm) { bestCm = cm; best = &d; }
            }
            if (!best) continue;
            if (!s_clone.netExec && !CloneCommandKnown() && s_clone.multiUse >= 0 && c.dist <= c.reach)
            {
                if (Due(c.actor, ActClone, now, kStationGapMs))
                    Want({ reinterpret_cast<UObject*>(c.actor), s_clone.multiUse, ActClone }, now);
                continue;
            }
            if (!Due(c.actor, ActClone, now, kStationGapMs)) continue;
            if (s_clone.netExec) SendLearned(pc, s_clone, c.actor, best->actor);
            else                 SendCloneCommand(pc, c.actor, best->actor);
            ++s_count[ActClone];
            static uint64_t s_lastCloneLog = 0;
            if (now - s_lastCloneLog > 5000)
            {
                s_lastCloneLog = now;
                Logger::Log("[Breeding] clone - asked chamber %p to clone %s (%.0f cm away, chamber shards %d, via %s)",
                            (void*)c.actor, NameOf(reinterpret_cast<UObject*>(best->actor)->Class).c_str(), bestCm,
                            *At<int32_t>(c.actor, OFF_CHAMBER_SHARDS), s_clone.netExec ? "learned request" : "built-in 'Clone'");
            }
        }
    }

    static void DoHatch(UObject* pc, uint64_t now)
    {
        if (!s_hatch.netExec && s_hatch.multiUse < 0) return;
        for (const Station& inc : s_incubators)
        {
            if (!Due(inc.actor, ActHatch, now, kStationGapMs)) continue;
            if (s_hatch.multiUse >= 0) { Want({ reinterpret_cast<UObject*>(inc.actor), s_hatch.multiUse, ActHatch }, now); continue; }
            SendLearned(pc, s_hatch, inc.actor, nullptr);
            ++s_count[ActHatch];
        }
    }

    // ---- hatch verification ----------------------------------------------------
    // Only an action the incubator itself labels as hatching is ever learned:
    // its radial entries come from its BPGetMultiUseEntries (FMultiUseEntry,
    // 0x50 each: UseString @0x08, UseIndex @0x18 - read live), and the label
    // must be its HatchEggString or contain "Hatch". Pick up / demolish / temp
    // control on an incubator can never be learned and repeated.
    static bool ContainsHatch(const wchar_t* s, int n)
    {
        for (int i = 0; i + 5 <= n; i++)
            if ((s[i] == L'H' || s[i] == L'h') && (s[i + 1] | 0x20) == L'a' && (s[i + 2] | 0x20) == L't' &&
                (s[i + 3] | 0x20) == L'c' && (s[i + 4] | 0x20) == L'h') return true;
        return false;
    }

    static UFunction* FindOwnFunction(const UObject* obj, const char* name)
    {
        int depth = 0;
        for (UStruct* s = obj->Class; Valid(s) && depth < 4; s = s->SuperField, depth++)
        {
            int guard = 0;
            for (UField* f = s->Children; Valid(f) && guard++ < 4096; f = f->Next)
                if (f->GetName() == name && NameOf(reinterpret_cast<UObject*>(f)->Class) == "Function")
                    return reinterpret_cast<UFunction*>(f);
        }
        return nullptr;
    }

    __declspec(noinline) static bool CallEntries(void* obj, UFunction* fn, void* pc, uint8_t* out)
    {
        __try
        {
            memset(out, 0, 0x28);
            *reinterpret_cast<void**>(out) = pc;   // ForPC; MultiUseEntries in, ReturnValue out
            UObject::ProcessEvent(obj, fn, out);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    static bool IsHatchUseIndex(UObject* incubator, void* pc, int32_t idx)
    {
        static void*      s_cls = nullptr;
        static UFunction* s_fn  = nullptr;
        if (incubator->Class != s_cls) { s_cls = incubator->Class; s_fn = FindOwnFunction(incubator, "BPGetMultiUseEntries"); }
        if (!s_fn) return false;
        alignas(16) uint8_t parms[0x28];
        if (!CallEntries(incubator, s_fn, pc, parms)) return false;
        // The returned array was allocated by the game; it is only read, and left.
        const uint8_t* data = *reinterpret_cast<uint8_t**>(parms + 0x18);
        const int      n    = *reinterpret_cast<int32_t*>(parms + 0x20);
        if (!Valid(data) || n <= 0 || n > 64) return false;

        static uint32_t s_offLabel = 0; static void* s_labelCls = nullptr;
        const wchar_t* label = nullptr; int labelN = 0;
        if (s_labelCls != incubator->Class)
        {
            s_labelCls = incubator->Class;
            s_offLabel = 0;
            int depth = 0;
            for (UStruct* s = incubator->Class; Valid(s) && depth < 4 && !s_offLabel; s = s->SuperField, depth++)
                for (UField* f = s->Children; Valid(f); f = f->Next)
                    if (f->GetName() == "HatchEggString") { s_offLabel = static_cast<uint32_t>(reinterpret_cast<UProperty*>(f)->Offset); break; }
        }
        if (s_offLabel)
        {
            label  = *At<wchar_t*>(incubator, s_offLabel);
            labelN = *At<int32_t>(incubator, s_offLabel + 8);
            if (!Valid(label) || labelN <= 1 || labelN > 128) { label = nullptr; labelN = 0; }
        }

        for (int i = 0; i < n; i++)
        {
            const uint8_t* e = data + i * 0x50;
            if (*At<int32_t>(e, 0x18) != idx) continue;
            const wchar_t* s  = *At<wchar_t*>(e, 0x08);
            const int      sn = *At<int32_t>(e, 0x10);
            if (!Valid(s) || sn <= 1 || sn > 256) return false;
            if (label && sn == labelN && wcsncmp(s, label, sn) == 0) return true;
            return ContainsHatch(s, sn);
        }
        return false;
    }

    // ---- Auto Level counts, kept across sessions -------------------------------
    // Points applied per dino (DinoID1/2) can not be read back from the client,
    // so they are saved to paidini\autolevel.dat - a re-inject never levels a
    // dino past what you set.
    struct LevelState
    {
        int      applied[kLevelStats] = {};
        int      pendingStat = -1;
        uint16_t levelAtSend = 0;
        uint64_t sentAt      = 0;
    };
    static inline std::unordered_map<uint64_t, LevelState> s_level;
    static inline bool     s_levelLoaded = false;
    static inline bool     s_levelDirty  = false;
    static inline uint64_t s_levelSaveAt = 0;

    static std::wstring LevelFile()
    {
        wchar_t prof[MAX_PATH] = {};
        if (!GetEnvironmentVariableW(L"USERPROFILE", prof, MAX_PATH)) return L"";
        return std::wstring(prof) + L"\\AppData\\Local\\Packages\\StudioWildcard.4558480580BB9_1w2mm55455e38\\AC\\paidini\\autolevel.dat";
    }

    static void LoadLevels()
    {
        s_levelLoaded = true;
        const std::wstring path = LevelFile();
        if (path.empty()) return;
        FILE* f = nullptr;
        if (_wfopen_s(&f, path.c_str(), L"r") != 0 || !f) return;
        unsigned long long key; int c[kLevelStats];
        int loaded = 0;
        while (fscanf_s(f, "%llu %d %d %d %d %d %d %d %d", &key, &c[0], &c[1], &c[2], &c[3], &c[4], &c[5], &c[6], &c[7]) == 9)
        {
            LevelState& st = s_level[key];
            for (int i = 0; i < kLevelStats; i++) st.applied[i] = c[i] < 0 ? 0 : (c[i] > 255 ? 255 : c[i]);
            ++loaded;
        }
        fclose(f);
        Logger::Log("[Breeding] auto level: %d dinos' applied points loaded", loaded);
    }

    static void SaveLevels(uint64_t now)
    {
        if (!s_levelDirty || now < s_levelSaveAt) return;
        s_levelDirty = false;
        const std::wstring path = LevelFile();
        if (path.empty()) return;
        FILE* f = nullptr;
        if (_wfopen_s(&f, path.c_str(), L"w") != 0 || !f) return;
        for (const auto& [key, st] : s_level)
        {
            bool any = false;
            for (int i = 0; i < kLevelStats; i++) if (st.applied[i]) { any = true; break; }
            if (!any) continue;
            fprintf(f, "%llu", static_cast<unsigned long long>(key));
            for (int i = 0; i < kLevelStats; i++) fprintf(f, " %d", st.applied[i]);
            fprintf(f, "\n");
        }
        fclose(f);
    }

    static inline DWORD s_gameThread = 0;

public:
    static bool AnyOn()
    {
        using E = Settings::Dino;
        return E::AutoSaddle || E::AutoImprint || E::AutoNameDino || E::AutoClaim ||
               E::AutoNeuter || E::AutoLevel || E::AutoClone || E::AutoFillCloning ||
               E::AutoPickupEggs || E::TransferEggsIncubator || E::HatchIncubatorEggs;
    }

    // ProcessEvent hook wants: learning (clone / hatch) or the claim name box.
    static bool WantsEvents()
    {
        using E = Settings::Dino;
        return E::AutoClaim || E::AutoClone || E::HatchIncubatorEggs;
    }

    // Eject: write any unsaved Auto Level counts now.
    static void Flush() { s_levelSaveAt = 0; SaveLevels(GetTickCount64()); }

    static bool CloneLearned() { return s_clone.netExec || s_clone.multiUse >= 0 || CloneCommandKnown(); }
    static bool HatchLearned() { return s_hatch.netExec || s_hatch.multiUse >= 0; }

    // From the ProcessEvent pre-hook. Returns true to drop the call: the "Name
    // your dino!" box the server sends after a claim, only for a dino Auto
    // Claim claimed in the last 15 s. Also catches a clone / hatch done by hand.
    static bool OnPreEvent(void* obj, UFunction* function, void* parms)
    {
        using E = Settings::Dino;
        const auto& r = EngineRefs::g_refs;
        if (!function || !parms) return false;
        if (GetCurrentThreadId() != s_gameThread) return false;   // the state below is game-thread only

        if (E::AutoClaim && function == r.pcClientNotifyEditText && !s_claimedAt.empty())
        {
            void* forObject = *reinterpret_cast<void**>(reinterpret_cast<uint8_t*>(parms) + 0x10);
            auto it = s_claimedAt.find(forObject);
            if (it != s_claimedAt.end())
            {
                const bool fresh = GetTickCount64() - it->second <= kClaimNameBoxMs;
                s_claimedAt.erase(it);
                if (fresh) { Logger::Log("[Breeding] dropped the name box for the dino just claimed"); return true; }
            }
            return false;
        }

        if ((!E::AutoClone && !E::HatchIncubatorEggs) || s_sending) return false;

        if (function == r.pcNetExecCommand && r.pcNetExecCommand)
        {
            AActor* forActor = *reinterpret_cast<AActor**>(parms);
            if (!Valid(forActor)) return false;
            const std::string& n = NameOf(reinterpret_cast<UObject*>(forActor)->Class);
            const bool chamber   = n == "TekCloningChamber_C";
            const bool incubator = n == "EggIncubator_C";
            if (!(chamber && E::AutoClone) && !(incubator && E::HatchIncubatorEggs)) return false;
            const FName& cmdName = *reinterpret_cast<FName*>(reinterpret_cast<uint8_t*>(parms) + 8);
            // Only the commands these features mean: the chamber's own Clone, and
            // an incubator command whose name says hatch.
            if (chamber && CloneCommandKnown()) return false;   // built-in, nothing to learn
            if (incubator)
            {
                const std::string cn = cmdName.ComparisonIndex > 0 ? cmdName.GetName() : std::string();
                std::wstring w(cn.begin(), cn.end());
                if (!ContainsHatch(w.c_str(), (int)w.size()))
                {
                    Logger::Log("[Breeding] incubator command '%s' is not a hatch - not learned", cn.c_str());
                    return false;
                }
            }
            Learned& l = chamber ? s_clone : s_hatch;
            memcpy(l.block, parms, sizeof(l.block));
            memset(l.block + 0x10 + 0x30, 0, 0x10);   // StringParam1: its memory is not ours to keep
            l.dinoSlot = -1;
            for (int k = 0; k < 3; ++k)
            {
                UObject* o = *reinterpret_cast<UObject**>(l.block + 0x10 + 0x18 + k * 8);
                if (Valid(o) && IsDino(o)) { l.dinoSlot = k; break; }
            }
            l.netExec = true;
            const FName& cmd = *reinterpret_cast<FName*>(reinterpret_cast<uint8_t*>(parms) + 8);
            Logger::Log("[Breeding] learned the %s - command '%s', dino in ObjParam%d",
                        chamber ? "clone" : "hatch", cmd.GetName().c_str(), l.dinoSlot + 1);
            return false;
        }
        if (function == r.pcServerMultiUse && r.pcServerMultiUse)
        {
            UObject* target = *reinterpret_cast<UObject**>(parms);
            if (!Valid(target)) return false;
            const int32_t idx = *reinterpret_cast<int32_t*>(reinterpret_cast<uint8_t*>(parms) + 8);
            const std::string& n = NameOf(target->Class);
            if (n == "EggIncubator_C" && E::HatchIncubatorEggs && s_hatch.multiUse < 0 && !s_hatch.netExec)
            {
                if (IsHatchUseIndex(target, obj, idx))
                {
                    s_hatch.multiUse = idx;
                    Logger::Log("[Breeding] learned the hatch - incubator multi-use %d", idx);
                }
                else Logger::Log("[Breeding] incubator multi-use %d is not the hatch entry - not learned", idx);
            }
        }
        return false;
    }

    // GAME THREAD, once per frame from DrawHUD.
    static void Tick(APlayerController* controller, AActor* localActor, int32_t localTribeID)
    {
        using E = Settings::Dino;
        s_gameThread = GetCurrentThreadId();
        const uint64_t now = GetTickCount64();

        // A switch turned off forgets what it learned (so a wrong catch is undone
        // by toggling it), and Auto Level's counts reach the disk.
        static bool s_wasHatch = false, s_wasClone = false;
        if (s_wasHatch && !E::HatchIncubatorEggs) { s_hatch = Learned{}; Logger::Log("[Breeding] hatch: forgot the learned action"); }
        if (s_wasClone && !E::AutoClone)          s_clone = Learned{};
        s_wasHatch = E::HatchIncubatorEggs;
        s_wasClone = E::AutoClone;
        SaveLevels(now);

        if (!AnyOn() || !Valid(controller) || !Valid(localActor) || !EngineRefs::Ready()) return;
        if (!EngineRefs::g_refs.pcServerMultiUse) return;
        static uint64_t s_nextScan = 0;
        if (now >= s_nextScan)
        {
            s_nextScan = now + kScanMs;
            Scan(localActor);
        }

        UObject* pc = reinterpret_cast<UObject*>(controller);
        static std::vector<Item> mine;
        if (E::AutoSaddle || E::AutoImprint || E::AutoFillCloning || E::TransferEggsIncubator)
            MyItems(localActor, mine);

        s_why = Why{};
        for (const Dino& d : s_dinos)
        {
            if (IsMine(d, localTribeID)) ++s_why.mine;
            if (d.baby) ++s_why.babies;
        }
        s_why.eggsGround = (int)s_eggs.size();

        if (E::AutoSaddle)            DoSaddle(pc, localTribeID, mine, now);
        if (E::AutoImprint)           DoImprint(localActor, localTribeID, mine, now);
        if (E::AutoNameDino)          DoName(pc, localTribeID, now);
        if (E::AutoClaim)             DoClaim(now);
        if (E::AutoNeuter)            DoNeuter(localTribeID, now);
        if (E::AutoLevel)             DoLevel(pc, localTribeID, now);
        if (E::AutoClone)             DoClone(pc, localTribeID, now);
        if (E::AutoFillCloning)       DoFillChamber(pc, mine, now);
        if (E::AutoPickupEggs)        DoPickupEggs(now);
        if (E::TransferEggsIncubator) DoTransferEggs(pc, mine, now);
        if (E::HatchIncubatorEggs)    DoHatch(pc, now);
        FlushUses(pc, now);

        // Every 5 s while any switch is on: what was sent, and why a quiet
        // feature is quiet.
        static uint64_t s_lastStatus = 0;
        if (now - s_lastStatus >= kStatusMs)
        {
            s_lastStatus = now;
            char line[1024];
            int n = snprintf(line, sizeof(line), "[Breeding] tribe %d | dinos near %d, yours %d, babies %d |",
                             localTribeID, (int)s_dinos.size(), s_why.mine, s_why.babies);
            auto add = [&](const char* fmt, auto... a)
            {
                if (n > 0 && n < (int)sizeof(line)) n += snprintf(line + n, sizeof(line) - n, fmt, a...);
            };
            if (E::AutoSaddle)   add(" saddle sent %d (unsaddled in reach %d, equipping %d, no fitting saddle %d, saddled %d, too far %d, saddles on you %d)",
                                     s_count[ActSaddle], s_why.saddleNeed, s_why.saddleEquipping, s_why.saddleNoFit, s_why.saddleHas, s_why.saddleFar, s_why.saddlesMine);
            if (E::AutoImprint)  add(" imprint sent %d (due %d, too far %d, walk %d, no food %d)", s_count[ActImprint],
                                     s_why.imprintDue, s_why.imprintFar, s_why.imprintWalk, s_why.imprintNoFood);
            if (E::AutoNameDino) add(" name sent %d (to name %d%s)", s_count[ActName], s_why.unnamed, !E::AutoNameText[0] ? ", NO NAME TYPED" : "");
            if (E::AutoClaim)    add(" claim sent %d (unclaimed %d)", s_count[ActClaim], s_why.unclaimed);
            if (E::AutoNeuter)   add(" neuter sent %d (not neutered %d, too far %d)", s_count[ActNeuter], s_why.neuterable, s_why.neuterFar);
            if (E::AutoLevel)    add(" level sent %d (ready %d, no points yet %d)", s_count[CntLevel], s_why.levelReady, s_why.levelNoPoints);
            if (E::AutoClone)    add(" clone sent %d (chambers within %.0fm %d, %s)", s_count[ActClone], E::AutoCloneRange, (int)s_cloneChambers.size(), CloneLearned() ? "ready" : "NOT READY");
            if (E::AutoFillCloning) add(" shards sent %d (stacks %d, chambers in reach %d)", s_count[CntShards], s_why.shardsMine, (int)s_chambers.size());
            if (E::AutoPickupEggs)  add(" eggs picked %d (in reach %d)", s_count[ActEgg], s_why.eggsGround);
            if (E::TransferEggsIncubator) add(" eggs in %d (fertile stacks %d, incubators in reach %d)", s_count[CntEggsIn], s_why.eggsMine, (int)s_incubators.size());
            if (E::HatchIncubatorEggs) add(" hatch sent %d (incubators in reach %d, %s)", s_count[ActHatch], (int)s_incubators.size(), HatchLearned() ? "learned" : "NOT LEARNED - hatch one by hand");
            Logger::Log("%s", line);
            memset(s_count, 0, sizeof(s_count));
        }
    }
};

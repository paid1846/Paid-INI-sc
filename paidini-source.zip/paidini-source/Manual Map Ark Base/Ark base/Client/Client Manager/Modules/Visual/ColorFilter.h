#pragma once
// ============================================================================
// ColorFilter - NVIDIA-Freestyle-style game filter for the Store build (which
// the NVIDIA app can't hook). Every frame, before the menu is drawn, the back
// buffer is copied and redrawn through a full-screen pixel shader applying
// vibrance, saturation, contrast, brightness, gamma, temperature and sharpen.
//
// Render thread only (Present hook). All D3D state it touches is saved and
// restored, so the game and the ImGui overlay never see it.
// ============================================================================
#include <Windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <cstring>
#include "Client Manager/CheatSettings.h"

namespace ColorFilter
{
    // Settings in menu units (percent / gamma), converted in Params().
    struct Params
    {
        float vibrance;    // -1..1
        float saturation;  //  0..2
        float contrast;    //  0.5..1.5
        float brightness;  //  0.5..1.5
        float gamma;       //  0.5..2
        float temperature; // -1..1
        float sharpen;     //  0..1
        float texel_x, texel_y;
        float pad[3];
    };

    inline const char* kShader = R"(
cbuffer P : register(b0)
{
    float vibrance; float saturation; float contrast; float brightness;
    float gamma; float temperature; float sharpen; float texel_x;
    float texel_y; float3 pad;
};
Texture2D src : register(t0);
SamplerState smp : register(s0);

struct VSOut { float4 pos : SV_Position; float2 uv : TEXCOORD0; };

VSOut vs_main(uint id : SV_VertexID)
{
    VSOut o;
    o.uv = float2((id << 1) & 2, id & 2);
    o.pos = float4(o.uv * float2(2, -2) + float2(-1, 1), 0, 1);
    return o;
}

float4 ps_main(VSOut i) : SV_Target
{
    float4 base = src.Sample(smp, i.uv);
    float3 c = base.rgb;

    // sharpen: unsharp mask against the 4 direct neighbours
    if (sharpen > 0.001)
    {
        float3 blur = (src.Sample(smp, i.uv + float2(texel_x, 0)).rgb +
                       src.Sample(smp, i.uv - float2(texel_x, 0)).rgb +
                       src.Sample(smp, i.uv + float2(0, texel_y)).rgb +
                       src.Sample(smp, i.uv - float2(0, texel_y)).rgb) * 0.25;
        c += (c - blur) * sharpen * 1.5;
    }

    c *= brightness;
    c = (c - 0.5) * contrast + 0.5;

    float luma = dot(c, float3(0.2126, 0.7152, 0.0722));
    c = lerp(luma.xxx, c, saturation);

    // vibrance: boosts low-saturation colours more than already vivid ones
    float mx = max(c.r, max(c.g, c.b));
    float mn = min(c.r, min(c.g, c.b));
    float sat = mx - mn;
    luma = dot(c, float3(0.2126, 0.7152, 0.0722));
    c = lerp(luma.xxx, c, 1.0 + vibrance * (1.0 - sign(vibrance) * sat));

    c *= float3(1.0 + temperature * 0.10, 1.0 + temperature * 0.02, 1.0 - temperature * 0.10);

    c = pow(saturate(c), 1.0 / gamma);
    return float4(c, base.a);
}
)";

    inline ID3D11VertexShader*       g_vs     = nullptr;
    inline ID3D11PixelShader*        g_ps     = nullptr;
    inline ID3D11Buffer*             g_cb     = nullptr;
    inline ID3D11SamplerState*       g_smp    = nullptr;
    inline ID3D11BlendState*         g_blend  = nullptr;
    inline ID3D11RasterizerState*    g_rs     = nullptr;
    inline ID3D11DepthStencilState*  g_ds     = nullptr;
    inline ID3D11Texture2D*          g_copy   = nullptr;
    inline ID3D11ShaderResourceView* g_srv    = nullptr;
    inline UINT        g_w = 0, g_h = 0;
    inline DXGI_FORMAT g_fmt = DXGI_FORMAT_UNKNOWN;
    inline bool        g_failed = false; // shader compile failed; don't retry every frame

    template <typename T> inline void SafeRelease(T*& p) { if (p) { p->Release(); p = nullptr; } }

    inline bool IsNeutral()
    {
        const auto& s = Settings::Filter::Values;
        return s.vibrance == 0.f && s.saturation == 100.f && s.contrast == 100.f && s.brightness == 100.f &&
               s.gamma == 1.f && s.temperature == 0.f && s.sharpen == 0.f;
    }

    // True when the filter has work to do this frame.
    inline bool Active() { return Settings::Filter::Enabled && !g_failed && !IsNeutral(); }

    inline DXGI_FORMAT TypedFormat(DXGI_FORMAT f)
    {
        switch (f)
        {
        case DXGI_FORMAT_R8G8B8A8_TYPELESS:    return DXGI_FORMAT_R8G8B8A8_UNORM;
        case DXGI_FORMAT_B8G8R8A8_TYPELESS:    return DXGI_FORMAT_B8G8R8A8_UNORM;
        case DXGI_FORMAT_R10G10B10A2_TYPELESS: return DXGI_FORMAT_R10G10B10A2_UNORM;
        case DXGI_FORMAT_R16G16B16A16_TYPELESS: return DXGI_FORMAT_R16G16B16A16_FLOAT;
        default:                               return f;
        }
    }

    inline bool CreatePipeline(ID3D11Device* dev)
    {
        if (g_vs) return true;
        ID3DBlob* vsb = nullptr; ID3DBlob* psb = nullptr; ID3DBlob* err = nullptr;
        const size_t len = strlen(kShader);
        if (FAILED(D3DCompile(kShader, len, "ColorFilter", nullptr, nullptr, "vs_main", "vs_4_0", 0, 0, &vsb, &err)) ||
            FAILED(D3DCompile(kShader, len, "ColorFilter", nullptr, nullptr, "ps_main", "ps_4_0", 0, 0, &psb, &err)))
        {
            SafeRelease(vsb); SafeRelease(psb); SafeRelease(err);
            g_failed = true;
            return false;
        }
        dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs);
        dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ps);
        SafeRelease(vsb); SafeRelease(psb); SafeRelease(err);

        D3D11_BUFFER_DESC cb{}; cb.ByteWidth = sizeof(Params); cb.Usage = D3D11_USAGE_DYNAMIC;
        cb.BindFlags = D3D11_BIND_CONSTANT_BUFFER; cb.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
        dev->CreateBuffer(&cb, nullptr, &g_cb);

        D3D11_SAMPLER_DESC sd{}; sd.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
        sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP; sd.MaxLOD = D3D11_FLOAT32_MAX;
        dev->CreateSamplerState(&sd, &g_smp);

        D3D11_BLEND_DESC bd{}; bd.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
        dev->CreateBlendState(&bd, &g_blend);

        D3D11_RASTERIZER_DESC rd{}; rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.DepthClipEnable = TRUE;
        dev->CreateRasterizerState(&rd, &g_rs);

        D3D11_DEPTH_STENCIL_DESC dd{}; dd.DepthEnable = FALSE; dd.StencilEnable = FALSE;
        dev->CreateDepthStencilState(&dd, &g_ds);

        if (!g_vs || !g_ps || !g_cb || !g_smp || !g_blend || !g_rs || !g_ds) { g_failed = true; return false; }
        return true;
    }

    inline bool EnsureCopy(ID3D11Device* dev, ID3D11Texture2D* bb)
    {
        D3D11_TEXTURE2D_DESC d{};
        bb->GetDesc(&d);
        if (d.SampleDesc.Count > 1) return false; // MSAA back buffer: not supported
        if (g_copy && d.Width == g_w && d.Height == g_h && d.Format == g_fmt) return true;

        SafeRelease(g_srv); SafeRelease(g_copy);
        D3D11_TEXTURE2D_DESC cd = d;
        cd.BindFlags = D3D11_BIND_SHADER_RESOURCE; cd.Usage = D3D11_USAGE_DEFAULT;
        cd.CPUAccessFlags = 0; cd.MiscFlags = 0; cd.MipLevels = 1; cd.ArraySize = 1;
        if (FAILED(dev->CreateTexture2D(&cd, nullptr, &g_copy))) return false;

        D3D11_SHADER_RESOURCE_VIEW_DESC sv{};
        sv.Format = TypedFormat(d.Format); sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
        if (FAILED(dev->CreateShaderResourceView(g_copy, &sv, &g_srv))) { SafeRelease(g_copy); return false; }

        g_w = d.Width; g_h = d.Height; g_fmt = d.Format;
        return true;
    }

    // Filters the back buffer in place. rtv = a render target view of it.
    inline void Apply(ID3D11Device* dev, ID3D11DeviceContext* ctx, IDXGISwapChain* sc, ID3D11RenderTargetView* rtv)
    {
        if (!Active() || !CreatePipeline(dev)) return;

        ID3D11Texture2D* bb = nullptr;
        if (FAILED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb)) || !bb) return;
        const bool ok = EnsureCopy(dev, bb);
        if (ok) ctx->CopyResource(g_copy, bb);
        bb->Release();
        if (!ok) return;

        // constants
        const auto& s = Settings::Filter::Values;
        D3D11_MAPPED_SUBRESOURCE m{};
        if (FAILED(ctx->Map(g_cb, 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) return;
        Params p{};
        p.vibrance    = s.vibrance / 100.f;
        p.saturation  = s.saturation / 100.f;
        p.contrast    = s.contrast / 100.f;
        p.brightness  = s.brightness / 100.f;
        p.gamma       = s.gamma > 0.05f ? s.gamma : 1.f;
        p.temperature = s.temperature / 100.f;
        p.sharpen     = s.sharpen / 100.f;
        p.texel_x     = 1.f / (float)g_w;
        p.texel_y     = 1.f / (float)g_h;
        memcpy(m.pData, &p, sizeof(p));
        ctx->Unmap(g_cb, 0);

        // ---- save state ----
        ID3D11RenderTargetView* oRTV = nullptr; ID3D11DepthStencilView* oDSV = nullptr;
        ctx->OMGetRenderTargets(1, &oRTV, &oDSV);
        ID3D11BlendState* oBlend = nullptr; FLOAT oFactor[4]; UINT oMask = 0;
        ctx->OMGetBlendState(&oBlend, oFactor, &oMask);
        ID3D11DepthStencilState* oDS = nullptr; UINT oRef = 0;
        ctx->OMGetDepthStencilState(&oDS, &oRef);
        ID3D11RasterizerState* oRS = nullptr; ctx->RSGetState(&oRS);
        UINT oVPn = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE; D3D11_VIEWPORT oVP[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
        ctx->RSGetViewports(&oVPn, oVP);
        D3D11_PRIMITIVE_TOPOLOGY oTopo; ctx->IAGetPrimitiveTopology(&oTopo);
        ID3D11InputLayout* oIL = nullptr; ctx->IAGetInputLayout(&oIL);
        ID3D11VertexShader* oVS = nullptr; ctx->VSGetShader(&oVS, nullptr, nullptr);
        ID3D11PixelShader* oPS = nullptr; ctx->PSGetShader(&oPS, nullptr, nullptr);
        ID3D11ShaderResourceView* oSRV = nullptr; ctx->PSGetShaderResources(0, 1, &oSRV);
        ID3D11SamplerState* oSmp = nullptr; ctx->PSGetSamplers(0, 1, &oSmp);
        ID3D11Buffer* oCB = nullptr; ctx->PSGetConstantBuffers(0, 1, &oCB);

        // ---- draw ----
        D3D11_VIEWPORT vp{ 0.f, 0.f, (float)g_w, (float)g_h, 0.f, 1.f };
        ctx->OMSetRenderTargets(1, &rtv, nullptr);
        const FLOAT zero[4] = { 0, 0, 0, 0 };
        ctx->OMSetBlendState(g_blend, zero, 0xFFFFFFFF);
        ctx->OMSetDepthStencilState(g_ds, 0);
        ctx->RSSetState(g_rs);
        ctx->RSSetViewports(1, &vp);
        ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        ctx->IASetInputLayout(nullptr);
        ctx->VSSetShader(g_vs, nullptr, 0);
        ctx->PSSetShader(g_ps, nullptr, 0);
        ctx->PSSetShaderResources(0, 1, &g_srv);
        ctx->PSSetSamplers(0, 1, &g_smp);
        ctx->PSSetConstantBuffers(0, 1, &g_cb);
        ctx->Draw(3, 0);

        // ---- restore state ----
        ID3D11ShaderResourceView* nullSRV = nullptr;
        ctx->PSSetShaderResources(0, 1, oSRV ? &oSRV : &nullSRV);
        ctx->PSSetSamplers(0, 1, &oSmp);
        ctx->PSSetConstantBuffers(0, 1, &oCB);
        ctx->PSSetShader(oPS, nullptr, 0);
        ctx->VSSetShader(oVS, nullptr, 0);
        ctx->IASetInputLayout(oIL);
        ctx->IASetPrimitiveTopology(oTopo);
        ctx->RSSetViewports(oVPn, oVP);
        ctx->RSSetState(oRS);
        ctx->OMSetDepthStencilState(oDS, oRef);
        ctx->OMSetBlendState(oBlend, oFactor, oMask);
        ctx->OMSetRenderTargets(1, &oRTV, oDSV);

        SafeRelease(oRTV); SafeRelease(oDSV); SafeRelease(oBlend); SafeRelease(oDS); SafeRelease(oRS);
        SafeRelease(oIL); SafeRelease(oVS); SafeRelease(oPS); SafeRelease(oSRV); SafeRelease(oSmp); SafeRelease(oCB);
    }

    inline void Shutdown()
    {
        SafeRelease(g_srv); SafeRelease(g_copy);
        SafeRelease(g_vs); SafeRelease(g_ps); SafeRelease(g_cb); SafeRelease(g_smp);
        SafeRelease(g_blend); SafeRelease(g_rs); SafeRelease(g_ds);
        g_w = g_h = 0; g_fmt = DXGI_FORMAT_UNKNOWN;
    }
}

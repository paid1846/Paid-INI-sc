#pragma once
#include <Global.h>
#include "Client Manager/Modules/Engine/EngineRefs.h"

// ============================================================================
//  Stalker Vision - adds ARK's own ESPMaterialOutline post-process material
//  (as a dynamic instance) to the level's active PostProcessVolume, with
//  ESPDepth set from the distance slider, and turns off the low-health
//  screen shading on the camera. Ported from a friend's StalkerIni.
//
//  Game thread only (DrawHUD hook): it calls ProcessEvent and edits an
//  engine array. Offsets verified against the Store build.
// ============================================================================

namespace StalkerVision
{
    constexpr uintptr_t kVolBlendables   = 0x07F0; // APostProcessVolume Settings.WeightedBlendables array
    constexpr uintptr_t kVolFlags        = 0x0828; // bit0 bEnabled, bit1 bUnbound
    constexpr uintptr_t kCamIgnoreHealth = 0x1851; // camera manager: skip low-health shading
    constexpr ULONGLONG kCreateRetryMs   = 500;

    struct Arr { UObject** Data; int32_t Count; int32_t Max; };

    inline UObject*  s_mid        = nullptr;
    inline int32_t   s_midIdx     = -1;
    inline int32_t   s_midSerial  = 0;
    inline UObject*  s_midClass   = nullptr;
    inline UObject*  s_volume     = nullptr;
    inline UWorld*   s_world      = nullptr;
    inline float     s_appliedDist = 0.f;
    inline uint8_t   s_camOrig    = 0xFF; // 0xFF = not overridden
    inline ULONGLONG s_lastCreate = 0;

    inline bool Valid(const void* p) { return reinterpret_cast<uintptr_t>(p) >= 0x10000; }

    inline void SetScalar(int32_t nameIdx, float value)
    {
        if (!s_mid || nameIdx <= 0) return;
        struct { FName ParameterName; float Value; } p{ FName(nameIdx), value };
        UObject::ProcessEvent(s_mid, EngineRefs::g_refs.midSetScalar, &p);
    }

    inline void SetVector(int32_t nameIdx, float r, float g, float b, float a)
    {
        if (!s_mid || nameIdx <= 0) return;
        struct { FName ParameterName; float R, G, B, A; } p{ FName(nameIdx), r, g, b, a };
        UObject::ProcessEvent(s_mid, EngineRefs::g_refs.midSetVector, &p);
    }

    inline void IgnoreHealthShading(bool on)
    {
        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        uint8_t* cam = pc ? reinterpret_cast<uint8_t*>(pc->PlayerCameraManager) : nullptr;
        if (!Valid(cam)) return;
        uint8_t& flag = cam[kCamIgnoreHealth];
        if (on)
        {
            if (s_camOrig == 0xFF) s_camOrig = flag;
            if (flag != 1) flag = 1;
        }
        else if (s_camOrig != 0xFF)
        {
            flag = s_camOrig;
            s_camOrig = 0xFF;
        }
    }

    // The MID is only kept alive by the volume's blendables array; confirm the
    // GObjects slot still holds the same object (index + serial + class).
    inline bool MidAlive()
    {
        if (!s_mid || s_midIdx < 0) return false;
        auto& objs = UObject::GetGlobalObjects();
        if (s_midIdx >= objs.Count()) return false;
        FUObjectItem* item = objs.GetItemByIndex(s_midIdx);
        if (!item || item->Object != s_mid) return false;
        if (s_midSerial && item->SerialNumber != s_midSerial) return false;
        return reinterpret_cast<UObject*>(s_mid->Class) == s_midClass;
    }

    // Prefer the unbound (global) volume; otherwise the first enabled one.
    inline UObject* FindVolume()
    {
        UWorld* world = UWorld::Get();
        ULevel* level = world ? world->PersistentLevel : nullptr;
        if (!Valid(level)) return nullptr;
        auto& actors = level->Actors;
        const int32_t count = actors.Count();
        if (count <= 0 || count > 200000) return nullptr;

        UClass* cls = EngineRefs::g_refs.clsPostProcessVolume;
        UObject* fallback = nullptr;
        for (int32_t i = 0; i < count; ++i)
        {
            UObject* a = reinterpret_cast<UObject*>(actors[i]);
            if (!Valid(a) || !a->IsA(cls)) continue;
            const uint8_t flags = reinterpret_cast<const uint8_t*>(a)[kVolFlags];
            if (!(flags & 0x01)) continue;
            if (flags & 0x02) return a;
            if (!fallback) fallback = a;
        }
        return fallback;
    }

    inline Arr* VolumeBlendables()
    {
        if (!s_volume) s_volume = FindVolume();
        if (!s_volume) return nullptr;
        Arr* arr = reinterpret_cast<Arr*>(reinterpret_cast<uint8_t*>(s_volume) + kVolBlendables);
        if (arr->Count < 0 || arr->Count > 64 || arr->Max < arr->Count) return nullptr;
        if (arr->Max > 0 && !Valid(arr->Data)) return nullptr;
        return arr;
    }

    inline bool EnsureMID(AActor* self)
    {
        if (s_mid) return true;
        const auto& r = EngineRefs::g_refs;
        struct { UObject* WorldContextObject; UObject* Parent; UObject* ReturnValue; } p{ reinterpret_cast<UObject*>(self), r.matESPOutline, nullptr };
        UObject::ProcessEvent(r.kismetMaterialCDO, r.kismetCreateMID, &p);
        if (!Valid(p.ReturnValue)) return false;

        s_mid       = p.ReturnValue;
        s_midIdx    = s_mid->InternalIndex;
        s_midClass  = reinterpret_cast<UObject*>(s_mid->Class);
        s_midSerial = 0;
        auto& objs = UObject::GetGlobalObjects();
        FUObjectItem* item = (s_midIdx >= 0 && s_midIdx < objs.Count()) ? objs.GetItemByIndex(s_midIdx) : nullptr;
        if (!item || item->Object != s_mid) { s_mid = nullptr; return false; }
        s_midSerial = item->SerialNumber;

        s_appliedDist = Settings::Ini::StalkerDist;
        SetScalar(r.nameESPFillIntensity, 0.f);
        SetScalar(r.nameESPDepth, Settings::Ini::StalkerDist * 100.f);
        SetVector(r.nameBackgroundColor, 0.f, 0.f, 0.f, 0.f);
        return true;
    }

    // Appends in place; never reallocates the engine's array.
    inline void Push()
    {
        Arr* arr = VolumeBlendables();
        if (!arr) return;
        for (int32_t i = 0; i < arr->Count; ++i)
            if (arr->Data[i] == s_mid) return;
        if (arr->Count >= arr->Max) return;
        arr->Data[arr->Count++] = s_mid;
    }

    inline void Pull()
    {
        Arr* arr = (s_mid && MidAlive()) ? VolumeBlendables() : nullptr;
        if (arr)
        {
            for (int32_t i = 0; i < arr->Count; ++i)
            {
                if (arr->Data[i] != s_mid) continue;
                for (int32_t j = i; j + 1 < arr->Count; ++j) arr->Data[j] = arr->Data[j + 1];
                --arr->Count;
                break;
            }
        }
        s_volume = nullptr;
    }

    // Fully off: material out of the volume, camera flag restored.
    inline void Disable()
    {
        if (s_volume) Pull();
        IgnoreHealthShading(false);
    }

    inline bool IsRestored() { return !s_volume && s_camOrig == 0xFF; }

    // Call every frame from the game thread (SEH-guarded by the caller).
    inline void Tick()
    {
        UWorld* world = UWorld::Get();
        if (world != s_world) { s_world = world; s_mid = nullptr; s_volume = nullptr; }
        if (s_mid && !MidAlive()) { s_mid = nullptr; s_volume = nullptr; }

        if (!Settings::Ini::StalkerVision)
        {
            Disable();
            return;
        }

        EngineRefs::RequestStalkerRefs();
        if (!EngineRefs::StalkerReady()) return;

        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        AActor* self = pc ? reinterpret_cast<AActor*>(pc->AcknowledgedPawn) : nullptr;
        if (!Valid(self)) return;

        const ULONGLONG now = GetTickCount64();
        if (!s_mid && now - s_lastCreate >= kCreateRetryMs)
        {
            s_lastCreate = now;
            EnsureMID(self);
        }
        if (!s_mid || !MidAlive()) { s_mid = nullptr; return; }

        if (s_appliedDist != Settings::Ini::StalkerDist)
        {
            s_appliedDist = Settings::Ini::StalkerDist;
            SetScalar(EngineRefs::g_refs.nameESPDepth, s_appliedDist * 100.f);
        }
        Push();
        IgnoreHealthShading(true);
    }
}

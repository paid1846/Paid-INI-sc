#pragma once
#include <Global.h>
// framework ImGui (1.91.3) via include dirs, NOT Client/ImGui
#include "imgui.h"

// ============================================================================
//  Ini Presets - graphics-quality toggles (view mode + engine show flags),
//  applied straight through ULocalPlayer::Get()->ViewportClient every frame.
//
//  Self-contained: draws the toggles (Draw), applies them to the viewport
//  (Apply, called every frame so the effect persists with the menu closed),
//  and restores the original viewport state on eject (Restore).
// ============================================================================

namespace IniPresets
{
    inline int32_t          s_origViewMode  = 0;
    inline FEngineShowFlags s_origShowFlags = {};
    inline bool             s_captured      = false;
    inline bool             s_applied       = false;

    // Draws the checkboxes. Call from inside an ImGui window while the menu
    // is open.
    inline void Draw()
    {
        if (ImGui::Checkbox("Normal", &Settings::Ini::Normal) && Settings::Ini::Normal)
            Settings::Ini::Hard = Settings::Ini::Potato = false;
        if (ImGui::Checkbox("Hard", &Settings::Ini::Hard) && Settings::Ini::Hard)
            Settings::Ini::Normal = Settings::Ini::Potato = false;
        if (ImGui::Checkbox("Potato", &Settings::Ini::Potato) && Settings::Ini::Potato)
            Settings::Ini::Normal = Settings::Ini::Hard = false;
        ImGui::Checkbox("Full Bright",      &Settings::Ini::FullBright);
        ImGui::Checkbox("No XZ",            &Settings::Ini::NoXZ);
        ImGui::Checkbox("No Rock/Trees",    &Settings::Ini::NoRockTrees);
        ImGui::Checkbox("Remove Particles", &Settings::Ini::RemoveParticles);
        ImGui::Checkbox("No Fog",           &Settings::Ini::NoFog);
        ImGui::Checkbox("No Landscape",     &Settings::Ini::NoLandscape);
    }

    // Applies the current toggle state to the local player's viewport client.
    // Call every frame from the game thread (DrawHUD hook) so the effect
    // persists with the menu closed. No-ops safely if there's no local
    // player yet (main menu / loading screen).
    inline void Apply()
    {
        // Fast path: nothing toggled and nothing ever written — skip the
        // ULocalPlayer scan entirely (this runs every frame).
        const bool anyOn = Settings::Ini::Normal || Settings::Ini::Hard ||
            Settings::Ini::Potato || Settings::Ini::FullBright ||
            Settings::Ini::NoXZ || Settings::Ini::NoRockTrees ||
            Settings::Ini::RemoveParticles || Settings::Ini::NoFog ||
            Settings::Ini::NoLandscape || Settings::Ini::NoWater;
        if (!anyOn && !s_applied)
            return;

        // Log the first time any toggle fires so we can confirm SyncCfgToSettings worked.
        static bool s_loggedFirstFire = false;
        if (!s_loggedFirstFire)
        {
            s_loggedFirstFire = true;
            Logger::Log("[IniPresets] first Apply with anyOn=true: Normal=%d Hard=%d Potato=%d FullBright=%d NoXZ=%d NoRockTrees=%d RemoveParticles=%d NoFog=%d NoLandscape=%d NoWater=%d",
                (int)Settings::Ini::Normal, (int)Settings::Ini::Hard,
                (int)Settings::Ini::Potato, (int)Settings::Ini::FullBright,
                (int)Settings::Ini::NoXZ, (int)Settings::Ini::NoRockTrees,
                (int)Settings::Ini::RemoveParticles, (int)Settings::Ini::NoFog,
                (int)Settings::Ini::NoLandscape, (int)Settings::Ini::NoWater);
        }

        ULocalPlayer* lp = ULocalPlayer::Get();
        if (!lp)
        {
            static bool s_loggedNoLP = false;
            if (!s_loggedNoLP) { s_loggedNoLP = true; Logger::Log("[IniPresets] ULocalPlayer::Get() returned null — GWorld not found or not in-game yet"); }
            return;
        }
        if (!lp->ViewportClient)
        {
            static bool s_loggedNoVC = false;
            if (!s_loggedNoVC) { s_loggedNoVC = true; Logger::Log("[IniPresets] ViewportClient is null — ULocalPlayer offset may be wrong"); }
            return;
        }
        UGameViewportClient* vc = lp->ViewportClient;

        if (!s_captured)
        {
            s_origViewMode  = vc->ViewModeIndex;
            s_origShowFlags = vc->EngineShowFlags;
            s_captured = true;
            Logger::Log("[IniPresets] captured originals: ViewModeIndex=%d", s_origViewMode);
        }

        // Build the final state in locals and store each field only when it
        // differs. Writing the originals back and then the preset every frame
        // let the renderer catch the original values mid-update, flipping the
        // view mode / show flags on and off - every flip rebuilds engine
        // render state (visibility, shaders), which showed up as stutters.
        int32_t          mode  = s_origViewMode;
        FEngineShowFlags flags = s_origShowFlags;

        if (anyOn)
        {
            if (Settings::Ini::Normal)      mode = 3;
            else if (Settings::Ini::Hard)   mode = 1;
            else if (Settings::Ini::Potato) mode = 0;

            // ARK's in-game "fullbright" is the Tonemapper flag; the Lighting
            // flag is ignored by the game viewport.
            if (Settings::Ini::FullBright)      flags.Tonemapper = false;
            if (Settings::Ini::NoXZ)            flags.PostProcessMaterial = false;
            if (Settings::Ini::NoRockTrees)     flags.InstancedStaticMeshes = false;
            if (Settings::Ini::RemoveParticles) flags.Particles = false;
            if (Settings::Ini::NoFog)           flags.Fog = false;
            if (Settings::Ini::NoLandscape)     flags.Landscape = false;
            if (Settings::Ini::NoWater)
            {
                flags.Fog                 = false;
                flags.Atmosphere          = false;
                flags.Translucency        = false;
                flags.PostProcessMaterial = false;
            }
        }

        if (vc->ViewModeIndex != mode)
            vc->ViewModeIndex = mode;
        if (memcmp(&vc->EngineShowFlags, &flags, sizeof(flags)) != 0)
            vc->EngineShowFlags = flags;

        s_applied = anyOn;
    }

    // Puts the viewport back exactly how we found it. Call once on eject —
    // otherwise a toggle left on would still show altered graphics after
    // the DLL unloads and stops re-applying every frame.
    inline void Restore()
    {
        if (!s_captured) return;
        ULocalPlayer* lp = ULocalPlayer::Get();
        if (lp && lp->ViewportClient)
        {
            lp->ViewportClient->ViewModeIndex   = s_origViewMode;
            lp->ViewportClient->EngineShowFlags = s_origShowFlags;
        }
        s_applied  = false;
        s_captured = false;
    }
}

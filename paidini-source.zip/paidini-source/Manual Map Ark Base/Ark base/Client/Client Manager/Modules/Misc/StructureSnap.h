#pragma once
// ============================================================================
// StructureSnap - flush-snaps structures that have no native snap points
// (cryofridges, vaults, chem benches, dedicated storage, ...) into the nearest
// free side of an existing structure of the same type.
//
// HOW THE GHOST SHOWS THE SNAP
// The placer re-positions the ghost ACTOR every frame from its own trace, and
// nothing we write to the actor or its placement data survives that. What it
// never touches is the relative transform of the components under the ghost's
// root. So the root is left exactly where the game puts it and every direct
// child of the root (the StructureMesh etc.) gets a relative offset that lands
// it on the snap pose:
//     childRel = Rz(-rootYaw) * (snapPos - rootPos) + Rz(snapYaw - rootYaw) * origRel
// The root pose used is the game's own placement for this frame (captured from
// BPIsAllowedToBuild, which the placer dispatches every frame right before it
// moves the ghost) plus a measured bias, so the mesh sits on the snap with no
// lag. When the snap drops, the original relative transforms are put back.
//
// WHEN IT SNAPS
// When the game's placement (where you are looking) is at the level of a
// same-type structure - on the floor beside it, against its side or on top of
// it - and within ~1.25 structure widths of one of its free sides. The nearest
// free side wins; the last chosen side is kept while it is still close so it
// does not flicker between two. Occupied sides are skipped.
//
// COMMIT
// ServerRequestPlaceStructure carries the client's raw hit location and view
// rotation; the server re-runs placement from those. The pre-hook shifts them
// by exactly (snapped - raw) of the displayed frame, in X, Y and Z (aiming at
// the top of a fridge moves the hit point down to the floor of the free side).
//
// SIZE
// Structure roots are bare SceneComponents (zero bounds); the footprint comes
// from the StructureMesh child's world AABB, solved back to the mesh's local
// half-extents with its yaw. Spacing 0.00 m = meshes touching.
//
// THREADING: everything here runs on the game thread (ProcessEvent hook and
// the DrawHUD hook).
// ============================================================================
#include <Global.h>
#include <cmath>
#include <cfloat>
#include <cstdio>
#include <vector>
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Misc/QuickPickup.h"            // PropOffset, GameFocused
#include "Client Manager/Modules/HUD/ArmorHud.h"                 // Valid()
#include "Client Manager/Modules/UI/Input Bridge/InputBridge.h"

namespace StructureSnap
{
    // USceneComponent (Store build): ComponentToWorld rotation quat / translation,
    // Bounds (FBoxSphereBounds), AttachChildren, RelativeLocation / Rotation.
    inline constexpr uintptr_t OFF_C2W_ROT         = 0x00E0;
    inline constexpr uintptr_t OFF_C2W_POS         = 0x00F0;
    inline constexpr uintptr_t OFF_BOUNDS_ORIGIN   = 0x0118;
    inline constexpr uintptr_t OFF_BOUNDS_EXTENT   = 0x0118 + 0x0C;
    inline constexpr uintptr_t OFF_ATTACH_CHILDREN = 0x0148;
    inline constexpr uintptr_t OFF_REL_LOC         = 0x0158;
    inline constexpr uintptr_t OFF_REL_ROT         = 0x0164;
    inline constexpr uintptr_t OFF_ROOT            = 0x0268;

    inline constexpr float kPi = 3.14159265f;

    struct V3 { float x, y, z; };
    struct R3 { float pitch, yaw, roll; };

    // ---- state ---------------------------------------------------------------
    struct Snap
    {
        bool      valid = false;
        V3        raw{};     float rawYaw  = 0.f;   // the game's placement this frame
        V3        pos{};     float yaw     = 0.f;   // the snap pose shown / committed
        ULONGLONG stamp = 0;
    };
    inline Snap g_snap;

    inline int       g_rotSteps   = 0;       // Left / Right arrow, 90 degrees each
    inline void*     g_ghost      = nullptr; // current preview (from the placer)
    inline void*     g_ghostClass = nullptr;
    inline bool      g_snappable  = false;   // ghost class has no native snap points
    inline wchar_t   g_name[64]   = L"";     // DescriptiveName of the ghost

    // Root pose bias: actual ghost root (read in DrawHUD) minus the game's
    // placement data. Normally zero; measured so the mesh offset stays exact.
    inline V3    g_rootBias{};
    inline float g_rootYawBias = 0.f;

    // Last chosen side (hysteresis).
    inline bool g_haveLast = false;
    inline V3   g_lastSlot{};

    // Reflection offsets, resolved lazily.
    inline uint32_t g_offPlacer = 0, g_offPlacing = 0, g_offSnapPoints = 0, g_offDescName = 0;
    inline void*    g_pcClass = nullptr;
    inline void*    g_placerClass = nullptr;

    // Parameter offsets.
    inline int32_t  g_pOutData = -1;
    inline int32_t  g_pBuildLoc = -1, g_pBuildRot = -1, g_pViewRot = -1, g_pSnapped = -1, g_pSnapCycle = -1;
    inline int32_t  g_nameAllowed = -1;      // FName index of "BPIsAllowedToBuild"
    inline bool     g_loggedPlaceSeen = false;

    inline bool Ptr(const void* p)
    {
        const uintptr_t v = reinterpret_cast<uintptr_t>(p);
        return v > 0x10000 && v < 0x7FFFFFFFFFFF;
    }
    template <typename T> inline T& At(const void* base, uintptr_t off)
    {
        return *reinterpret_cast<T*>(reinterpret_cast<uintptr_t>(base) + off);
    }

    inline float NormYaw(float y)
    {
        y = fmodf(y, 360.f);
        if (y > 180.f)  y -= 360.f;
        if (y < -180.f) y += 360.f;
        return y;
    }

    inline float SpacingCm() { return Settings::Misc::SnapSpacing * 100.f; }

    // Offset of a function parameter (UFunction children; offsets start at 0).
    inline int32_t ParamOffset(UFunction* fn, const char* name)
    {
        int guard = 0;
        for (UField* f = reinterpret_cast<UStruct*>(fn)->Children; Ptr(f) && guard++ < 64; f = f->Next)
            if (f->GetName() == name)
                return static_cast<int32_t>(reinterpret_cast<UProperty*>(f)->Offset);
        return -1;
    }

    inline int32_t NameIndex(const void* obj) { return At<int32_t>(obj, 0x18); }

    // ---- geometry --------------------------------------------------------------
    inline V3 WorldPos(const void* comp) { const float* t = &At<float>(comp, OFF_C2W_POS); return { t[0], t[1], t[2] }; }

    inline float WorldYaw(const void* comp)
    {
        const float* q = &At<float>(comp, OFF_C2W_ROT); // x y z w
        const float siny = 2.f * (q[3] * q[2] + q[0] * q[1]);
        const float cosy = 1.f - 2.f * (q[1] * q[1] + q[2] * q[2]);
        return atan2f(siny, cosy) * 180.f / kPi;
    }

    inline void* RootOf(const void* actor)
    {
        void* rc = At<void*>(actor, OFF_ROOT);
        return Ptr(rc) ? rc : nullptr;
    }

    // Footprint in the ROOT frame: hx along the root's forward, hy along its right.
    // zBot / zTop: mesh bottom and top relative to the root's Z.
    struct Footprint { float hx = 0.f, hy = 0.f, hz = 0.f, zBot = 0.f, zTop = 0.f; bool ok = false; };

    inline bool IsStaticMeshComp(const UObject* c)
    {
        static void* s_yes[16] = {}; static void* s_no[32] = {};
        static int nYes = 0, nNo = 0;
        for (int i = 0; i < nYes; i++) if (s_yes[i] == c->Class) return true;
        for (int i = 0; i < nNo; i++)  if (s_no[i]  == c->Class) return false;
        bool yes = false;
        int depth = 0;
        for (UStruct* s = c->Class; Ptr(s) && depth < 12; s = s->SuperField, depth++)
            if (s->GetName() == "StaticMeshComponent") { yes = true; break; }
        if (yes) { if (nYes < 16) s_yes[nYes++] = c->Class; }
        else     { if (nNo < 32)  s_no[nNo++]   = c->Class; }
        return yes;
    }

    // The biggest static mesh under the root (depth 2) - the StructureMesh.
    inline const void* MainMesh(const void* root)
    {
        const void* best = nullptr;
        float bestArea = 0.f;
        auto consider = [&](const void* c) {
            if (!Ptr(c) || !IsStaticMeshComp(reinterpret_cast<const UObject*>(c))) return;
            const float* e = &At<float>(c, OFF_BOUNDS_EXTENT);
            const float area = e[0] * e[1];
            if (area > bestArea && e[0] < 5000.f && e[1] < 5000.f) { bestArea = area; best = c; }
        };
        const TArray<void*>& kids = At<TArray<void*>>(root, OFF_ATTACH_CHILDREN);
        const int n = kids.Count();
        for (int i = 0; i < n && i < 64; i++)
        {
            const void* c = kids.Data()[i];
            consider(c);
            if (!Ptr(c)) continue;
            const TArray<void*>& kids2 = At<TArray<void*>>(c, OFF_ATTACH_CHILDREN);
            const int m = kids2.Count();
            for (int j = 0; j < m && j < 64; j++) consider(kids2.Data()[j]);
        }
        return best;
    }

    inline Footprint MeasureActor(const void* actor)
    {
        Footprint fp;
        const void* root = RootOf(actor);
        if (!root) return fp;
        const void* mesh = MainMesh(root);
        if (!mesh) return fp;

        const float* e = &At<float>(mesh, OFF_BOUNDS_EXTENT);
        const float meshYaw = WorldYaw(mesh) * kPi / 180.f;
        const float c = fabsf(cosf(meshYaw)), s = fabsf(sinf(meshYaw));
        const float det = c * c - s * s;
        if (fabsf(det) < 0.3f) return fp;             // too close to 45 deg to solve
        const float lx = (c * e[0] - s * e[1]) / det; // mesh-local half extents
        const float ly = (c * e[1] - s * e[0]) / det;
        if (!(lx > 1.f && ly > 1.f)) return fp;

        const float rel = (WorldYaw(mesh) - WorldYaw(root)) * kPi / 180.f;
        const float cr = fabsf(cosf(rel)), sr = fabsf(sinf(rel));
        fp.hx = cr * lx + sr * ly;
        fp.hy = sr * lx + cr * ly;
        fp.hz = e[2];
        const float originZ = At<float>(mesh, OFF_BOUNDS_ORIGIN + 8);
        const float rootZ   = WorldPos(root).z;
        fp.zBot = originZ - e[2] - rootZ;
        fp.zTop = originZ + e[2] - rootZ;
        fp.ok = true;
        return fp;
    }

    // Cached per class (same class, same mesh). Measured from whichever actor
    // gives a well-conditioned solve first.
    struct FpEntry { void* cls; Footprint fp; };
    inline FpEntry g_fp[32];
    inline int     g_fpCount = 0;

    inline const Footprint* CachedFootprint(void* cls)
    {
        for (int i = 0; i < g_fpCount; i++) if (g_fp[i].cls == cls) return &g_fp[i].fp;
        return nullptr;
    }
    inline void StoreFootprint(void* cls, const Footprint& fp)
    {
        if (!fp.ok || CachedFootprint(cls)) return;
        if (g_fpCount < 32) g_fp[g_fpCount++] = { cls, fp };
        Logger::Log("[StructureSnap] footprint %.1f x %.1f cm, height %.1f", fp.hx * 2.f, fp.hy * 2.f, fp.zTop - fp.zBot);
    }

    // ---- same-class structures near the player --------------------------------
    // Positions are read once per refresh (placed structures do not move), so
    // the per-frame solve is plain arithmetic.
    struct Cand { void* actor; V3 p; float yaw; };
    inline std::vector<Cand> g_cands;
    inline std::vector<Cand> g_near;      // per-solve subset around the aim
    inline void*             g_candClass = nullptr;
    inline ULONGLONG         g_candStamp = 0;

    inline void RefreshCandidates(void* cls, const void* ghost)
    {
        const ULONGLONG now = GetTickCount64();
        if (cls == g_candClass && now - g_candStamp < 500) return;
        g_candClass = cls;
        g_candStamp = now;
        g_cands.clear();

        UWorld* world = UWorld::Get();
        if (!world || !Ptr(world->PersistentLevel)) return;
        TArray<AActor*>& actors = world->PersistentLevel->Actors;
        const int count = actors.Count();
        if (count <= 0 || count > 400000) return;
        for (int i = 0; i < count; i++)
        {
            const UObject* a = reinterpret_cast<const UObject*>(actors[i]);
            if (!Ptr(a) || a == ghost || a->Class != cls) continue;
            const void* r = RootOf(a);
            if (!r) continue;
            g_cands.push_back({ const_cast<UObject*>(a), WorldPos(r), WorldYaw(r) });
        }
    }

    // ---- the snap itself ------------------------------------------------------
    // Given the game's unsnapped placement, find the free side the player is
    // aiming at. Returns false (leave the ghost alone) otherwise.
    inline bool Solve(const void* ghost, const V3& raw, V3& outPos, float& outYaw)
    {
        void* cls = reinterpret_cast<const UObject*>(ghost)->Class;
        RefreshCandidates(cls, ghost);
        if (g_cands.empty()) return false;

        const Footprint* fp = CachedFootprint(cls);
        if (!fp)
        {
            StoreFootprint(cls, MeasureActor(ghost));
            for (size_t i = 0; !CachedFootprint(cls) && i < g_cands.size() && i < 16; i++)
                StoreFootprint(cls, MeasureActor(g_cands[i].actor));
            fp = CachedFootprint(cls);
            if (!fp) return false;
        }

        const bool  rotOdd = (g_rotSteps & 1) != 0;
        const float gap    = SpacingCm();
        const float minW   = 2.f * (fp->hx < fp->hy ? fp->hx : fp->hy);
        const float maxW   = 2.f * (fp->hx > fp->hy ? fp->hx : fp->hy);
        const float accept = 1.25f * maxW + (gap > 0.f ? gap : 0.f);
        const float stackH = (fp->zTop - fp->zBot) > 20.f ? (fp->zTop - fp->zBot) : 100.f;
        const float zTol   = 60.f;
        const float occR2  = (0.5f * minW) * (0.5f * minW);
        const float near2  = (accept + maxW + 200.f) * (accept + maxW + 200.f);

        // Only structures around the aim take part (occupancy included).
        const float occNear2 = (sqrtf(near2) + maxW + gap + 50.f) * (sqrtf(near2) + maxW + gap + 50.f);
        g_near.clear();
        for (const Cand& c : g_cands)
        {
            const float dx = c.p.x - raw.x, dy = c.p.y - raw.y;
            if (dx * dx + dy * dy < occNear2) g_near.push_back(c);
        }
        if (g_near.empty()) { g_haveLast = false; return false; }

        auto occupied = [&](const void* skip, float sx, float sy, float sz) {
            for (const Cand& o : g_near)
            {
                if (o.actor == skip) continue;
                const float ox = o.p.x - sx, oy = o.p.y - sy;
                if (ox * ox + oy * oy < occR2 && fabsf(o.p.z - sz) < zTol) return true;
            }
            return false;
        };

        float bestScore = accept * accept;
        bool  found     = false;
        V3    bestSlot{};

        for (const Cand& c : g_near)
        {
            void* n = c.actor;
            const V3 pn = c.p;
            const float dx0 = pn.x - raw.x, dy0 = pn.y - raw.y;
            if (dx0 * dx0 + dy0 * dy0 > near2) continue;
            // Placement at this structure's level: its floor, its side, or its top.
            if (raw.z < pn.z - zTol || raw.z > pn.z + stackH + zTol) continue;

            const float yawN = c.yaw;
            const float yr = yawN * kPi / 180.f;
            const float fx = cosf(yr), fy = sinf(yr);   // neighbour forward
            const float rx = -fy,      ry = fx;         // neighbour right

            for (int k = 0; k < 4; k++)
            {
                const bool  alongFwd = k < 2;
                const float sign     = (k & 1) ? -1.f : 1.f;
                const float ax = (alongFwd ? fx : rx) * sign, ay = (alongFwd ? fy : ry) * sign;
                const float hN   = alongFwd ? fp->hx : fp->hy;
                const float hNew = (alongFwd != rotOdd) ? fp->hx : fp->hy;
                const float d    = hN + hNew + gap;
                const float sx = pn.x + ax * d, sy = pn.y + ay * d;

                const float ddx = sx - raw.x, ddy = sy - raw.y;
                float score = ddx * ddx + ddy * ddy;
                // Keep the current side while it is still a candidate (no flicker).
                if (g_haveLast && fabsf(sx - g_lastSlot.x) < 5.f && fabsf(sy - g_lastSlot.y) < 5.f &&
                    fabsf(pn.z - g_lastSlot.z) < 5.f)
                    score *= 0.6f;
                if (score >= bestScore) continue;
                if (occupied(n, sx, sy, pn.z)) continue;   // side already taken

                bestScore = score;
                found     = true;
                bestSlot  = { sx, sy, pn.z };
                outYaw    = NormYaw(yawN + 90.f * g_rotSteps);
            }
        }
        if (!found) { g_haveLast = false; return false; }
        g_haveLast = true;
        g_lastSlot = bestSlot;
        outPos     = bestSlot;   // on the neighbour's floor
        return true;
    }

    // ---- smoothing ---------------------------------------------------------------
    struct Vis { bool active = false; V3 pos{}; float yaw = 0.f; };
    inline Vis    g_vis;                     // pose the ghost's meshes are shown at
    inline double g_visTime = 0.0;
    inline constexpr float kEaseRate = 22.f; // 1/s - settles in ~0.15 s

    inline double NowSeconds()
    {
        static LARGE_INTEGER s_freq{};
        if (!s_freq.QuadPart) QueryPerformanceFrequency(&s_freq);
        LARGE_INTEGER t;
        QueryPerformanceCounter(&t);
        return static_cast<double>(t.QuadPart) / static_cast<double>(s_freq.QuadPart);
    }

    // True while the arrow keys belong to the snap (turn / gap) instead of the
    // camera.
    inline volatile LONG g_wantArrows = 0;

    // ---- arrow keys off the camera --------------------------------------------
    // ARK binds the arrows as axis keys: Turn (Left -1 / Right +1) and LookUp
    // (Up -1 / Down +1). UPlayerInput keeps the bindings in AxisMappings
    // (+0xF8, TArray<FInputAxisKeyMapping>, 0x28 each: AxisName, Key, Scale
    // @0x20) and a built cache, AxisKeyMap (+0x1C8, sparse array of 0x28
    // elements: FName axis, TArray<FInputAxisKeyMapping> mappings), which is
    // what the axis values are summed from. Both are unreflected on this build;
    // offsets read live. While blocked, the four arrow mappings' Scale is 0 in
    // both, so the arrows move nothing and the mouse is untouched. Restored by
    // searching again (the cache can be rebuilt), never through stale pointers.
    inline constexpr uintptr_t OFF_PI_AXIS_MAPPINGS = 0x00F8;
    inline constexpr uintptr_t OFF_PI_AXIS_KEYMAP   = 0x01C8;

    struct ArrowOrig { int32_t axis, key; float scale; };
    inline ArrowOrig g_arrowOrig[8];
    inline int       g_arrowOrigCount = 0;
    inline bool      g_arrowsBlocked  = false;
    inline void*     g_piClass = nullptr;
    inline uint32_t  g_offPlayerInput = 0;

    inline void* PlayerInputObj()
    {
        ULocalPlayer* lp = ULocalPlayer::Get();
        const UObject* pc = lp ? reinterpret_cast<const UObject*>(lp->PlayerController) : nullptr;
        if (!Ptr(pc)) return nullptr;
        if (pc->Class != g_piClass) { g_piClass = pc->Class; g_offPlayerInput = QuickPickup::PropOffset(pc->Class, "PlayerInput"); }
        if (!g_offPlayerInput) return nullptr;
        void* pi = At<void*>(pc, g_offPlayerInput);
        return Ptr(pi) ? pi : nullptr;
    }

    inline bool IsArrowKey(int32_t key)
    {
        const auto& r = EngineRefs::g_refs;
        return key > 0 && (key == r.nameKeyLeft || key == r.nameKeyRight || key == r.nameKeyUp || key == r.nameKeyDown);
    }
    inline bool IsCameraAxis(int32_t axis)
    {
        const auto& r = EngineRefs::g_refs;
        return axis > 0 && (axis == r.nameAxisLookUp || axis == r.nameAxisTurn);
    }

    // Visit every arrow-key camera mapping (source list + built cache).
    template <typename F> inline void ForEachArrowMapping(void* pi, F&& fn)
    {
        auto visitList = [&](uint8_t* data, int n) {
            if (!Ptr(data) || n <= 0 || n > 512) return;
            for (int i = 0; i < n; i++)
            {
                uint8_t* m = data + i * 0x28;
                const int32_t axis = At<int32_t>(m, 0x00), key = At<int32_t>(m, 0x08);
                if (IsCameraAxis(axis) && IsArrowKey(key)) fn(axis, key, At<float>(m, 0x20));
            }
        };
        visitList(At<uint8_t*>(pi, OFF_PI_AXIS_MAPPINGS), At<int32_t>(pi, OFF_PI_AXIS_MAPPINGS + 8));

        uint8_t* elems = At<uint8_t*>(pi, OFF_PI_AXIS_KEYMAP);
        const int maxN = At<int32_t>(pi, OFF_PI_AXIS_KEYMAP + 8);   // ArrayNum (holes included)
        if (!Ptr(elems) || maxN <= 0 || maxN > 256) return;
        for (int i = 0; i < maxN; i++)
        {
            uint8_t* e = elems + i * 0x28;
            if (!IsCameraAxis(At<int32_t>(e, 0x00))) continue;   // holes / other axes
            visitList(At<uint8_t*>(e, 0x08), At<int32_t>(e, 0x10));
        }
    }

    inline void BlockArrows(bool block)
    {
        const auto& r = EngineRefs::g_refs;
        if (r.nameAxisTurn <= 0 || r.nameAxisLookUp <= 0 || r.nameKeyLeft <= 0) return;
        void* pi = PlayerInputObj();
        if (!pi) { if (!block) g_arrowsBlocked = false; return; }

        if (block)
        {
            // Every frame while blocked (re-applies if the cache was rebuilt).
            ForEachArrowMapping(pi, [&](int32_t axis, int32_t key, float& scale) {
                if (scale == 0.f) return;
                bool known = false;
                for (int i = 0; i < g_arrowOrigCount; i++)
                    if (g_arrowOrig[i].axis == axis && g_arrowOrig[i].key == key) { known = true; break; }
                if (!known && g_arrowOrigCount < 8) g_arrowOrig[g_arrowOrigCount++] = { axis, key, scale };
                scale = 0.f;
            });
            if (!g_arrowsBlocked) { g_arrowsBlocked = true; Logger::Log("[StructureSnap] arrow keys taken from the camera (%d mappings)", g_arrowOrigCount); }
        }
        else if (g_arrowsBlocked)
        {
            ForEachArrowMapping(pi, [&](int32_t axis, int32_t key, float& scale) {
                for (int i = 0; i < g_arrowOrigCount; i++)
                    if (g_arrowOrig[i].axis == axis && g_arrowOrig[i].key == key) { scale = g_arrowOrig[i].scale; break; }
            });
            g_arrowsBlocked = false;
        }
    }

    // ---- ghost mesh offset -------------------------------------------------------
    struct ChildOrig { void* comp; V3 loc; R3 rot; };
    inline ChildOrig g_orig[24];
    inline int       g_origCount = 0;
    inline void*     g_origGhost = nullptr;
    inline bool      g_offsetOn  = false;

    inline void SetRel(void* comp, const V3& loc, const R3& rot)
    {
        UFunction* fn = EngineRefs::g_refs.compSetRelLocRot;
        static int32_t oLoc = -2, oRot = -2;
        if (fn && oLoc == -2) { oLoc = ParamOffset(fn, "NewLocation"); oRot = ParamOffset(fn, "NewRotation"); }
        if (fn && oLoc >= 0 && oRot >= 0)
        {
            alignas(16) uint8_t buf[256] = {};   // room for any trailing out-params
            At<V3>(buf, oLoc) = loc;
            At<R3>(buf, oRot) = rot;
            UObject::ProcessEvent(comp, fn, buf);
        }
        else
        {
            At<V3>(comp, OFF_REL_LOC) = loc;     // picked up when the root next moves
            At<R3>(comp, OFF_REL_ROT) = rot;
        }
    }

    inline void CaptureOriginals(void* ghost)
    {
        if (g_origGhost == ghost) return;
        g_origGhost = ghost;
        g_origCount = 0;
        g_offsetOn  = false;
        const void* root = RootOf(ghost);
        if (!root) return;
        const TArray<void*>& kids = At<TArray<void*>>(root, OFF_ATTACH_CHILDREN);
        const int n = kids.Count();
        for (int i = 0; i < n && g_origCount < 24; i++)
        {
            void* c = kids.Data()[i];
            if (!Ptr(c)) continue;
            g_orig[g_origCount++] = { c, At<V3>(c, OFF_REL_LOC), At<R3>(c, OFF_REL_ROT) };
        }
    }

    inline void ApplyOffset(void* ghost, const V3& rootPos, float rootYaw, const V3& snapPos, float snapYaw)
    {
        CaptureOriginals(ghost);
        if (g_origCount == 0) return;

        const float ry = -rootYaw * kPi / 180.f;
        const float cr = cosf(ry), sr = sinf(ry);
        const float wx = snapPos.x - rootPos.x, wy = snapPos.y - rootPos.y;
        const V3 t{ cr * wx - sr * wy, sr * wx + cr * wy, snapPos.z - rootPos.z };  // in root space

        const float dYaw = NormYaw(snapYaw - rootYaw);
        const float dr = dYaw * kPi / 180.f;
        const float cd = cosf(dr), sd = sinf(dr);

        for (int i = 0; i < g_origCount; i++)
        {
            const ChildOrig& o = g_orig[i];
            const V3 loc{ cd * o.loc.x - sd * o.loc.y + t.x, sd * o.loc.x + cd * o.loc.y + t.y, o.loc.z + t.z };
            const R3 rot{ o.rot.pitch, NormYaw(o.rot.yaw + dYaw), o.rot.roll };
            SetRel(o.comp, loc, rot);
        }
        g_offsetOn = true;
    }

    // Put the ghost's meshes back. Only on the ghost they were taken from, and
    // only while it is still the live preview (a cancelled ghost is destroyed).
    inline void ClearOffset(void* liveGhost)
    {
        g_vis.active = false;
        if (!g_offsetOn) return;
        g_offsetOn = false;
        if (!liveGhost || liveGhost != g_origGhost) return;
        for (int i = 0; i < g_origCount; i++)
            SetRel(g_orig[i].comp, g_orig[i].loc, g_orig[i].rot);
    }

    // Last game placement seen (for easing frames with no placement update).
    inline V3     g_lastRaw{};
    inline float  g_lastRawYaw  = 0.f;
    inline V3     g_lastRootPos{};
    inline float  g_lastRootYaw = 0.f;
    inline double g_lastEval    = 0.0;

    // Snappy: the mesh goes straight to the snap the frame it is found, jumps
    // straight between sides, and straight back onto the ghost when it drops.
    inline void StepVis(void* ghost, const V3& rootPos, float rootYaw, bool snapped, const V3& sPos, float sYaw)
    {
        if (!snapped) { ClearOffset(ghost); return; }
        g_vis.active = true;
        g_vis.pos    = sPos;
        g_vis.yaw    = sYaw;
        ApplyOffset(ghost, rootPos, rootYaw, sPos, sYaw);
    }

    // ---- placer / ghost -------------------------------------------------------
    inline void* ResolveGhost()
    {
        ULocalPlayer* lp = ULocalPlayer::Get();
        const UObject* pc = lp ? reinterpret_cast<const UObject*>(lp->PlayerController) : nullptr;
        if (!Ptr(pc)) return nullptr;
        if (pc->Class != g_pcClass) { g_pcClass = pc->Class; g_offPlacer = QuickPickup::PropOffset(pc->Class, "StructurePlacer"); }
        if (!g_offPlacer) return nullptr;
        const UObject* placer = At<UObject*>(pc, g_offPlacer);
        if (!Ptr(placer)) return nullptr;
        if (placer->Class != g_placerClass)
        {
            g_placerClass = placer->Class;
            g_offPlacing = QuickPickup::PropOffset(placer->Class, "CurrentPlacingStructure");
        }
        if (!g_offPlacing) return nullptr;
        void* ghost = At<void*>(placer, g_offPlacing);
        return Ptr(ghost) ? ghost : nullptr;
    }

    inline void OnGhostClass(const UObject* ghost)
    {
        g_ghostClass = ghost->Class;
        g_rotSteps = 0;
        g_snap.valid = false;
        g_haveLast = false;

        if (!g_offSnapPoints) g_offSnapPoints = QuickPickup::PropOffset(ghost->Class, "SnapPoints");
        const int spCount = g_offSnapPoints ? At<TArray<void*>>(ghost, g_offSnapPoints).Count() : 0;
        g_snappable = spCount <= 0; // native snapping (foundations, walls...) is left alone

        g_name[0] = 0;
        if (!g_offDescName) g_offDescName = QuickPickup::PropOffset(ghost->Class, "DescriptiveName");
        if (g_offDescName)
        {
            const wchar_t* data = At<wchar_t*>(ghost, g_offDescName);
            const int cnt = At<int32_t>(ghost, g_offDescName + 8);
            if (Ptr(data) && cnt > 1 && cnt < 64) wcsncpy_s(g_name, data, _TRUNCATE);
        }
        if (!g_name[0])
        {
            const std::string n = reinterpret_cast<const UObject*>(ghost->Class)->GetName();
            swprintf_s(g_name, L"%hs", n.c_str());
        }
        Logger::Log("[StructureSnap] placing %ls (native snap points: %d)", g_name, spCount);
    }

    // ---- ProcessEvent hooks (game thread) -----------------------------------------
    inline bool IsAllowedToBuildFn(UFunction* fn)
    {
        UFunction* base = EngineRefs::g_refs.structBPIsAllowedToBuild;
        UFunction* ex   = EngineRefs::g_refs.structBPIsAllowedToBuildEx;
        if (!base) return false;
        if (fn == base || fn == ex) return true;
        static int32_t s_nameEx = -1;
        if (g_nameAllowed < 0) g_nameAllowed = NameIndex(base);
        if (ex && s_nameEx < 0) s_nameEx = NameIndex(ex);
        const int32_t n = NameIndex(fn);
        return n == g_nameAllowed || (s_nameEx >= 0 && n == s_nameEx); // BP overrides of the same events
    }

    // After the original: read the game's placement for this frame, solve, and
    // offset the ghost's meshes onto the snap.
    inline void OnPostEvent(void* obj, UFunction* fn, void* parms)
    {
        if (!parms || obj != g_ghost || !g_snappable || !Settings::Misc::StructureSnapping) return;
        if (!IsAllowedToBuildFn(fn)) return;

        if (g_pOutData < 0) g_pOutData = ParamOffset(fn, "OutPlacementData");
        if (g_pOutData < 0) return;

        const uint8_t* pd = reinterpret_cast<const uint8_t*>(parms) + g_pOutData;
        const V3 raw    = At<V3>(pd, 0x00);          // FPlacementData::AdjustedLocation
        const float rawYaw = At<R3>(pd, 0x0C).yaw;  // FPlacementData::AdjustedRotation

        const V3    rootPos{ raw.x + g_rootBias.x, raw.y + g_rootBias.y, raw.z + g_rootBias.z };
        const float rootYaw = NormYaw(rawYaw + g_rootYawBias);

        V3 pos; float yaw;
        const bool snapped = Solve(obj, raw, pos, yaw);
        if (snapped)
        {
            g_snap.raw    = raw;
            g_snap.rawYaw = rawYaw;
            g_snap.pos    = pos;
            g_snap.yaw    = yaw;
            g_snap.stamp  = GetTickCount64();
            g_snap.valid  = true;
        }
        else g_snap.valid = false;

        g_lastRaw     = raw;
        g_lastRawYaw  = rawYaw;
        g_lastRootPos = rootPos;
        g_lastRootYaw = rootYaw;
        g_lastEval    = NowSeconds();
        StepVis(obj, rootPos, rootYaw, snapped, pos, yaw);
    }

    // Before the original: ship the displayed pose to the server.
    inline void OnPreEvent(void* obj, UFunction* fn, void* parms)
    {
        UFunction* place = EngineRefs::g_refs.pcServerRequestPlaceStructure;
        if (!place || fn != place || !parms) return;
        if (!g_loggedPlaceSeen) { g_loggedPlaceSeen = true; Logger::Log("[StructureSnap] placement request seen at ProcessEvent"); }
        if (!Settings::Misc::StructureSnapping || !g_snap.valid || GetTickCount64() - g_snap.stamp > 500) return;

        if (g_pBuildLoc < 0)
        {
            g_pBuildLoc  = ParamOffset(fn, "BuildLocation");
            g_pBuildRot  = ParamOffset(fn, "BuildRotation");
            g_pViewRot   = ParamOffset(fn, "PlayerViewRotation");
            g_pSnapped   = ParamOffset(fn, "bSnapped");
            g_pSnapCycle = ParamOffset(fn, "SnapPointCycle");
        }
        if (g_pBuildLoc < 0 || g_pViewRot < 0) return;

        V3& bl = At<V3>(parms, g_pBuildLoc);
        R3& vr = At<R3>(parms, g_pViewRot);
        const float dyaw = NormYaw(g_snap.yaw - g_snap.rawYaw);
        Logger::Log("[StructureSnap] commit: build (%.1f,%.1f,%.1f) view yaw %.1f | raw (%.1f,%.1f,%.1f) yaw %.1f -> snap (%.1f,%.1f,%.1f) yaw %.1f",
                    bl.x, bl.y, bl.z, vr.yaw, g_snap.raw.x, g_snap.raw.y, g_snap.raw.z, g_snap.rawYaw,
                    g_snap.pos.x, g_snap.pos.y, g_snap.pos.z, g_snap.yaw);

        bl.x += g_snap.pos.x - g_snap.raw.x;
        bl.y += g_snap.pos.y - g_snap.raw.y;
        bl.z += g_snap.pos.z - g_snap.raw.z;
        vr.yaw = NormYaw(vr.yaw + dyaw);
        if (g_pBuildRot >= 0) { R3& br = At<R3>(parms, g_pBuildRot); br.yaw = NormYaw(br.yaw + dyaw); }
        if (g_pSnapped >= 0)   At<bool>(parms, g_pSnapped) = false;
        if (g_pSnapCycle >= 0) At<int32_t>(parms, g_pSnapCycle) = 0;

        // Pick up the structure being placed as a neighbour soon (once the
        // server has spawned it), so its side counts as taken.
        g_candStamp = GetTickCount64() - 250;
    }

    // ---- DrawHUD (game thread): track the ghost, arrow keys, on-screen text ------
    struct KeyRepeat { bool down = false; ULONGLONG next = 0; };
    inline KeyRepeat g_kLeft, g_kRight, g_kUp, g_kDown;

    // true on press, then repeating while held (after 350 ms, every 40 ms)
    inline bool Pressed(KeyRepeat& k, int vk, bool allowRepeat)
    {
        const bool down = InputBridge::g_down[vk];
        const ULONGLONG now = GetTickCount64();
        bool fire = false;
        if (down && !k.down) { fire = true; k.next = now + 350; }
        else if (down && allowRepeat && now >= k.next) { fire = true; k.next = now + 40; }
        k.down = down;
        return fire;
    }

    // SansationBold18 - the font ARK draws structure prompts in ("[E] : Access
    // Inventory"). Roboto18 only if it is not loaded. Plain text, no outline.
    inline UFont* HudFont()
    {
        return EngineRefs::g_refs.fontSansation ? EngineRefs::g_refs.fontSansation : EngineRefs::g_refs.font18;
    }

    inline FVector2D TextSize(AHUD* hud, const wchar_t* text, float scale)
    {
        FVector2D out(0.f, 0.f);
        if (!EngineRefs::g_refs.hudGetTextSize) return out;
        struct { FString Text; float OutWidth, OutHeight; UFont* Font; float Scale; } p{};
        p.Text = FString(text); p.Font = HudFont(); p.Scale = scale;
        UObject::ProcessEvent(hud, EngineRefs::g_refs.hudGetTextSize, &p);
        out.X = p.OutWidth; out.Y = p.OutHeight;
        return out;
    }

    inline void DrawText(AHUD* hud, const wchar_t* text, float x, float y, const FLinearColor& color, float scale)
    {
        struct { FString Text; FLinearColor TextColor; float ScreenX, ScreenY; UFont* Font; float Scale; bool bScalePosition; } p{};
        p.Text = FString(text); p.TextColor = color; p.ScreenX = floorf(x + 0.5f); p.ScreenY = floorf(y + 0.5f);
        p.Font = HudFont(); p.Scale = scale;
        UObject::ProcessEvent(hud, EngineRefs::g_refs.hudDrawText, &p);
    }

    // The ghost root the placer actually set this frame vs. the placement data
    // the offset was computed from. Kept as a bias so the next frame is exact.
    inline void MeasureRootBias(void* ghost)
    {
        if (!g_snap.valid || GetTickCount64() - g_snap.stamp > 100) return;
        const void* root = RootOf(ghost);
        if (!root) return;
        const V3 actual = WorldPos(root);
        const V3 b{ actual.x - g_snap.raw.x, actual.y - g_snap.raw.y, actual.z - g_snap.raw.z };
        const float yb = NormYaw(WorldYaw(root) - g_snap.rawYaw);
        if (fabsf(b.x) < 150.f && fabsf(b.y) < 150.f && fabsf(b.z) < 150.f)
        {
            // Filtered: a steady offset is learned, frame-to-frame noise is not.
            const float k = 0.15f;
            g_rootBias.x += (b.x - g_rootBias.x) * k;
            g_rootBias.y += (b.y - g_rootBias.y) * k;
            g_rootBias.z += (b.z - g_rootBias.z) * k;
            g_rootYawBias += ((fabsf(yb) < 20.f ? yb : 0.f) - g_rootYawBias) * k;
        }
        static bool s_logged = false;
        if (!s_logged && (fabsf(b.x) + fabsf(b.y) + fabsf(b.z) > 2.f || fabsf(yb) > 0.5f))
        {
            s_logged = true;
            Logger::Log("[StructureSnap] ghost root differs from placement data by (%.1f,%.1f,%.1f) yaw %.1f", b.x, b.y, b.z, yb);
        }
    }

    // Eject / feature off: hand the ghost its meshes back.
    inline void Release()
    {
        g_wantArrows = 0;
        BlockArrows(false);
        ClearOffset(ResolveGhost());
        g_snap.valid = false;
    }

    inline void Tick(AHUD* hud, bool menuOpen)
    {
        if (!Settings::Misc::StructureSnapping)
        {
            g_wantArrows = 0;
            BlockArrows(false);
            if (g_offsetOn) Release();
            g_ghost = nullptr;
            g_ghostClass = nullptr;
            g_snap.valid = false;
            return;
        }

        void* ghost = ResolveGhost();
        g_ghost = ghost;
        if (!ghost)
        {
            g_wantArrows = 0;
            BlockArrows(false);
            g_ghostClass = nullptr;
            g_snap.valid = false;
            g_offsetOn = false;
            g_vis.active = false;
            g_origGhost = nullptr;
            return;
        }
        const UObject* go = reinterpret_cast<const UObject*>(ghost);
        if (go->Class != g_ghostClass) OnGhostClass(go);
        g_wantArrows = g_snappable ? 1 : 0;
        BlockArrows(g_wantArrows != 0);
        if (!g_snappable) return;

        MeasureRootBias(ghost);

        // No placement update lately (the game only re-evaluates when something
        // changes): if the ghost has not moved, keep solving from the last
        // placement so turning / gap changes and the easing still play out.
        if (NowSeconds() - g_lastEval > 0.05)
        {
            const void* root = RootOf(ghost);
            const V3 r = root ? WorldPos(root) : V3{ 1e9f, 1e9f, 1e9f };
            const float ex = r.x - g_lastRootPos.x, ey = r.y - g_lastRootPos.y, ez = r.z - g_lastRootPos.z;
            if (ex * ex + ey * ey + ez * ez < 1.f)
            {
                V3 pos; float yaw;
                const bool snapped = Solve(ghost, g_lastRaw, pos, yaw);
                if (snapped)
                {
                    g_snap.raw = g_lastRaw; g_snap.rawYaw = g_lastRawYaw;
                    g_snap.pos = pos;       g_snap.yaw    = yaw;
                    g_snap.stamp = GetTickCount64();
                    g_snap.valid = true;
                }
                else g_snap.valid = false;
                StepVis(ghost, g_lastRootPos, g_lastRootYaw, snapped, pos, yaw);
            }
            else
            {
                g_snap.valid = false;
                ClearOffset(ghost);
            }
        }

        // Arrow keys: rotate 90 degrees / change spacing by 1 cm (hold to repeat).
        const bool keys = !menuOpen && QuickPickup::GameFocused();
        if (keys)
        {
            if (Pressed(g_kLeft,  VK_LEFT,  false)) g_rotSteps = (g_rotSteps + 3) & 3;
            if (Pressed(g_kRight, VK_RIGHT, false)) g_rotSteps = (g_rotSteps + 1) & 3;
            float& sp = Settings::Misc::SnapSpacing;
            if (Pressed(g_kUp,   VK_UP,   true)) sp = (std::min)(sp + 0.01f,  5.f);
            if (Pressed(g_kDown, VK_DOWN, true)) sp = (std::max)(sp - 0.01f, -1.f);
            sp = roundf(sp * 100.f) / 100.f;
        }

        if (!ArmorHud::Valid(hud) || !ArmorHud::Valid(hud->Canvas) || !EngineRefs::g_refs.hudDrawText) return;
        const float clipX = At<float>(hud->Canvas, 0x30), clipY = At<float>(hud->Canvas, 0x34);
        if (!(clipX > 0.f && clipY > 0.f)) return;

        // Top-centre status + controls, ARK's prompt font, plain (no outline).
        float hr = clipY / 1440.f;
        if (hr < 0.25f) hr = 1.f;
        const float scale = 1.3f * hr;

        wchar_t l1[160], l2[96], l3[96];
        float sp = Settings::Misc::SnapSpacing;
        if (fabsf(sp) < 0.005f) sp = 0.f;
        if (g_snap.valid) swprintf_s(l1, L"Snap Locked: %ls  -  Gap %.2fm", g_name, sp);
        else              swprintf_s(l1, L"Snap Ready: %ls  -  look at one to snap beside it", g_name);
        swprintf_s(l2, L"Left / Right Arrow: Turn 90 Degrees");
        swprintf_s(l3, L"Up / Down Arrow: Gap %.2fm", sp);

        const FLinearColor locked(0.35f, 1.f, 0.45f, 1.f);
        const FLinearColor ready(0.9f, 0.9f, 0.9f, 1.f);
        const FLinearColor hint(1.f, 0.82f, 0.2f, 1.f);
        const wchar_t* lines[3] = { l1, l2, l3 };
        float y = roundf(clipY * 0.045f);
        for (int i = 0; i < 3; i++)
        {
            const float s = i == 0 ? scale : scale * 0.85f;
            const FVector2D ts = TextSize(hud, lines[i], s);
            const float x = roundf((clipX - ts.X) * 0.5f);
            DrawText(hud, lines[i], x, y, i == 0 ? (g_snap.valid ? locked : ready) : hint, s);
            y += roundf(ts.Y > 1.f ? ts.Y + 2.f * hr : 26.f * hr);
        }
    }
}

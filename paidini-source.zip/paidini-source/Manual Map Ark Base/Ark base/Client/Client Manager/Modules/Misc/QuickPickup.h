#pragma once
// ============================================================================
// QuickPickup - instant structure pickup from the hold-E wheel, plus an
// optional key that picks up whatever the "[E] : Pickup ..." prompt shows.
//
//   - the wheel's hold time is the client's copy of the server setting
//     AShooterGameState::StructurePickupHoldDuration (found by name through
//     reflection; 0x6BC on the Store build); 0 means "instant", so it is held
//     at 0 while on and the original written back when off or on eject
//   - the key sends ShooterPlayerController.ServerMultiUse(target, 203) - the
//     wheel's own Pickup request (203 = pickup case in
//     APrimalStructure::TryMultiUse) - at AShooterHUD::LastTargetedActor, the
//     actor the use prompt is drawn for, resolved through GObjects with the
//     serial-number check
// The server's own rules (ownership, pickup window, range) still apply.
//
// Ported from a friend's implementation. Differences: UFunctions come from
// EngineRefs (no FindObject scans), the structure check walks the class
// chain (AActor::IsStructure uses FindClass), and the key is read from
// InputBridge::g_down - GetAsyncKeyState returns 0 on the game thread in UWP.
//
// THREADING: Tick on the game thread, from DrawHUD. Restore on eject.
// ============================================================================
#include <Windows.h>
#include <cstdint>
#include <string>
#include <Global.h>
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Keybinds/Keybinds.h"
#include "Client Manager/Modules/UI/Input Bridge/InputBridge.h"

namespace QuickPickup
{
    inline constexpr int32_t kPickupUseIndex = 203;

    inline void*    g_State = nullptr;
    inline void*    g_Class = nullptr;
    inline uint32_t g_Off   = 0;
    inline float    g_Orig  = -1.f;

    inline void*    g_HudClass  = nullptr;
    inline uint32_t g_OffTarget = 0;
    inline bool     g_WasDown   = false;

    inline bool Readable(const void* p, size_t n)
    {
        if (!p || reinterpret_cast<uintptr_t>(p) < 0x10000 || n == 0) return false;
        const uint8_t* cur = static_cast<const uint8_t*>(p);
        const uint8_t* end = cur + n;
        if (end < cur) return false;
        while (cur < end)
        {
            MEMORY_BASIC_INFORMATION mbi{};
            if (!VirtualQuery(cur, &mbi, sizeof(mbi)))      return false;
            if (mbi.State != MEM_COMMIT)                    return false;
            if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return false;
            const uint8_t* regionEnd = static_cast<const uint8_t*>(mbi.BaseAddress) + mbi.RegionSize;
            if (regionEnd <= cur) return false;
            cur = regionEnd;
        }
        return true;
    }

    inline uint32_t PropOffset(void* cls, const char* name)
    {
        int guard = 0;
        for (UStruct* st = reinterpret_cast<UStruct*>(cls); st && guard++ < 48; st = st->SuperField)
        {
            if (!Readable(st, sizeof(void*) * 8)) break;
            int fguard = 0;
            for (UField* f = st->Children; f && fguard++ < 8192; f = f->Next)
            {
                if (!Readable(f, 0x50)) break;
                if (f->GetName() != name) continue;
                const uint32_t o = static_cast<uint32_t>(reinterpret_cast<UProperty*>(f)->Offset);
                if (o >= 0x20 && o < 0x8000) return o;
            }
        }
        return 0;
    }

    inline void ApplyHold(bool on)
    {
        UWorld* world = UWorld::Get();
        UObject* gs = world ? reinterpret_cast<UObject*>(world->GameState) : nullptr;
        if (!gs || reinterpret_cast<uintptr_t>(gs) < 0x10000 || !gs->Class) return;

        if (gs != g_State)
        {
            g_State = gs;
            g_Orig  = -1.f;
        }
        if (gs->Class != g_Class)
        {
            g_Class = gs->Class;
            g_Off   = PropOffset(gs->Class, "StructurePickupHoldDuration");
        }
        if (!g_Off) return;

        // The value is replicated from the server, and before the server's copy
        // arrives (joining, loading in, a transfer) it reads the class default,
        // 0. Remembering that 0 as "the original" left the wheel instant after
        // the feature was turned off. We only ever write 0, so any non-zero
        // value that shows up is the server's own setting: it always replaces
        // the remembered original, and that is what turning off puts back.
        float* hold = reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(gs) + g_Off);
        const float v = *hold;
        if (on)
        {
            if (v != 0.f)                 g_Orig = v;      // the server's value (fresh or updated)
            else if (g_Orig < 0.f)        g_Orig = 0.f;    // nothing seen yet; a later server value replaces it
            if (v != 0.f) *hold = 0.f;
        }
        else if (g_Orig >= 0.f)
        {
            if (v == 0.f) *hold = g_Orig;  // ours: put the server's value back (a server update already did)
            g_Orig = -1.f;
        }
    }

    inline AActor* TargetedActor(UObject* hud)
    {
        if (!hud || reinterpret_cast<uintptr_t>(hud) < 0x10000 || !hud->Class) return nullptr;
        if (hud->Class != g_HudClass)
        {
            g_HudClass  = hud->Class;
            g_OffTarget = PropOffset(hud->Class, "LastTargetedActor");
        }
        if (!g_OffTarget) return nullptr;

        const int32_t* weak = reinterpret_cast<const int32_t*>(reinterpret_cast<uintptr_t>(hud) + g_OffTarget);
        auto& objs = UObject::GetGlobalObjects();
        if (weak[0] <= 0 || weak[0] >= objs.Count()) return nullptr;
        FUObjectItem* item = objs.GetItemByIndex(weak[0]);
        if (!item || item->SerialNumber != weak[1] || !item->Object) return nullptr;
        return reinterpret_cast<AActor*>(item->Object);
    }

    // Class-chain check instead of AActor::IsStructure (FindClass full scan).
    inline bool IsStructure(const UObject* o)
    {
        int depth = 0;
        for (UStruct* s = o->Class; s && reinterpret_cast<uintptr_t>(s) >= 0x10000 && depth < 24; s = s->SuperField, depth++)
            if (s->GetName() == "PrimalStructure") return true;
        return false;
    }

    inline bool IsChatOpen(UObject* hud)
    {
        UFunction* fn = EngineRefs::g_refs.hudIsChatBoxVisible;
        if (!fn || !hud || reinterpret_cast<uintptr_t>(hud) < 0x10000) return false;
        struct { bool ReturnValue; } p = {};
        UObject::ProcessEvent(hud, fn, &p);
        return p.ReturnValue;
    }

    inline bool GameFocused()
    {
        HWND fg = GetForegroundWindow();
        if (!fg) return false;
        const DWORD myPid = GetCurrentProcessId();
        DWORD pid = 0;
        GetWindowThreadProcessId(fg, &pid);
        if (pid == myPid) return true;
        HWND core = FindWindowExW(fg, nullptr, L"Windows.UI.Core.CoreWindow", nullptr);
        if (core)
        {
            pid = 0;
            GetWindowThreadProcessId(core, &pid);
            if (pid == myPid) return true;
        }
        return false;
    }

    inline void Pickup(APlayerController* pc, UObject* hud)
    {
        UFunction* fn = EngineRefs::g_refs.pcServerMultiUse;
        if (!fn || !pc || reinterpret_cast<uintptr_t>(pc) < 0x10000) return;
        AActor* target = TargetedActor(hud);
        if (!target || !IsStructure(reinterpret_cast<UObject*>(target))) return;
        struct { UObject* ForObject; int32_t UseIndex; } p{ reinterpret_cast<UObject*>(target), kPickupUseIndex };
        UObject::ProcessEvent(pc, fn, &p);
    }

    inline void Tick(UObject* hud, APlayerController* pc, bool menuOpen)
    {
        const bool enabled = Settings::Misc::QuickPickup;
        ApplyHold(enabled);

        const int vk = Keybinds::ImGuiKeyToVk(Settings::Misc::QuickPickupKey);
        const bool down = enabled && vk > 0 && vk <= 0xFF && InputBridge::g_down[vk] &&
                          !menuOpen && GameFocused() && !IsChatOpen(hud);
        if (down && !g_WasDown) Pickup(pc, hud);
        g_WasDown = down;
    }

    inline bool IsRestored() { return g_Orig < 0.f; }

    inline void Restore()
    {
        if (g_Orig < 0.f || !g_Off) { g_Orig = -1.f; return; }
        UWorld* world = UWorld::Get();
        UObject* gs = world ? reinterpret_cast<UObject*>(world->GameState) : nullptr;
        if (gs && gs == g_State)
        {
            float* hold = reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(gs) + g_Off);
            if (*hold == 0.f) *hold = g_Orig;   // a non-zero value is already the server's
        }
        g_Orig = -1.f;
    }
}

#pragma once
// ============================================================================
// BetterInput - while your inventory is open, the game's own Drop, Transfer
// and Use keys fire as fast as the engine takes them: held, one action every
// frame with no key-repeat wait; spammed, the taps are joined into one run.
//
// It edits the UWP build's two 256-byte key tables (keyNow / keyPrev, found
// by signature in FUWPInputInterface::ConditionalScanForKeyboardChanges -
// verified on the Store build: one match, tables at RVA 0x4371C70 / 0x4371B70)
// so the per-frame scan sees a fresh key-down edge every frame. No input is
// sent to Windows, so no key can be left stuck down.
//
// Off while an inventory search box is being typed in, while Shift / Ctrl /
// Alt is held (split-half is the same key with a modifier - repeating it split
// the stack until all of it moved), with the menu open, or when the game is
// not focused. No chat check: IsChatBoxVisible is true whenever the chat box is
// SHOWN, which on this client is always.
//
// Ported from a friend's implementation. Differences for this DLL:
//   - keys come from InputBridge::g_down (GetAsyncKeyState reads 0 on the game
//     thread under UWP; the input thread is attached to the UI thread)
//   - no FindClass / FindObjects at runtime (full GObjects name scans freeze
//     the game): the DataListPanel class comes from EngineRefs, the panel list
//     is rebuilt on a background thread, the player check walks the class
//     chain, and the Drop / Transfer / Use keys are read from the live
//     PlayerInput's ActionMappings (+0xE8) instead of the InputSettings CDO
//   - the signature scan uses the SDK's ScanPattern (CRT parsing misbehaves in
//     the manually mapped image)
//
// THREADING: Tick on the game thread, from DrawHUD. Reset on eject.
// ============================================================================
#include <Windows.h>
#include <cstdint>
#include <cstdlib>
#include <string>
#include <vector>
#include <Global.h>
#include <CheatSettings.h>
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Misc/QuickPickup.h"            // PropOffset, GameFocused
#include "Client Manager/Modules/UI/Input Bridge/InputBridge.h"

namespace BetterInput
{
    inline constexpr int       kTransferVK         = 'T';
    inline constexpr int       kSpamGapMs          = 150;
    inline constexpr uintptr_t kOffPiActionMappings = 0x00E8;   // UPlayerInput::ActionMappings (0x28 each)
    inline constexpr uint32_t  kOffNameFilterDefault = 0x0770;  // DataListPanel NameFilter (FString)
    inline constexpr uintptr_t kOffInvFlags        = 0x1260;    // AShooterCharacter::bIsViewingInventory byte
    inline constexpr uint8_t   kInvOpenBit         = 1u << 5;
    inline constexpr const char* kKeyTableSig =
        "42 0F B6 84 3E ?? ?? ?? ?? 84 C0 75 ?? 42 80 BC 3E ?? ?? ?? ?? 01 75 ?? B3 01 EB ?? 32 DB";

    struct KeyState
    {
        uint64_t releaseMs = 0;
        int      pendingVk = 0;
        int      fakeVk    = 0;
        bool     active    = false;
        bool     spamming  = false;
    };
    inline KeyState dropState, transferState, useState;

    inline uint8_t* keyNow  = nullptr;
    inline uint8_t* keyPrev = nullptr;

    inline int      autoDropVK     = 0;
    inline int      autoTransferVK = 0;
    inline int      autoUseVK      = 0;
    inline uint64_t lastResolveMs  = 0;

    inline bool Down(int vk) { return vk > 0 && vk <= 0xFF && InputBridge::g_down[vk]; }

    inline bool Readable(const void* p, size_t n)
    {
        if (!p || reinterpret_cast<uintptr_t>(p) < 0x10000 || n == 0) return false;
        const uint8_t* cur = static_cast<const uint8_t*>(p);
        const uint8_t* end = cur + n;
        if (end < cur) return false;
        while (cur < end)
        {
            MEMORY_BASIC_INFORMATION mbi{};
            if (!VirtualQuery(cur, &mbi, sizeof(mbi)))      return false;
            if (mbi.State != MEM_COMMIT)                    return false;
            if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return false;
            const uint8_t* regionEnd = static_cast<const uint8_t*>(mbi.BaseAddress) + mbi.RegionSize;
            if (regionEnd <= cur) return false;
            cur = regionEnd;
        }
        return true;
    }

    inline bool ResolveKeyTables()
    {
        static bool searched = false;
        if (searched) return keyNow != nullptr;
        searched = true;
        uint8_t* hit = static_cast<uint8_t*>(ScanPattern(kKeyTableSig));
        if (!hit) { Logger::Log("[BetterInput] key table signature NOT FOUND"); return false; }
        auto* base = reinterpret_cast<uint8_t*>(GetModuleHandleW(nullptr));
        keyNow  = base + *reinterpret_cast<int32_t*>(hit + 0x05);
        keyPrev = base + *reinterpret_cast<int32_t*>(hit + 0x11);
        Logger::Log("[BetterInput] key tables now=%p prev=%p", keyNow, keyPrev);
        return true;
    }

    inline void Cancel(KeyState& st)
    {
        if (keyNow)
        {
            if (st.pendingVk) keyPrev[st.pendingVk] = keyNow[st.pendingVk];
            if (st.fakeVk)    keyNow[st.fakeVk] = 0;
        }
        st = {};
    }

    inline void Reset()
    {
        Cancel(dropState); Cancel(transferState); Cancel(useState);
    }

    inline bool IsShooterCharacter(const UObject* o)
    {
        int depth = 0;
        for (UStruct* s = o->Class; s && reinterpret_cast<uintptr_t>(s) >= 0x10000 && depth < 16; s = s->SuperField, depth++)
            if (s->GetName() == "ShooterCharacter") return true;
        return false;
    }

    inline bool IsInventoryOpen(AActor* localActor)
    {
        if (!localActor || reinterpret_cast<uintptr_t>(localActor) < 0x10000) return false;
        static void* s_cls = nullptr; static bool s_isPlayer = false;
        const UObject* o = reinterpret_cast<const UObject*>(localActor);
        if (o->Class != s_cls) { s_cls = o->Class; s_isPlayer = IsShooterCharacter(o); }
        if (!s_isPlayer) return false;
        const uint8_t flags = *reinterpret_cast<uint8_t*>(reinterpret_cast<uintptr_t>(localActor) + kOffInvFlags);
        return (flags & kInvOpenBit) != 0;
    }

    // ---- inventory search boxes (DataListPanel NameFilter) ----------------------
    struct PanelSnap { UObject* panel; uint32_t hash; };
    inline std::vector<PanelSnap> panelSnaps;
    inline bool     needRefresh   = true;
    inline uint64_t lastTypedMs   = 0;
    inline bool     searchFocused = false;
    inline uint64_t lastLmbMs     = 0;
    inline uint64_t typedAtClick  = 0;
    inline bool     prevLmb = false, prevEsc = false;
    inline uint32_t offNameFilter = 0;

    // Background panel list (GObjects walk off the game thread).
    inline SRWLOCK              g_panelLock = SRWLOCK_INIT;
    inline std::vector<UObject*> g_panelFound;
    inline volatile LONG        g_panelBusy  = 0;
    inline volatile LONG        g_panelFresh = 0;

    inline void CollectPanelsAt(int32_t i, UClass* cls, std::vector<UObject*>& out)
    {
        __try
        {
            UObject* o = UObject::GetGlobalObjects().GetByIndex(i);
            if (!o || o->Class != cls) return;
            if (*reinterpret_cast<const uint32_t*>(reinterpret_cast<uintptr_t>(o) + 0x08) & 0x10) return; // RF_ClassDefaultObject
            out.push_back(o);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    inline DWORD WINAPI PanelThread(LPVOID)
    {
        std::vector<UObject*> found;
        UClass* cls = EngineRefs::g_refs.clsDataListPanel;
        if (cls)
        {
            const int32_t n = UObject::GetGlobalObjects().Count();
            for (int32_t i = 0; i < n; i++) CollectPanelsAt(i, cls, found);
        }
        AcquireSRWLockExclusive(&g_panelLock);
        g_panelFound.swap(found);
        ReleaseSRWLockExclusive(&g_panelLock);
        InterlockedExchange(&g_panelFresh, 1);
        InterlockedExchange(&g_panelBusy, 0);
        return 0;
    }

    inline void RequestPanels()
    {
        if (!EngineRefs::g_refs.clsDataListPanel) return;
        if (InterlockedCompareExchange(&g_panelBusy, 1, 0) != 0) return;
        HANDLE h = CreateThread(nullptr, 0, PanelThread, nullptr, 0, nullptr);
        if (h) CloseHandle(h); else InterlockedExchange(&g_panelBusy, 0);
    }

    inline uint32_t HashNameFilter(void* panel)
    {
        struct RawStr { wchar_t* data; int32_t count; int32_t max; };
        auto* s = reinterpret_cast<RawStr*>(reinterpret_cast<uintptr_t>(panel) + offNameFilter);
        if (!Readable(s, sizeof(RawStr))) return 0;
        if (!s->data || s->count <= 0 || s->count > 4096 || reinterpret_cast<uintptr_t>(s->data) < 0x10000) return 0;
        const int n = s->count > 64 ? 64 : s->count;
        if (!Readable(s->data, sizeof(wchar_t) * static_cast<size_t>(n))) return 0;
        uint32_t h = 2166136261u;
        for (int i = 0; i < n; i++)
            h = (h ^ static_cast<uint32_t>(static_cast<uint16_t>(s->data[i]))) * 16777619u;
        return h;
    }

    inline void ScanSearchBars(uint64_t now)
    {
        UClass* cls = EngineRefs::g_refs.clsDataListPanel;
        if (!cls) return;
        if (!offNameFilter)
        {
            offNameFilter = QuickPickup::PropOffset(cls, "NameFilter");
            if (!offNameFilter) offNameFilter = kOffNameFilterDefault;
        }

        static uint64_t lastRefresh = 0;
        if (needRefresh || now - lastRefresh > 10000)
        {
            needRefresh = false;
            lastRefresh = now;
            RequestPanels();
        }

        // Take a finished background list, keeping known hashes.
        if (InterlockedExchange(&g_panelFresh, 0))
        {
            std::vector<PanelSnap> rebuilt;
            AcquireSRWLockShared(&g_panelLock);
            for (UObject* o : g_panelFound)
            {
                uint32_t prev = 0xFFFFFFFFu;
                for (auto& s : panelSnaps)
                    if (s.panel == o) { prev = s.hash; break; }
                rebuilt.push_back({ o, prev });
            }
            ReleaseSRWLockShared(&g_panelLock);
            panelSnaps.swap(rebuilt);
        }

        for (auto& snap : panelSnaps)
        {
            if (!snap.panel || reinterpret_cast<uintptr_t>(snap.panel) < 0x10000) continue;
            if (!Readable(snap.panel, offNameFilter + 0x10)) continue;
            const uint32_t h = HashNameFilter(snap.panel);
            if (snap.hash != 0xFFFFFFFFu && snap.hash != h) lastTypedMs = now;
            snap.hash = h;
        }
    }

    inline void UpdateSearchFocus(uint64_t now)
    {
        if (lastTypedMs && now - lastTypedMs < 200) searchFocused = true;

        const bool lmb = Down(VK_LBUTTON);
        if (lmb && !prevLmb) { lastLmbMs = now; typedAtClick = lastTypedMs; }
        prevLmb = lmb;
        if (lastLmbMs && now - lastLmbMs > 600)
        {
            if (lastTypedMs == typedAtClick) searchFocused = false;
            lastLmbMs = 0;
        }

        const bool esc = Down(VK_ESCAPE);
        if (esc && !prevEsc) searchFocused = false;
        prevEsc = esc;
    }

    // ---- key bindings -----------------------------------------------------------
    inline int FKeyNameToVK(const std::string& n)
    {
        if (n.empty()) return 0;
        if (n.size() == 1)
        {
            const char c = n[0];
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) return static_cast<int>(c);
        }
        if (n.size() >= 2 && n[0] == 'F')
        {
            int fn = 0;
            for (size_t i = 1; i < n.size() && n[i] >= '0' && n[i] <= '9'; i++) fn = fn * 10 + (n[i] - '0');
            if (fn >= 1 && fn <= 24) return VK_F1 + (fn - 1);
        }
        if (n == "LeftMouseButton")   return VK_LBUTTON;
        if (n == "RightMouseButton")  return VK_RBUTTON;
        if (n == "MiddleMouseButton") return VK_MBUTTON;
        if (n == "ThumbMouseButton")  return VK_XBUTTON1;
        if (n == "ThumbMouseButton2") return VK_XBUTTON2;
        if (n == "SpaceBar")          return VK_SPACE;
        if (n == "Enter")             return VK_RETURN;
        if (n == "Tab")               return VK_TAB;
        if (n == "BackSpace")         return VK_BACK;
        if (n == "LeftShift")         return VK_LSHIFT;
        if (n == "RightShift")        return VK_RSHIFT;
        if (n == "LeftControl")       return VK_LCONTROL;
        if (n == "RightControl")      return VK_RCONTROL;
        if (n == "LeftAlt")           return VK_LMENU;
        if (n == "RightAlt")          return VK_RMENU;
        if (n == "Up")                return VK_UP;
        if (n == "Down")              return VK_DOWN;
        if (n == "Left")              return VK_LEFT;
        if (n == "Right")             return VK_RIGHT;
        if (n == "Insert")            return VK_INSERT;
        if (n == "Delete")            return VK_DELETE;
        if (n == "Home")              return VK_HOME;
        if (n == "End")               return VK_END;
        if (n == "PageUp")            return VK_PRIOR;
        if (n == "PageDown")          return VK_NEXT;
        return 0;
    }

    // The player's live bindings: PlayerInput::ActionMappings (ActionName @0,
    // Key FName @8, 0x28 each - read on the Store build).
    inline void ResolveBindings(uint64_t now)
    {
        if (now - lastResolveMs < 1000) return;
        lastResolveMs = now;

        ULocalPlayer* lp = ULocalPlayer::Get();
        const UObject* pc = lp ? reinterpret_cast<const UObject*>(lp->PlayerController) : nullptr;
        if (!pc || reinterpret_cast<uintptr_t>(pc) < 0x10000) return;
        static void* s_pcCls = nullptr; static uint32_t s_offPI = 0;
        if (pc->Class != s_pcCls) { s_pcCls = pc->Class; s_offPI = QuickPickup::PropOffset(pc->Class, "PlayerInput"); }
        if (!s_offPI) return;
        const uint8_t* pi = *reinterpret_cast<uint8_t* const*>(reinterpret_cast<uintptr_t>(pc) + s_offPI);
        if (!pi || reinterpret_cast<uintptr_t>(pi) < 0x10000) return;

        struct RawArray { uint8_t* data; int32_t count; int32_t max; };
        const auto* arr = reinterpret_cast<const RawArray*>(pi + kOffPiActionMappings);
        if (!arr->data || arr->count <= 0 || arr->count > 4096) return;
        if (!Readable(arr->data, 0x28 * static_cast<size_t>(arr->count))) return;

        int newDrop = 0, newTransfer = 0, newUse = 0;
        for (int i = 0; i < arr->count; i++)
        {
            const uint8_t* e = arr->data + i * 0x28;
            const std::string action = reinterpret_cast<const FName*>(e)->GetName();
            const int vk = FKeyNameToVK(reinterpret_cast<const FName*>(e + 0x08)->GetName());
            if (!vk) continue;

            if (!newDrop && (action == "DropItem" || action == "DropCurrentItem" ||
                             action == "DropHeldItem" || action == "Drop" ||
                             action == "DropItemFromInventory"))
                newDrop = vk;
            if (!newTransfer && action == "TransferItem")
                newTransfer = vk;
            if (!newUse && (action == "UseItem" || action == "Use" ||
                            action == "InteractUse" || action == "InteractObject"))
                newUse = vk;
            if (newDrop && newTransfer && newUse) break;
        }
        if (newDrop)     autoDropVK     = newDrop;
        if (newTransfer) autoTransferVK = newTransfer;
        if (newUse)      autoUseVK      = newUse;
    }

    // ---- the key table edit -------------------------------------------------------
    inline void TickKey(KeyState& st, int vk, bool focused, uint64_t now)
    {
        if (vk <= 0 || vk > 0xFF) return;
        if (!focused || !Down(vk))
        {
            if (!st.active) return;
            if (!st.releaseMs)
            {
                if (st.pendingVk && !keyNow[vk] && !keyPrev[vk]) keyPrev[vk] = 1;
                st.pendingVk = 0;
                st.releaseMs = now;
            }
            if (!focused || now - st.releaseMs > static_cast<uint64_t>(kSpamGapMs))
            {
                if (st.fakeVk) { keyNow[vk] = 0; keyPrev[vk] = 1; }
                st = {};
                return;
            }
            if (!st.spamming) return;
            if (!st.fakeVk)
            {
                if (keyNow[vk] || keyPrev[vk]) return;
                keyNow[vk] = 1;
                st.fakeVk  = vk;
                return;
            }
        }
        else if (st.releaseMs)
        {
            st.spamming  = true;
            st.releaseMs = 0;
            st.fakeVk    = 0;
        }
        else if (!st.active)
        {
            st.active = true;
            return;
        }

        if (st.pendingVk)
        {
            if (keyNow[vk] && !keyPrev[vk]) return;
            st.pendingVk = 0;
        }
        if (!keyNow[vk]) return;
        keyPrev[vk]  = 0;
        st.pendingVk = vk;
    }

    // One status line every 2s while the inventory is open. Logging only.
    inline void Status(const char* stage, int dropVk = 0, int transferVk = 0, int useVk = 0,
                       bool focused = false)
    {
        static uint64_t s_last = 0;
        const uint64_t now = GetTickCount64();
        if (now - s_last < 2000) return;
        s_last = now;
        auto tab = [](uint8_t* t, int vk) { return (t && vk > 0 && vk <= 0xFF) ? (int)t[vk] : -1; };
        Logger::Log("[BetterInput] %s | keys drop 0x%02X transfer 0x%02X use 0x%02X (from binds %d/%d/%d) | focused %d | "
                    "drop held %d table %d/%d | transfer held %d table %d/%d",
                    stage, dropVk, transferVk, useVk,
                    autoDropVK != 0, autoTransferVK != 0, autoUseVK != 0, (int)focused,
                    (int)Down(dropVk), tab(keyNow, dropVk), tab(keyPrev, dropVk),
                    (int)Down(transferVk), tab(keyNow, transferVk), tab(keyPrev, transferVk));
    }

    inline void Tick(AActor* localActor, bool menuOpen)
    {
        if (!Settings::Misc::BetterInput || menuOpen) { Reset(); return; }

        static bool wasInvOpen = false;
        if (!IsInventoryOpen(localActor))
        {
            searchFocused = false;
            wasInvOpen = false;
            Reset();
            return;
        }
        if (!wasInvOpen) { wasInvOpen = true; needRefresh = true; }

        const uint64_t now = GetTickCount64();
        ScanSearchBars(now);
        UpdateSearchFocus(now);

        if (searchFocused) { Status("off: search box in use"); Reset(); return; }

        const bool modifier = Down(VK_SHIFT) || Down(VK_CONTROL) || Down(VK_MENU);
        if (modifier) { Status("off: Shift / Ctrl / Alt held"); Reset(); return; }

        if (!ResolveKeyTables()) { Status("off: key tables not found (signature)"); return; }
        ResolveBindings(now);
        const bool focused = QuickPickup::GameFocused();

        const int dropVk     = autoDropVK     ? autoDropVK     : 'O';
        const int transferVk = autoTransferVK ? autoTransferVK : kTransferVK;
        const int useVk      = autoUseVK      ? autoUseVK      : 'E';
        TickKey(dropState,     dropVk,     focused, now);
        TickKey(transferState, transferVk, focused, now);
        TickKey(useState,      useVk,      focused, now);
        Status("running", dropVk, transferVk, useVk, focused);
    }

    // Eject: nothing left edited, and the panel thread finished.
    inline bool IsIdle() { return g_panelBusy == 0; }
}

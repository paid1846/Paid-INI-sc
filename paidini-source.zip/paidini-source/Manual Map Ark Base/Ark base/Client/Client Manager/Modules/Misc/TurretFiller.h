#pragma once
// ============================================================================
// Turret Filler - Misc tab. Walk along your tribe's heavy / Tek turrets and
// they are topped up from your inventory: advanced rifle bullets into heavies,
// element shards into Tek turrets, up to the amount set in the cog. Uses the
// game's ordinary transfer (ServerTransferToRemoteInventory), so it moves only
// what you carry, only into turrets you could open yourself.
//
// Show Turret Fill: a marker on every one of your turrets in range, near or
// far - green full, red short (with the amount), plus a running total.
// Far turrets are judged from PrimalStructureItemContainer.CurrentItemCount
// (0xC1C), which the server replicates to everyone: it is the number of ammo
// STACKS in the turret (read live: heavy 0..58 of MaxItemCount 58, Tek 0..5
// of 5). Stacks x the ammo's MaxItemQuantity (0x5FC on the item's default
// object: 100 bullets, 1000 shards) gives the amount - exact when the stacks
// are full, an upper bound by at most one partial stack otherwise. A turret
// counted up close (its item list) uses that exact count for 15 s.
//
// PORTED from the supplied TurretFiller.h / TurretFillState.h. Changes for
// this build, all read live (Store build):
//   - no AutoDupe / TransmitterInventory / PlayerTweaks / FindClass. Turrets
//     are PrimalStructureTurret subclasses (EngineRefs.clsTurret), Tek ones by
//     class name; the ammo is the turret's own AmmoItemTemplate (0xE28) -
//     AdvancedRifleBullet for a heavy, ElementShard for a Tek turret - not a
//     name match. Plain auto / plant turrets are skipped.
//   - NumBullets (0xEC8) is NOT sent to clients (reads 0 on full turrets), so
//     the amount is counted from the turret's inventory (MyInventoryComponent
//     0xAF8 -> InventoryItems 0x118, ItemQuantity 0x5F8). That list is empty
//     until requested, so the turret's items are requested and the count is
//     only trusted kSettleMs after the reply could have arrived - counting an
//     unloaded list as empty would over-fill.
//   - reach is ARK's own RemoteInventoryAllowViewing(PC, offset) on the
//     turret inventory (150 cm viewing distance).
//   - over-fill guard as in the source: what was just sent counts as present
//     for kPendingMs, and a stack is never sent more than it holds.
//   - filled turrets are re-checked every kRecheckMs so one that has fired
//     gets topped up again.
//
// THREADING: game thread (DrawHUD hook).
// ============================================================================
#include <Global.h>
#include <CheatSettings.h>
#include <unordered_map>
#include <vector>
#include <cmath>
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Misc/QuickPickup.h"
#include "Client Manager/Modules/Notifications/Notifications.h"

namespace TurretFiller
{
    inline constexpr uintptr_t OFF_TEAM        = 0x0230;
    inline constexpr uintptr_t OFF_ROOT        = 0x0268;
    inline constexpr uintptr_t OFF_C2W_POS     = 0x00F0;
    inline constexpr uintptr_t OFF_CONT_INV    = 0x0AF8;   // PrimalStructureItemContainer::MyInventoryComponent
    inline constexpr uintptr_t OFF_AMMO_CLASS  = 0x0E28;   // PrimalStructureTurret::AmmoItemTemplate
    inline constexpr uintptr_t OFF_INV_ITEMS   = 0x0118;
    inline constexpr uintptr_t OFF_ITEM_ID     = 0x0210;
    inline constexpr uintptr_t OFF_ITEM_QTY    = 0x05F8;
    inline constexpr uintptr_t OFF_ITEM_FLAGS  = 0x0053;
    inline constexpr uint8_t   BIT_NOT_REAL    = 0x02 | 0x10;
    inline constexpr uintptr_t OFF_CHAR_INV    = 0x0D20;
    inline constexpr uintptr_t OFF_CUR_ITEMS   = 0x0C1C;   // PrimalStructureItemContainer::CurrentItemCount (replicated)
    inline constexpr uintptr_t OFF_MAX_ITEMS   = 0x0C20;   // ...MaxItemCount (slots)
    inline constexpr uintptr_t OFF_STACK_SIZE  = 0x05FC;   // PrimalItem::MaxItemQuantity
    inline constexpr uintptr_t OFF_PC_PAWN     = 0x04E8;

    inline constexpr uint64_t kPassMs     = 25;
    inline constexpr uint64_t kSweepMs    = 500;     // turret list refresh
    inline constexpr uint64_t kSettleMs   = 350;     // after requesting items, before trusting the count
    inline constexpr uint64_t kRecheckMs  = 10000;   // re-request items this often
    inline constexpr uint64_t kPendingMs  = 2500;
    inline constexpr float    kNearM      = 15.f;    // candidates for filling

    inline bool Valid(const void* p) { const uintptr_t v = reinterpret_cast<uintptr_t>(p); return v > 0x10000 && v < 0x7FFFFFFFFFFF; }
    template <typename T> inline T& At(const void* b, uintptr_t o) { return *reinterpret_cast<T*>(reinterpret_cast<uintptr_t>(b) + o); }

    struct V3 { float x, y, z; };

    // ---- turret classes ---------------------------------------------------------------
    // 0 = not a fillable turret, 1 = heavy, 2 = Tek. Cached per class.
    inline int KindOf(const UObject* o)
    {
        static std::unordered_map<const void*, int> s_kind;
        auto it = s_kind.find(o->Class);
        if (it != s_kind.end()) return it->second;
        int k = 0;
        const UClass* turret = EngineRefs::g_refs.clsTurret;
        bool isTurret = false;
        int depth = 0;
        for (UStruct* s = o->Class; Valid(s) && depth < 24; s = s->SuperField, depth++)
        {
            if (s == reinterpret_cast<const UStruct*>(turret)) { isTurret = true; break; }
        }
        if (isTurret)
        {
            const std::string n = reinterpret_cast<const UObject*>(o->Class)->GetName();
            if (n.find("Tek") != std::string::npos)        k = 2;
            else if (n.find("Heavy") != std::string::npos) k = 1;
        }
        s_kind.emplace(o->Class, k);
        return k;
    }

    // Item class is (or derives from) the ammo class.
    inline bool IsAmmo(const UObject* item, const UClass* ammo)
    {
        if (!Valid(ammo)) return false;
        int depth = 0;
        for (UStruct* s = item->Class; Valid(s) && depth < 16; s = s->SuperField, depth++)
            if (s == reinterpret_cast<const UStruct*>(ammo)) return true;
        return false;
    }

    struct RawArray { UObject** data; int32_t count; int32_t max; };

    inline const RawArray* ItemsOf(const void* inv)
    {
        if (!Valid(inv)) return nullptr;
        const RawArray* a = reinterpret_cast<const RawArray*>(reinterpret_cast<uintptr_t>(inv) + OFF_INV_ITEMS);
        if (a->count < 0 || a->count > 20000 || (a->count && !Valid(a->data))) return nullptr;
        return a;
    }

    inline bool RealItem(const UObject* it)
    {
        return Valid(it) && !(At<uint8_t>(it, OFF_ITEM_FLAGS) & BIT_NOT_REAL);
    }

    inline int CountAmmo(const void* inv, const UClass* ammo)
    {
        const RawArray* a = ItemsOf(inv);
        if (!a) return -1;
        int total = 0;
        for (int i = 0; i < a->count; i++)
        {
            const UObject* it = a->data[i];
            if (!RealItem(it) || !IsAmmo(it, ammo)) continue;
            const int32_t q = At<int32_t>(it, OFF_ITEM_QTY);
            if (q > 0 && q < 1000000) total += q;
        }
        return total;
    }

    // ---- calls ------------------------------------------------------------------------
    __declspec(noinline) inline bool Call(void* obj, UFunction* fn, void* parms)
    {
        if (!fn || !Valid(obj)) return false;
        __try { UObject::ProcessEvent(obj, fn, parms); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool CanReach(void* pc, void* inv)
    {
        UFunction* fn = EngineRefs::g_refs.invAllowViewing;
        if (!fn) return false;
        struct { void* PC; float MaxAllowedDistanceOffset; bool ReturnValue; uint8_t pad[3]; } p{ pc, 0.f, false, {} };
        return Call(inv, fn, &p) && p.ReturnValue;
    }

    inline void RequestItems(void* pc, void* inv)
    {
        struct { UObject* forInventory; bool bInventoryItems; bool bIsFirstSpawn; uint8_t _pad[6]; } rp{ reinterpret_cast<UObject*>(inv), true, false, {} };
        Call(pc, EngineRefs::g_refs.pcRequestActorItems, &rp);
    }

    inline void Transfer(void* pc, void* inv, uint64_t itemId, int32_t qty)
    {
        struct { UObject* InventoryComp; uint64_t ItemId; bool bAlsoTryToEquip; uint8_t _pad[3]; int32_t RequestedQuantity; } p{};
        p.InventoryComp = reinterpret_cast<UObject*>(inv); p.ItemId = itemId; p.RequestedQuantity = qty;
        Call(pc, EngineRefs::g_refs.pcTransferToRemoteInv, &p);
    }

    // ---- per turret state ------------------------------------------------------------
    struct Turret { int32_t idx, serial; bool tek; V3 pos; };
    inline std::vector<Turret> g_turrets;                // yours, within the marker / fill range
    inline uint64_t g_lastSweep = 0;

    struct State
    {
        uint64_t requestedAt = 0;   // items last requested
        uint64_t sentAt = 0;
        int      sentHave = 0, sentGave = 0;
        int      have = -1;         // last trusted count
        bool     filled = false;
    };
    inline std::unordered_map<uint64_t, State> g_state;    // key: idx << 32 | serial

    inline uint64_t Key(int32_t idx, int32_t serial) { return (uint64_t)(uint32_t)idx << 32 | (uint32_t)serial; }

    inline UObject* Resolve(int32_t idx, int32_t serial)
    {
        auto& objs = UObject::GetGlobalObjects();
        if (idx <= 0 || idx >= objs.Count()) return nullptr;
        FUObjectItem* item = objs.GetItemByIndex(idx);
        if (!item || item->SerialNumber != serial || !Valid(item->Object)) return nullptr;
        return item->Object;
    }

    inline bool PosOf(const void* actor, V3& out)
    {
        const void* root = At<void*>(actor, OFF_ROOT);
        if (!Valid(root)) return false;
        out = At<V3>(root, OFF_C2W_POS);
        return true;
    }

    inline float Dist2(const V3& a, const V3& b) { const float dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; return dx * dx + dy * dy + dz * dz; }

    inline void Sweep(UWorld* world, const V3& me, int32_t myTeam, float rangeM)
    {
        g_turrets.clear();
        if (!Valid(world) || !Valid(world->PersistentLevel) || !EngineRefs::g_refs.clsTurret) return;
        TArray<AActor*>& actors = world->PersistentLevel->Actors;
        const int count = actors.Count();
        if (count <= 0 || count > 400000) return;
        const float r2 = rangeM * 100.f * rangeM * 100.f;
        auto& objs = UObject::GetGlobalObjects();
        for (int i = 0; i < count; i++)
        {
            const UObject* a = reinterpret_cast<const UObject*>(actors[i]);
            if (!Valid(a) || !Valid(a->Class)) continue;
            const int k = KindOf(a);
            if (!k || At<int32_t>(a, OFF_TEAM) != myTeam) continue;
            V3 p;
            if (!PosOf(a, p) || Dist2(p, me) > r2) continue;
            const int32_t idx = a->InternalIndex;
            FUObjectItem* item = objs.GetItemByIndex(idx);
            if (!item || item->Object != a) continue;
            g_turrets.push_back({ idx, item->SerialNumber, k == 2, p });
            if (g_turrets.size() >= 1024) break;
        }
    }

    // Stacks of the ammo in your inventory, minus what was just sent from them.
    struct Stack { uint64_t id; int32_t seen, left; };
    struct Reserved { uint64_t id; int32_t seen, sent; uint64_t at; };
    inline std::vector<Reserved> g_reserved;

    inline void BuildStacks(const void* myInv, const UClass* ammo, uint64_t now, std::vector<Stack>& out)
    {
        out.clear();
        const RawArray* a = ItemsOf(myInv);
        if (!a) return;
        for (size_t i = g_reserved.size(); i-- > 0;)
            if (now - g_reserved[i].at >= kPendingMs) g_reserved.erase(g_reserved.begin() + i);
        for (int i = 0; i < a->count; i++)
        {
            const UObject* it = a->data[i];
            if (!RealItem(it) || !IsAmmo(it, ammo)) continue;
            const int32_t q = At<int32_t>(it, OFF_ITEM_QTY);
            const uint64_t id = At<uint64_t>(it, OFF_ITEM_ID);
            if (q <= 0 || q >= 1000000 || !id) continue;
            int32_t left = q;
            for (const Reserved& r : g_reserved) if (r.id == id && r.seen == q) left -= r.sent;
            if (left > 0) out.push_back({ id, q, left });
        }
    }

    inline void Reserve(uint64_t id, int32_t seen, int32_t sent, uint64_t now)
    {
        for (Reserved& r : g_reserved) if (r.id == id && r.seen == seen) { r.sent += sent; r.at = now; return; }
        g_reserved.push_back({ id, seen, sent, now });
    }

    inline void Reset()
    {
        g_turrets.clear();
        g_state.clear();
        g_reserved.clear();
    }

    // ---- game thread, every frame -----------------------------------------------------------
    inline void Tick(bool menuOpen)
    {
        using S = Settings::Misc;
        const bool want = S::TurretFiller || S::ShowTurretFill;
        if (!want || !EngineRefs::Ready()) { if (!g_state.empty() || !g_turrets.empty()) Reset(); return; }

        static uint64_t s_lastPass = 0;
        const uint64_t now = GetTickCount64();
        if (now - s_lastPass < kPassMs) return;
        s_lastPass = now;

        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        if (!Valid(pc)) return;
        void* me = reinterpret_cast<void*>(pc->LastControlledPlayerCharacter.Get());
        if (!Valid(me)) me = At<void*>(pc, OFF_PC_PAWN);
        if (!Valid(me)) return;
        V3 myPos;
        if (!PosOf(me, myPos)) return;
        const int32_t myTeam = At<int32_t>(me, OFF_TEAM);
        if (myTeam <= 0) return;

        if (now - g_lastSweep >= kSweepMs)
        {
            g_lastSweep = now;
            const float range = S::ShowTurretFill ? (std::max)(kNearM, S::ShowTurretFillDist) : kNearM;
            Sweep(UWorld::Get(), myPos, myTeam, range);
        }

        const void* myInv = At<void*>(me, OFF_CHAR_INV);
        std::vector<Stack> stacks[3];
        bool built[3] = {};
        bool noAmmo[3] = {};
        const float near2 = kNearM * 100.f * kNearM * 100.f;

        for (const Turret& t : g_turrets)
        {
            UObject* a = Resolve(t.idx, t.serial);
            if (!a) continue;
            State& st = g_state[Key(t.idx, t.serial)];
            const int target = t.tek ? (int)S::TurretFillTek : (int)S::TurretFillHeavy;
            void* inv = At<void*>(a, OFF_CONT_INV);
            const UClass* ammo = At<UClass*>(a, OFF_AMMO_CLASS);
            if (!Valid(inv) || !Valid(ammo)) continue;

            // Only turrets you can reach are asked for their items or filled.
            if (!S::TurretFiller || menuOpen || Dist2(t.pos, myPos) > near2 || target <= 0) continue;
            if (!CanReach(pc, inv)) continue;

            if (!st.requestedAt || now - st.requestedAt >= kRecheckMs)
            {
                RequestItems(pc, inv);
                st.requestedAt = now;
                continue;
            }
            if (now - st.requestedAt < kSettleMs) continue;   // reply still on its way

            int have = CountAmmo(inv, ammo);
            if (have < 0) continue;
            st.have = have;
            if (have >= target) { st.filled = true; continue; }
            st.filled = false;

            int eff = have;
            if (st.sentAt && now - st.sentAt < kPendingMs && st.sentHave + st.sentGave > eff) eff = st.sentHave + st.sentGave;
            if (eff >= target) continue;

            const int b = t.tek ? 2 : 1;
            if (!built[b]) { BuildStacks(myInv, ammo, now, stacks[b]); built[b] = true; }
            if (stacks[b].empty()) { noAmmo[b] = true; continue; }

            int need = target - eff, gave = 0, sends = 0;
            for (Stack& s : stacks[b])
            {
                if (need <= 0 || sends >= 40) break;
                if (s.left <= 0) continue;
                const int give = s.left < need ? s.left : need;
                Transfer(pc, inv, s.id, give);
                Reserve(s.id, s.seen, give, now);   // keyed by the stack size it was sent from
                s.left -= give; need -= give; gave += give; sends++;
            }
            if (!gave) continue;
            st.sentHave = have; st.sentGave = eff - have + gave; st.sentAt = now;
            st.requestedAt = now - kRecheckMs + 450;    // re-read the count right after
        }

        // Out of ammo: one toast per kind, at most every 20 s.
        static uint64_t s_warned[3] = {};
        for (int b = 1; b <= 2; b++)
            if (noAmmo[b] && now - s_warned[b] > 20000)
            {
                s_warned[b] = now;
                Notifications::Push(b == 2 ? "Turret Filler: no element shards on you" : "Turret Filler: no advanced rifle bullets on you",
                                    IM_COL32(255, 190, 60, 255));
            }

        if (g_state.size() > 4096) g_state.clear();
    }

    // ---- markers: ARK's HUD canvas ---------------------------------------------------------
    // Amount in a turret from far away: replicated stack count x stack size.
    inline int RemoteAmount(const UObject* a, int* slots = nullptr)
    {
        const int stacks = At<int32_t>(a, OFF_CUR_ITEMS), mx = At<int32_t>(a, OFF_MAX_ITEMS);
        if (stacks < 0 || stacks > 10000) return -1;
        if (slots) *slots = mx;
        const UClass* ammo = At<UClass*>(a, OFF_AMMO_CLASS);
        const UObject* cdo = Valid(ammo) ? ammo->ClassDefaultObject : nullptr;
        const int stack = Valid(cdo) ? At<int32_t>(cdo, OFF_STACK_SIZE) : 0;
        if (stack <= 0 || stack > 1000000) return -1;
        return stacks * stack;
    }

    inline void Draw(AHUD* hud)
    {
        using S = Settings::Misc;
        if (!S::ShowTurretFill || g_turrets.empty() || !Valid(hud) || !Valid(hud->Canvas)) return;
        const EngineRefs::Refs& r = EngineRefs::g_refs;
        if (!r.hudProject || !r.hudDrawRect) return;

        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        if (!Valid(pc)) return;
        // Camera direction, to skip turrets behind you (Project mirrors them).
        static uint32_t s_offRot = 0; static void* s_pcCls = nullptr;
        const UObject* pco = reinterpret_cast<const UObject*>(pc);
        if (pco->Class != s_pcCls) { s_pcCls = pco->Class; s_offRot = QuickPickup::PropOffset(pco->Class, "ControlRotation"); }
        V3 fwd{ 0.f, 0.f, 0.f };
        bool haveFwd = false;
        if (s_offRot)
        {
            const float pitch = At<float>(pc, s_offRot) * 3.14159265f / 180.f, yaw = At<float>(pc, s_offRot + 4) * 3.14159265f / 180.f;
            fwd = { cosf(pitch) * cosf(yaw), cosf(pitch) * sinf(yaw), sinf(pitch) };
            haveFwd = true;
        }
        void* me = At<void*>(pc, OFF_PC_PAWN);
        V3 myPos{};
        if (!Valid(me) || !PosOf(me, myPos)) return;

        const float clipY = At<float>(hud->Canvas, 0x34);
        float hr = clipY / 1440.f; if (hr < 0.25f) hr = 1.f;
        const float range2 = S::ShowTurretFillDist * 100.f * S::ShowTurretFillDist * 100.f;
        UFont* font = r.fontSansation ? r.fontSansation : r.font18;

        auto rect = [&](float x, float y, float w, float h, const FLinearColor& c) {
            struct { FLinearColor c; float x, y, w, h; } p{ c, x, y, w, h };
            Call(hud, r.hudDrawRect, &p);
        };
        auto textSize = [&](const wchar_t* s, float sc) {
            FVector2D out(0.f, 0.f);
            if (!r.hudGetTextSize || !font) return out;
            struct { FString Text; float W, H; UFont* Font; float Scale; } p{};
            p.Text = FString(s); p.Font = font; p.Scale = sc;
            Call(hud, r.hudGetTextSize, &p);
            out.X = p.W; out.Y = p.H;
            return out;
        };
        auto text = [&](const wchar_t* s, float x, float y, const FLinearColor& c, float sc) {
            if (!r.hudDrawText || !font) return;
            struct { FString Text; FLinearColor C; float X, Y; UFont* Font; float Scale; bool bScalePosition; } p{};
            p.Text = FString(s); p.Font = font; p.Scale = sc;
            p.C = FLinearColor(0.f, 0.f, 0.f, 0.85f); p.X = floorf(x + 1.5f); p.Y = floorf(y + 1.5f);
            Call(hud, r.hudDrawText, &p);
            p.Text = FString(s); p.C = c; p.X = floorf(x + 0.5f); p.Y = floorf(y + 0.5f);
            Call(hud, r.hudDrawText, &p);
        };

        const uint64_t now = GetTickCount64();
        int heavyTotal = 0, heavyFull = 0, tekTotal = 0, tekFull = 0;
        // Totals over every turret in range (also the ones behind you).
        for (const Turret& t : g_turrets)
        {
            if (Dist2(t.pos, myPos) > range2) continue;
            const UObject* actor = Resolve(t.idx, t.serial);
            if (!actor) continue;
            const int target = t.tek ? (int)S::TurretFillTek : (int)S::TurretFillHeavy;
            const auto it = g_state.find(Key(t.idx, t.serial));
            const bool exact = it != g_state.end() && it->second.have >= 0 && now - it->second.requestedAt < 15000;
            const int have = exact ? it->second.have : RemoteAmount(actor);
            (t.tek ? tekTotal : heavyTotal)++;
            if (have >= 0 && have >= target) (t.tek ? tekFull : heavyFull)++;
        }
        for (const Turret& t : g_turrets)
        {
            const float d2 = Dist2(t.pos, myPos);
            if (d2 > range2) continue;
            const V3 at{ t.pos.x, t.pos.y, t.pos.z + 80.f };
            if (haveFwd)
            {
                const float dx = at.x - myPos.x, dy = at.y - myPos.y, dz = at.z - myPos.z;
                if (dx * fwd.x + dy * fwd.y + dz * fwd.z <= 0.f) continue;
            }
            struct { V3 Location; V3 ReturnValue; } p{ at, {} };
            if (!Call(hud, r.hudProject, &p)) return;

            const UObject* actor = Resolve(t.idx, t.serial);
            if (!actor) continue;
            const int target = t.tek ? (int)S::TurretFillTek : (int)S::TurretFillHeavy;
            // Exact count from up close if it is fresh, else the replicated stacks.
            const auto it = g_state.find(Key(t.idx, t.serial));
            const bool exact = it != g_state.end() && it->second.have >= 0 && now - it->second.requestedAt < 15000;
            const int have = exact ? it->second.have : RemoteAmount(actor);
            const bool known  = have >= 0;
            const bool filled = known && have >= target;
            const FLinearColor col = filled ? FLinearColor(0.20f, 1.f, 0.35f, 1.f)
                                   : known  ? FLinearColor(1.f, 0.22f, 0.20f, 1.f)
                                            : FLinearColor(1.f, 0.70f, 0.15f, 1.f);   // amber: unknown


            // Bigger the closer it is (16 px far, 30 px near at 1440p).
            const float dm = sqrtf(d2) / 100.f;
            float scale = 1.f - (std::min)(dm, 60.f) / 60.f;
            const float sz = floorf((16.f + 14.f * scale) * hr + 0.5f);
            const float b  = (std::max)(2.f, floorf(2.f * hr + 0.5f));
            const float x = floorf(p.ReturnValue.x - sz * 0.5f + 0.5f), y = floorf(p.ReturnValue.y - sz * 0.5f + 0.5f);

            rect(x - b, y - b, sz + 2.f * b, sz + 2.f * b, FLinearColor(0.f, 0.f, 0.f, 0.85f));
            rect(x, y, sz, sz, col);
            rect(x, y, sz, floorf(sz * 0.4f), FLinearColor(1.f, 1.f, 1.f, 0.25f));   // gloss

            // Label: FULL / have of target / CHECK, with the kind.
            wchar_t lbl[48];
            if (filled)     swprintf_s(lbl, L"%ls FULL", t.tek ? L"TEK" : L"HEAVY");
            else if (known) swprintf_s(lbl, L"%d / %d", have, target);
            else            swprintf_s(lbl, L"%ls ?", t.tek ? L"TEK" : L"HEAVY");
            const float ts = (0.85f + 0.25f * scale) * hr;
            const FVector2D sz2 = textSize(lbl, ts);
            text(lbl, p.ReturnValue.x - sz2.X * 0.5f, y + sz + b + 2.f * hr, col, ts);
        }

        // Running total, bottom centre above the hotbar.
        if (heavyTotal || tekTotal)
        {
            const float clipX = At<float>(hud->Canvas, 0x30);
            const float ts = 1.0f * hr;
            wchar_t a[64], b2[64];
            swprintf_s(a, L"Heavy %d / %d full", heavyFull, heavyTotal);
            swprintf_s(b2, L"Tek %d / %d full", tekFull, tekTotal);
            const FVector2D sa = textSize(a, ts), sb = textSize(b2, ts);
            const float gap = 28.f * hr, total = (heavyTotal ? sa.X : 0.f) + (tekTotal ? sb.X : 0.f) + (heavyTotal && tekTotal ? gap : 0.f);
            const float py = floorf(clipY * 0.80f), padX = 12.f * hr, padY = 6.f * hr, h = (std::max)(sa.Y, sb.Y);
            float x = floorf((clipX - total) * 0.5f);
            rect(x - padX, py - padY, total + padX * 2.f, h + padY * 2.f, FLinearColor(0.02f, 0.06f, 0.08f, 0.75f));
            auto c = [](int f, int t) { return f >= t ? FLinearColor(0.20f, 1.f, 0.35f, 1.f) : FLinearColor(1.f, 0.30f, 0.26f, 1.f); };
            if (heavyTotal) { text(a, x, py, c(heavyFull, heavyTotal), ts); x += sa.X + gap; }
            if (tekTotal)   text(b2, x, py, c(tekFull, tekTotal), ts);
        }
    }
}

#pragma once
// ============================================================================
// TakeAll - everything in the inventory you are looking inside (a storage box,
// a fridge, a dino, a bag, a crate...) comes to you:
//   - no key set: the moment you open it, once per opening
//   - key set (Take All key in the cog): each time you press that key while
//     it is open
// Nothing is taken from anything you are not looking inside.
//
// It is ARK's own "Transfer All" button: AShooterPlayerController::
// ServerTransferAllFromRemoteInventory(InventoryComp, CustomFolderFilter,
// NameFilter, DestinationFolder, bNoFolderView) - empty filters, so all of it
// (layout read live: 0x00 / 0x08 / 0x18 / 0x28 / 0x38).
//
// WHICH INVENTORY: the one in the inventory screen's remote side. It is sent
// only while ARK's inventory screen is open (AShooterHUD::CurrentOpenedInventory)
// with a remote inventory in it (UUI_Inventory::bHasRemoteInventory), for the
// inventory you opened: the ServerActorViewRemoteInventory you sent to open it
// (ProcessEvent pre-hook), else the newest entry of the controller's
// RemoteViewingInventories. Never your own inventory.
//
// THREADING: game thread (DrawHUD hook; the pre-hook runs on the game thread).
// ============================================================================
#include <Global.h>
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Misc/QuickPickup.h"   // PropOffset, GameFocused
#include "Client Manager/Modules/Keybinds/Keybinds.h"
#include "Client Manager/Modules/UI/Input Bridge/InputBridge.h"

namespace TakeAll
{
    inline constexpr uintptr_t OFF_PC_PAWN       = 0x04E8;
    inline constexpr uintptr_t OFF_PAWN_INV      = 0x0D20;
    inline constexpr uint64_t  kSettleMs         = 120;    // let the server register us as a viewer
    inline constexpr uint64_t  kPendingMs        = 2000;

    inline void*     g_pending   = nullptr;   // inventory you just opened (from the open request)
    inline uint64_t  g_pendingAt = 0;
    inline void*     g_takenFor  = nullptr;   // already taken during this opening
    inline uint64_t  g_uiOpenAt  = 0;
    inline DWORD     g_gameThread = 0;

    inline uint32_t  g_offOpenInv = 0, g_offHasRemote = 0, g_offRemoteList = 0;
    inline void*     g_hudCls = nullptr; void* g_uiCls = nullptr; void* g_pcCls = nullptr;

    inline bool Valid(const void* p) { const uintptr_t v = reinterpret_cast<uintptr_t>(p); return v > 0x10000 && v < 0x7FFFFFFFFFFF; }
    template <typename T> inline T& At(const void* b, uintptr_t o) { return *reinterpret_cast<T*>(reinterpret_cast<uintptr_t>(b) + o); }

    // ProcessEvent pre-hook: you asked the server to open an inventory.
    inline void OnPreEvent(UFunction* fn, void* parms)
    {
        if (!Settings::Misc::TakeAll || !parms || fn != EngineRefs::g_refs.pcViewRemoteInv) return;
        if (GetCurrentThreadId() != g_gameThread) return;
        void* inv = *reinterpret_cast<void**>(parms);
        if (!Valid(inv)) return;
        g_pending   = inv;
        g_pendingAt = GetTickCount64();
    }

    inline void Send(UObject* pc, void* inv)
    {
        UFunction* fn = EngineRefs::g_refs.pcTransferAllFromRemote;
        if (!fn) return;
        struct {
            void*   InventoryComp;
            FString CurrentCustomFolderFilter;
            FString CurrentNameFilter;
            FString CurrentDestinationFolder;
            bool    bNoFolderView; uint8_t pad[7];
        } p{};
        p.InventoryComp = inv;
        UObject::ProcessEvent(pc, fn, &p);
    }

    inline bool g_keyWas = false;

    inline void Tick(AHUD* hud, bool menuOpen)
    {
        g_gameThread = GetCurrentThreadId();

        // Hotkey mode: with a key set, it takes all on each press of that key
        // (while you are looking inside something) instead of on opening.
        const int  vk      = Keybinds::ImGuiKeyToVk(Settings::Misc::TakeAllKey);
        const bool keyMode = vk > 0 && vk <= 0xFF;
        const bool keyDown = keyMode && InputBridge::g_down[vk] && !menuOpen && QuickPickup::GameFocused();
        const bool pressed = keyDown && !g_keyWas;
        g_keyWas = keyDown;

        if (!Settings::Misc::TakeAll || !Valid(hud) || !EngineRefs::Ready()) { g_takenFor = nullptr; g_uiOpenAt = 0; return; }

        const UObject* h = reinterpret_cast<const UObject*>(hud);
        if (h->Class != g_hudCls) { g_hudCls = h->Class; g_offOpenInv = QuickPickup::PropOffset(h->Class, "CurrentOpenedInventory"); }
        if (!g_offOpenInv) return;

        // Inventory screen closed: the next opening takes again.
        const UObject* ui = At<UObject*>(hud, g_offOpenInv);
        if (!Valid(ui)) { g_takenFor = nullptr; g_uiOpenAt = 0; return; }

        const uint64_t now = GetTickCount64();
        if (!g_uiOpenAt) g_uiOpenAt = now;
        if (now - g_uiOpenAt < kSettleMs) return;

        if (ui->Class != g_uiCls) { g_uiCls = ui->Class; g_offHasRemote = QuickPickup::PropOffset(ui->Class, "bHasRemoteInventory"); }
        if (g_offHasRemote && !At<bool>(ui, g_offHasRemote)) return;   // only your own inventory is open

        ULocalPlayer* lp = ULocalPlayer::Get();
        UObject* pc = lp ? reinterpret_cast<UObject*>(lp->PlayerController) : nullptr;
        if (!Valid(pc)) return;

        // The inventory you opened: your own open request, else the newest one
        // you are viewing.
        // When the viewing list is readable, the open request only counts if its
        // inventory is in it (Auto Saddle sends the same request for dinos).
        void* inv = nullptr;
        void* newest = nullptr;
        bool  pendingListed = false, haveList = false;
        if (pc->Class != g_pcCls) { g_pcCls = pc->Class; g_offRemoteList = QuickPickup::PropOffset(pc->Class, "RemoteViewingInventories"); }
        if (g_offRemoteList)
        {
            const TArray<void*>& list = At<TArray<void*>>(pc, g_offRemoteList);
            const int n = list.Count();
            if (n > 0 && n < 64)
            {
                haveList = true;
                newest = list.Data()[n - 1];
                for (int i = 0; i < n; i++) if (list.Data()[i] == g_pending) pendingListed = true;
            }
        }
        if (g_pending && now - g_pendingAt < kPendingMs && (!haveList || pendingListed)) inv = g_pending;
        if (!inv) inv = newest;
        if (!Valid(inv)) return;

        // Never your own inventory.
        void* pawn = At<void*>(pc, OFF_PC_PAWN);
        if (Valid(pawn) && At<void*>(pawn, OFF_PAWN_INV) == inv) return;

        if (keyMode) { if (!pressed) return; }      // each press takes again
        else if (inv == g_takenFor) return;         // automatic: once per opening

        Send(pc, inv);
        g_takenFor = inv;
        g_pending  = nullptr;
        const UObject* owner = Valid(At<UObject*>(inv, 0x20)) ? At<UObject*>(inv, 0x20) : nullptr;   // UObject::Outer
        Logger::Log("[TakeAll] took all from %s", owner ? owner->GetName().c_str() : "inventory");
    }
}

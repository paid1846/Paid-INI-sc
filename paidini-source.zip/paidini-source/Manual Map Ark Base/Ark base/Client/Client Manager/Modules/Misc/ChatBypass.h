#pragma once
// ============================================================================
// Chat Bypass - UWP profanity filter off.
//
// The Microsoft Store build runs every outgoing chat message through Xbox
// Live's StringService via UWPProfanityCheck_IsTextOK before it is handed to
// ServerSendChatMessage. A 0 result wipes the message client-side and it is
// never sent. With the toggle on, the check answers "text is OK" (1), so the
// message goes out as typed.
//
// Signature verified on the Store build: one match (RVA 0x2DD9830).
// THREADING: called on whichever thread sends chat; reads one bool.
// ============================================================================
#include <Windows.h>
#include "MinHook.h"
#include <CheatSettings.h>

namespace ChatBypass
{
    typedef char(__fastcall* UWPProfanityCheck_t)(void* TextToCheck);

    inline constexpr const char* kSignature =
        "48 89 4C 24 ? 53 55 56 57 41 54 41 56 41 57 48 83 EC 50 "
        "48 C7 44 24 ? FE FF FF FF 4C 8B F1 45 33 E4";

    inline void*               pTarget  = nullptr;
    inline UWPProfanityCheck_t oExecute = nullptr;

    inline char __fastcall Execute(void* TextToCheck)
    {
        if (Settings::Misc::ChatBypass)
            return 1; // "text is OK" - nothing gets filtered
        return oExecute(TextToCheck);
    }

    // Created before MH_EnableHook(MH_ALL_HOOKS); removed with every other hook.
    inline bool Create(void* target)
    {
        if (!target) return false;
        if (MH_CreateHook(target, reinterpret_cast<LPVOID>(&Execute), reinterpret_cast<LPVOID*>(&oExecute)) != MH_OK)
            return false;
        pTarget = target;
        return true;
    }
}

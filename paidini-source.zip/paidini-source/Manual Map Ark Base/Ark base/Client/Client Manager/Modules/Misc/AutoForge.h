#pragma once
// ============================================================================
// AutoForge - automated smelting line, Misc tab.
//
// Every 50ms it services forges you can reach (round-robin, budgeted RPCs):
//   - Deposit Gas: splits your gasoline evenly over industrial forges
//   - Deposit Metal: splits metal + scrap metal evenly over every forge
//   - Pull Metal: takes finished ingots out (stops when you are full)
//   - Pull To Dedi: pulled ingots go straight into the nearest dedicated
//     storage that holds them
//   - Turn On: lights off forges via the use wheel (server takes ~2.5/s)
//
// HOW IT FINDS FORGES: incremental level sweep (4000 actors/tick) matching
// the forge inventory blueprints by class chain, validated alive by object
// index + serial. Reach is proven per forge with the server's own
// RemoteInventoryAllowViewing test, not raw distance.
//
// THREADING: game thread (DrawHUD hook). UFunction resolution happens once
// on a worker thread; the game thread never eats a table scan.
// ============================================================================
#include <Global.h>
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Exploits/AutoDupe.h"
#include "Client Manager/Modules/Exploits/TransmitterInventory.h"
#include <algorithm>
#include <atomic>
#include <string>
#include <unordered_map>
#include <vector>
#include <float.h>
#include <cstdio>

namespace AutoForge
{
    inline constexpr DWORD     kTickMs      = 50;
    inline constexpr int       kRpcPerTick  = 3;    // hard pacing: never flood, scales to any forge count
    inline constexpr int       kSweepSlice  = 4000;
    inline constexpr int       kPullSlice   = 6;    // forges visited per tick for pulls (rotating)
    inline constexpr int       kReachJitter = 250; // stagger reach re-probes so they never bunch up
    inline constexpr DWORD     kReachMs     = 500;
    inline constexpr DWORD     kSettleMs    = 1200;
    inline constexpr DWORD     kRepeatMs    = 5000;
    inline constexpr DWORD     kAskEveryMs  = 20000;
    inline constexpr int       kAskPerTick  = 2;
    inline constexpr DWORD     kTookHoldMs  = 20000;
    inline constexpr int       kSlotMargin  = 5;
    inline constexpr uintptr_t kMaxItems    = 0x01B8;
    inline constexpr uintptr_t kAbsMaxItems = 0x0350;
    inline constexpr float     kNearCm      = 1500.f;
    inline constexpr uintptr_t kDediClass   = 0x0F00;
    inline constexpr uintptr_t kDediCount   = 0x0F08;
    inline constexpr DWORD     kFullCheckMs = 3000;
    inline constexpr DWORD     kFullHoldMs  = 60000;
    inline constexpr DWORD     kSentHoldMs  = 2000;
    inline constexpr uint32_t  kDeadFlags   = 0x30 | 0x100 | 0x4000 | 0x8000 | 0x10000;
    inline constexpr uintptr_t kItemFlags   = 0x0053;
    inline constexpr uint8_t   kNotRealItem = 0x02 | 0x10;
    inline constexpr uintptr_t kStatusComp  = 0x0D10;
    inline constexpr uintptr_t kStatCur     = 0x0818;
    inline constexpr uintptr_t kStatMax     = 0x00D8;
    inline constexpr int       kStatWeight  = 7;
    inline constexpr uintptr_t kActiveByte  = 0x0B00;
    inline constexpr uint8_t   kActiveMask  = 0x40;
    inline constexpr int32_t   kUseToggle   = 600;
    inline constexpr DWORD     kUseGapMs    = 400;
    inline constexpr DWORD     kToggleMs    = 5000;
    inline constexpr DWORD     kToggleMaxMs = 60000;
    inline constexpr int       kStuckTries  = 3;
    inline constexpr DWORD     kDoneShowMs  = 6000;
    inline constexpr float     kTextPx      = 22.f;
    inline constexpr float     kTextTop     = 0.06f;
    inline constexpr uintptr_t OFF_ItemQuantity = 0x05F8;

    enum Kind : uint8_t { kNone, kRefining, kIndustrial, kDedi };
    enum Mat : int8_t { mNone = -1, mGas, mMetal, mScrap, mIngot, mScrapIngot, mCount };

    struct Target { AActor* actor; int idx; void* cls; Kind kind; };
    struct State  { void* cls = nullptr; void* inv = nullptr; DWORD reachAt = 0; bool reach = false; DWORD askAt = 0; DWORD checkAt = 0; DWORD fullUntil = 0; int32_t count = 0; DWORD toggleAt = 0; int tries = 0; };
    struct Xfer   { AActor* actor; int idx; void* cls; FItemNetID id; int32_t qty; };
    struct Stack  { FItemNetID id; int32_t left; void* cls; };
    struct Plan   { uint64_t sig = 0; DWORD at = 0; DWORD settleAt = 0; };
    struct Status { std::atomic<int> total{ 0 }, done{ 0 }, extra{ 0 }; std::atomic<bool> busy{ false }; std::atomic<DWORD> doneAt{ 0 }; };

    inline Status s_on, s_fill;
    inline int    s_onPrev = -1;
    inline bool   s_stuck = true;

    inline std::vector<Target>                   s_targets, s_sweep;
    inline std::unordered_map<AActor*, State>    s_state;
    inline std::unordered_map<void*, Kind>       s_kindOf;
    inline std::unordered_map<void*, Mat>        s_matOf;
    inline std::unordered_map<uint64_t, DWORD>   s_sent, s_took;
    inline std::vector<Xfer>                     s_queue;
    inline size_t                                s_head = 0;
    inline Plan                                  s_plan[mCount];
    inline UWorld*                               s_world = nullptr;
    inline int                                   s_level = 0, s_actor = 0;
    inline DWORD                                 s_tickAt = 0, s_useAt = 0;
    inline UFunction*                            s_fnFull = nullptr;
    inline UFunction*                            s_fnTake = nullptr;
    inline volatile LONG                         s_fnBusy = 0;
    inline bool                                  s_fnDone = false;

    static UFunction* LookupFn(const char* name)
    {
        const std::string n(name);
        return UObject::FindObject<UFunction>(n);
    }

    static DWORD WINAPI FnThread(LPVOID)
    {
        UFunction* take = nullptr;
        UFunction* full = nullptr;
        __try { take = LookupFn("Function ShooterGame.ShooterPlayerController.ServerTransferFromRemoteInventory"); }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        __try { full = LookupFn("Function ShooterGame.PrimalInventoryComponent.IsAtMaxInventoryItems"); }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        if (take) s_fnTake = take;
        if (full) s_fnFull = full;
        s_fnDone = true;
        Logger::Log("[AutoForge] fns: take=%p full=%p",
                    static_cast<void*>(s_fnTake), static_cast<void*>(s_fnFull));
        InterlockedExchange(&s_fnBusy, 0);
        return 0;
    }

    inline void RequestFns()
    {
        if (s_fnDone || InterlockedCompareExchange(&s_fnBusy, 1, 0) != 0) return;
        HANDLE h = CreateThread(nullptr, 0, FnThread, nullptr, 0, nullptr);
        if (h) CloseHandle(h);
        else InterlockedExchange(&s_fnBusy, 0);
    }

    inline bool ValidPtr(const void* p) { const uintptr_t v = reinterpret_cast<uintptr_t>(p); return v > 0x10000 && v < 0x7FFFFFFFFFFF; }

    inline TArray<UObject*>* InvItems(UObject* inv)
    {
        if (!ValidPtr(inv) || MemBadPtr(inv, 0x128)) return nullptr;
        auto* items = reinterpret_cast<TArray<UObject*>*>((uintptr_t)inv + 0x0118);
        if (MemBadPtr(items, sizeof(void*) * 2)) return nullptr;
        return items;
    }

    inline int32_t Qty(UObject* it)
    {
        if (!ValidPtr(it) || MemBadPtr(it, OFF_ItemQuantity + 4)) return 0;
        const int32_t q = *reinterpret_cast<int32_t*>((uint64_t)it + OFF_ItemQuantity);
        return (q > 0 && q < 1000000) ? q : 0;
    }

    inline bool TerminalUsable(UObject* inv)
    {
        if (!ValidPtr(inv) || MemBadPtr(inv, sizeof(void*))) return false;
        void* vtbl = *reinterpret_cast<void**>(inv);
        return vtbl && !MemBadPtr(vtbl, sizeof(void*));
    }

    inline bool ChainHas(void* cls, const char* name)
    {
        for (UStruct* c = reinterpret_cast<UStruct*>(cls); c; c = c->SuperField)
        {
            if (MemBadPtr(c, 0x30)) return false;
            if (reinterpret_cast<UObject*>(c)->GetName() == name) return true;
        }
        return false;
    }

    inline Mat MatOf(UObject* item)
    {
        if (!ValidPtr(item)) return mNone;
        void* cls = item->Class;
        if (!cls) return mNone;
        auto it = s_matOf.find(cls);
        if (it != s_matOf.end()) return it->second;
        static const std::pair<const char*, Mat> kNames[] = {
            { "PrimalItemResource_ScrapMetalIngot_C", mScrapIngot },
            { "PrimalItemResource_MetalIngot_C",      mIngot },
            { "PrimalItemResource_ScrapMetal_C",      mScrap },
            { "PrimalItemResource_Metal_C",           mMetal },
            { "PrimalItemResource_Gasoline_C",        mGas },
        };
        Mat m = mNone;
        for (UStruct* c = reinterpret_cast<UStruct*>(cls); c && m == mNone; c = c->SuperField)
        {
            if (MemBadPtr(c, 0x30)) break;
            const std::string n = reinterpret_cast<UObject*>(c)->GetName();
            for (const auto& k : kNames)
                if (n == k.first) { m = k.second; break; }
        }
        if (s_matOf.size() > 4096) s_matOf.clear();
        return s_matOf[cls] = m;
    }

    inline bool Actor_IsContainer(AActor* a)
    {
        if (!ValidPtr(a)) return false;
        return TransmitterInventoryModule::IsItemContainer(a) ||
               TransmitterInventoryModule::IsSupplyCrate(a);
    }

    inline Kind KindOf(AActor* a)
    {
        if (!ValidPtr(a)) return kNone;
        void* cls = reinterpret_cast<UObject*>(a)->Class;
        if (!cls) return kNone;
        auto it = s_kindOf.find(cls);
        if (it != s_kindOf.end()) return it->second;
        if (!Actor_IsContainer(a)) return s_kindOf[cls] = kNone;
        void* inv = TransmitterInventoryModule::ContainerInventory(a);
        if (!inv) return s_kindOf[cls] = kNone;
        void* invCls = reinterpret_cast<UObject*>(inv)->Class;
        Kind k = kNone;
        if (ChainHas(invCls, "PrimalInventoryBP_IndustrialForge_C")) k = kIndustrial;
        else if (ChainHas(invCls, "PrimalInventoryBP_Forge_C"))      k = kRefining;
        else if (ChainHas(invCls, "PrimalInventory_DedicatedStorage_C")) k = kDedi;
        if (s_kindOf.size() > 8192) s_kindOf.clear();
        return s_kindOf[cls] = k;
    }

    inline bool IsActorValid(AActor* a, int idx, int serial)
    {
        if (!ValidPtr(a) || idx <= 0 || !UObject::GObjects) return false;
        auto& objs = UObject::GetGlobalObjects();
        if (idx >= objs.Count()) return false;
        FUObjectItem* item = objs.GetItemByIndex(idx);
        if (!item || item->Object != reinterpret_cast<UObject*>(a)) return false;
        if (serial && item->SerialNumber != serial) return false;
        const UObject* o = reinterpret_cast<UObject*>(a);
        return !(static_cast<uint32_t>(o->Flags) & kDeadFlags);
    }

    inline bool Alive(AActor* a, int idx, void* cls)
    {
        if (!a || idx <= 0) return false;
        auto& objs = UObject::GetGlobalObjects();
        if (idx >= objs.Count() || objs.GetByIndex(idx) != reinterpret_cast<UObject*>(a)) return false;
        const UObject* o = reinterpret_cast<UObject*>(a);
        return o->Class == cls && !(static_cast<uint32_t>(o->Flags) & kDeadFlags);
    }

    inline void Sweep(UWorld* world)
    {
        int budget = kSweepSlice;
        while (budget > 0)
        {
            if (s_level >= world->Levels.Count())
            {
                s_targets.swap(s_sweep);
                s_sweep.clear();
                s_level = s_actor = 0;
                if (s_state.size() > s_targets.size() * 2 + 64)
                    for (auto it = s_state.begin(); it != s_state.end();)
                        it = std::any_of(s_targets.begin(), s_targets.end(), [&](const Target& t) { return t.actor == it->first; }) ? std::next(it) : s_state.erase(it);
                return;
            }
            ULevel* level = world->Levels[s_level];
            const int n = level ? level->Actors.Count() : 0;
            for (; s_actor < n && budget > 0; ++s_actor, --budget)
            {
                AActor* a = level->Actors[s_actor];
                if (!ValidPtr(a)) continue;
                const Kind k = KindOf(a);
                if (k != kNone) s_sweep.push_back({ a, reinterpret_cast<UObject*>(a)->InternalIndex, reinterpret_cast<UObject*>(a)->Class, k });
            }
            if (s_actor >= n) { ++s_level; s_actor = 0; }
        }
    }

    inline int64_t Stacks(UObject* inv, Mat mat, std::vector<Stack>& out)
    {
        out.clear();
        int64_t total = 0;
        auto* items = InvItems(inv);
        for (int i = 0; items && i < items->Count(); ++i)
        {
            UObject* it = (*items)[i];
            if (!ValidPtr(it) || MatOf(it) != mat) continue;
            if (!ValidPtr(it) || MemBadPtr(it, kItemFlags + 1)) continue;
            if (*reinterpret_cast<uint8_t*>(reinterpret_cast<uintptr_t>(it) + kItemFlags) & kNotRealItem) continue;
            const int32_t qty = Qty(it);
            if (MemBadPtr(it, 0x218)) continue;
            const FItemNetID id = *reinterpret_cast<FItemNetID*>(reinterpret_cast<uintptr_t>(it) + AutoDupe::OFF_ItemId);
            if (qty <= 0 || (!id.ItemID1 && !id.ItemID2)) continue;
            out.push_back({ id, qty, it->Class });
            total += qty;
        }
        return total;
    }

    inline bool Room(UObject* myInv, AActor* me, bool anyWeight)
    {
        if (s_fnFull)
        {
            struct { bool R; } full{ false };
            UObject::ProcessEvent(myInv, s_fnFull, &full);
            if (full.R) return false;
        }
        if (anyWeight) return true;
        void* status = (!me || MemBadPtr(me, kStatusComp + 8)) ? nullptr : *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(me) + kStatusComp);
        if (!status || MemBadPtr(status, kStatCur + (kStatWeight + 1) * 4)) return true;
        const float cur = *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(status) + kStatCur + kStatWeight * 4);
        const float max = *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(status) + kStatMax + kStatWeight * 4);
        return !(max > 0.f && max < 1.0e7f && cur >= max);
    }

    // Server reach test (RemoteInventoryAllowViewing), not raw distance.
    inline UFunction* s_fnAllowView = nullptr;
    inline uint32_t   s_allowPcOff  = 0;
    inline int        s_allowState  = 0;

    inline int CanReach(APlayerController* pc, void* inv)
    {
        if (s_allowState == 0)
        {
            s_allowState = -1;
            UFunction* f = nullptr;
            __try { f = LookupFn("Function ShooterGame.PrimalInventoryComponent.RemoteInventoryAllowViewing"); }
            __except (EXCEPTION_EXECUTE_HANDLER) {}
            if (f && !MemBadPtr(f, 0xA0) && f->ParmsSize <= 64 && f->ReturnValueOffset < f->ParmsSize)
            {
                UProperty* first = nullptr;
                if (!MemBadPtr(f, 0x90)) first = reinterpret_cast<UProperty*>(reinterpret_cast<UStruct*>(f)->Children);
                if (first && !MemBadPtr(first, 0x50) && first->Offset >= 0 && first->Offset + 8 <= f->ParmsSize && (uint32_t)first->Offset != f->ReturnValueOffset)
                {
                    s_fnAllowView = f;
                    s_allowPcOff = (uint32_t)first->Offset;
                    s_allowState = 1;
                }
            }
        }
        if (s_allowState != 1) return -1;
        alignas(8) uint8_t buf[64] = {};
        *reinterpret_cast<void**>(buf + s_allowPcOff) = pc;
        UObject::ProcessEvent(inv, s_fnAllowView, buf);
        return buf[s_fnAllowView->ReturnValueOffset] ? 1 : 0;
    }

    inline float BoundsDistSq(const FVector& p, const FBoxSphereBounds& b)
    {
        auto axis = [](float v, float o, float e) { const float d = fabsf(v - o) - e; return d > 0.f ? d : 0.f; };
        const float dx = axis(p.X, b.Origin.X, b.BoxExtent.X);
        const float dy = axis(p.Y, b.Origin.Y, b.BoxExtent.Y);
        const float dz = axis(p.Z, b.Origin.Z, b.BoxExtent.Z);
        return dx * dx + dy * dy + dz * dz;
    }

    inline void Reachable(APlayerController* pc, const FVector& my, DWORD now, std::vector<Target*>& forges, std::vector<Target*>& dedis)
    {
        for (Target& t : s_targets)
        {
            if (!Alive(t.actor, t.idx, t.cls)) continue;
            if (MemBadPtr(t.actor, 0x270)) continue;
            USceneComponent* rc = *reinterpret_cast<USceneComponent**>(reinterpret_cast<uintptr_t>(t.actor) + 0x268);
            if (!ValidPtr(rc) || MemBadPtr(rc, 0x200)) continue;
            if (BoundsDistSq(my, rc->Bounds) > kNearCm * kNearCm) continue;
            State& st = s_state[t.actor];
            // Fresh entries stagger their first probe across the reach window
            // so 250 new forges don't all fire CanReach on the same tick.
            if (st.cls != t.cls) { st = State{ t.cls }; st.reachAt = now - kReachMs + (DWORD)((t.idx % 10) * (kReachMs / 10)); }
            if (now - st.reachAt >= kReachMs)
            {
                st.reachAt = now;
                st.inv = TransmitterInventoryModule::ContainerInventory(t.actor);
                st.reach = st.inv && TerminalUsable(reinterpret_cast<UObject*>(st.inv)) && CanReach(pc, st.inv) != 0;
            }
            if (!st.reach) continue;
            (t.kind == kDedi ? dedis : forges).push_back(&t);
        }
    }

    inline void* LiveInv(AActor* a, int idx, void* cls)
    {
        if (!Alive(a, idx, cls)) return nullptr;
        auto it = s_state.find(a);
        return it != s_state.end() && it->second.reach ? it->second.inv : nullptr;
    }

    inline void TransferStack(APlayerController* pc, void* dstInv, FItemNetID id, int32_t qty)
    {
        UFunction* fn = EngineRefs::g_refs.pcTransferToRemoteInv;
        if (!fn || !pc || !ValidPtr(dstInv)) return;
        struct
        {
            void*      InventoryComp;
            FItemNetID ItemId;
            bool       bAlsoTryToEqup;
            uint8_t    _pad[3];
            int32_t    RequestedQuantity;
        } p{};
        p.InventoryComp = dstInv; p.ItemId = id; p.RequestedQuantity = qty;
        UObject::ProcessEvent(reinterpret_cast<UObject*>(pc), fn, &p);
    }

    inline void Drain(APlayerController* pc, int& budget)
    {
        while (budget > 0 && s_head < s_queue.size())
        {
            const Xfer& x = s_queue[s_head++];
            void* inv = LiveInv(x.actor, x.idx, x.cls);
            if (!inv) continue;
            TransferStack(pc, inv, x.id, x.qty);
            --budget;
        }
        if (s_head >= s_queue.size()) { s_queue.clear(); s_head = 0; }
    }

    inline void PlanDeposit(Mat mat, const std::vector<Target*>& to, UObject* myInv, DWORD now)
    {
        if (to.empty()) return;
        const bool fresh = s_queue.empty();
        Plan& p = s_plan[mat];
        if (now < p.settleAt) return;
        std::vector<Stack> stacks;
        const int64_t total = Stacks(myInv, mat, stacks);
        if (total <= 0) return;
        uint64_t sig = (uint64_t)total * 1000003ull + to.size();
        for (const Target* t : to) sig = sig * 31ull + reinterpret_cast<uintptr_t>(t->actor);
        if (sig == p.sig && now - p.at < kRepeatMs) return;
        p.sig = sig;
        p.at = now;

        const int64_t n = (int64_t)to.size();
        const int64_t per = total / n, rem = total % n;
        size_t si = 0;
        for (int64_t i = 0; i < n && si < stacks.size(); ++i)
        {
            int64_t need = per + (i < rem ? 1 : 0);
            while (need > 0 && si < stacks.size())
            {
                Stack& s = stacks[si];
                const int32_t give = (int32_t)(std::min<int64_t>)(need, s.left);
                const Target* t = to[(size_t)i];
                s_queue.push_back({ t->actor, t->idx, t->cls, s.id, give });
                s.left -= give;
                need -= give;
                if (!s.left) ++si;
            }
        }
        p.settleAt = now + kSettleMs + (DWORD)(s_queue.size() / kRpcPerTick) * kTickMs;
        const int filled = (int)(std::min<int64_t>)(n, total);
        s_fill.extra = fresh ? filled : (std::max)(s_fill.extra.load(), filled);
        s_fill.total = (int)s_queue.size();
    }

    inline bool RealItem(UObject* it)
    {
        return ValidPtr(it) && !MemBadPtr(it, kItemFlags + 1) &&
               !(*reinterpret_cast<uint8_t*>(reinterpret_cast<uintptr_t>(it) + kItemFlags) & kNotRealItem);
    }

    inline int FreeSlots(UObject* myInv)
    {
        auto* items = (myInv && !MemBadPtr(myInv, kAbsMaxItems + 4)) ? InvItems(myInv) : nullptr;
        if (!items) return 0;
        const uintptr_t b = reinterpret_cast<uintptr_t>(myInv);
        if (MemBadPtr(myInv, kAbsMaxItems + 4)) return 0;
        const int max = *reinterpret_cast<int32_t*>(b + kMaxItems);
        int limit = *reinterpret_cast<int32_t*>(b + kAbsMaxItems);
        if (max >= 0) limit = (std::min)(limit, max);
        return limit - items->Count() - kSlotMargin;
    }

    inline void Take(APlayerController* pc, void* inv, FItemNetID id, int32_t qty)
    {
        if (!s_fnTake || !ValidPtr(inv)) return;
        struct { void* InventoryComp; FItemNetID ItemId; int32_t RequestedQuantity; int32_t ToSlotIndex; bool bEquipItem; uint8_t _pad[7]; } p{};
        static_assert(sizeof(p) == 0x20, "pull params must match the dump layout");
        p.InventoryComp = inv; p.ItemId = id; p.RequestedQuantity = qty; p.ToSlotIndex = -1;
        UObject::ProcessEvent(reinterpret_cast<UObject*>(pc), s_fnTake, &p);
    }

    inline size_t s_pullCursor = 0;

    inline void Pull(APlayerController* pc, const std::vector<Target*>& forges, UObject* myInv, DWORD now, int& budget)
    {
        int inflight = 0;
        for (auto it = s_took.begin(); it != s_took.end();)
        {
            if (now - it->second >= kTookHoldMs) { it = s_took.erase(it); continue; }
            if (now - it->second < kSentHoldMs) ++inflight;
            ++it;
        }
        int free = FreeSlots(myInv) - inflight;
        int asks = kAskPerTick;
        // Rotating slice: with hundreds of forges, walking every inventory
        // every tick is what melted the game thread. Each forge is visited
        // about once a second regardless of how many there are.
        const size_t n = forges.size();
        if (!n) return;
        if (s_pullCursor >= n) s_pullCursor = 0;
        for (int v = 0; v < kPullSlice && v < (int)n; v++)
        {
            const Target* t = forges[(s_pullCursor + (size_t)v) % n];
            if (budget <= 0) break;
            State& st = s_state[t->actor];
            if (asks > 0 && now - st.askAt >= kAskEveryMs)
            {
                st.askAt = now;
                if (ValidPtr(st.inv)) pc->ServerRequestActorItems(st.inv, true, false);
                --asks;
                --budget;
                continue;
            }
            if (free <= 0 || !s_fnTake) continue;
            auto* items = InvItems(reinterpret_cast<UObject*>(st.inv));
            for (int i = 0; items && i < items->Count() && free > 0 && budget > 0; ++i)
            {
                UObject* it = (*items)[i];
                if (!RealItem(it)) continue;
                const Mat m = MatOf(it);
                if (m != mIngot && m != mScrapIngot) continue;
                const int32_t qty = Qty(it);
                if (MemBadPtr(it, 0x218)) continue;
                const FItemNetID id = *reinterpret_cast<FItemNetID*>(reinterpret_cast<uintptr_t>(it) + AutoDupe::OFF_ItemId);
                if (qty <= 0 || (!id.ItemID1 && !id.ItemID2)) continue;
                const uint64_t key = ((uint64_t)id.ItemID1 << 32) | id.ItemID2;
                if (s_took.count(key)) continue;
                Take(pc, st.inv, id, qty);
                s_took[key] = now;
                --free;
                --budget;
            }
        }
        s_pullCursor = (s_pullCursor + (size_t)kPullSlice) % n;
    }

    inline void* DediClass(AActor* dedi)
    {
        return (!dedi || MemBadPtr(dedi, kDediCount + 4)) ? nullptr : *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(dedi) + kDediClass);
    }

    inline int32_t DediCount(AActor* dedi)
    {
        return (!dedi || MemBadPtr(dedi, kDediCount + 4)) ? 0 : *reinterpret_cast<int32_t*>(reinterpret_cast<uintptr_t>(dedi) + kDediCount);
    }

    inline bool DediOpen(AActor* dedi, State& st, DWORD now)
    {
        if (st.checkAt)
        {
            if (DediCount(dedi) != st.count) st.checkAt = 0;
            else if (now - st.checkAt >= kFullCheckMs) { st.checkAt = 0; st.fullUntil = now + kFullHoldMs; }
        }
        return !st.fullUntil || (int32_t)(now - st.fullUntil) >= 0;
    }

    inline void ToDedi(APlayerController* pc, UObject* myInv, const std::vector<Target*>& dedis, const FVector& my, DWORD now, int& budget)
    {
        s_stuck = dedis.empty();
        if (s_stuck) return;
        for (auto it = s_sent.begin(); it != s_sent.end();)
            it = now - it->second >= kSentHoldMs ? s_sent.erase(it) : std::next(it);
        std::vector<Stack> stacks;
        for (Mat mat : { mIngot, mScrapIngot })
        {
            if (!Stacks(myInv, mat, stacks)) continue;
            for (const Stack& s : stacks)
            {
                if (budget <= 0) return;
                const uint64_t key = ((uint64_t)s.id.ItemID1 << 32) | s.id.ItemID2;
                if (s_sent.count(key)) continue;
                const Target* best = nullptr;
                float bestD = FLT_MAX;
                for (const Target* d : dedis)
                {
                    State& st = s_state[d->actor];
                    if (DediClass(d->actor) != s.cls || !DediOpen(d->actor, st, now)) continue;
                    if (MemBadPtr(d->actor, 0x270)) continue;
                    USceneComponent* rrc = *reinterpret_cast<USceneComponent**>(reinterpret_cast<uintptr_t>(d->actor) + 0x268);
                    if (!ValidPtr(rrc) || MemBadPtr(rrc, 0x200)) continue;
                    const float d2 = BoundsDistSq(my, rrc->Bounds);
                    if (d2 < bestD) { bestD = d2; best = d; }
                }
                if (!best) { s_stuck = true; break; }
                State& bs = s_state[best->actor];
                TransferStack(pc, bs.inv, s.id, s.left);
                if (!bs.checkAt) { bs.checkAt = now; bs.count = DediCount(best->actor); }
                s_sent[key] = now;
                --budget;
            }
        }
    }

    inline void TurnOn(APlayerController* pc, const std::vector<Target*>& forges, DWORD now)
    {
        UFunction* fnUse = EngineRefs::g_refs.pcServerMultiUse;
        const Target* pick = nullptr;
        State* ps = nullptr;
        int total = 0, on = 0, stuck = 0;
        for (const Target* t : forges)
        {
            State& st = s_state[t->actor];
            if (MemBadPtr(t->actor, kActiveByte + 1)) continue;
            ++total;
            if (*reinterpret_cast<uint8_t*>(reinterpret_cast<uintptr_t>(t->actor) + kActiveByte) & kActiveMask) { ++on; st.tries = 0; st.toggleAt = 0; continue; }
            if (st.tries >= kStuckTries) ++stuck;
            const DWORD hold = (std::min)(kToggleMs << (std::min)(st.tries, 4), kToggleMaxMs);
            if (st.toggleAt && now - st.toggleAt < hold) continue;
            if (!ps || st.tries < ps->tries || (st.tries == ps->tries && st.toggleAt < ps->toggleAt)) { pick = t; ps = &st; }
        }
        const int pending = total - on - stuck;
        s_on.total = total;
        s_on.done = on;
        s_on.extra = stuck;
        s_on.busy = pending > 0;
        if (total && !pending && s_onPrev != 0) s_on.doneAt = now;
        s_onPrev = total ? pending : -1;

        if (!pick || now - s_useAt < kUseGapMs) return;
        if (!fnUse) return;
        s_useAt = now;
        ps->toggleAt = now;
        ++ps->tries;
        struct { UObject* ForObject; int32_t UseIndex; int32_t _pad; } p{ reinterpret_cast<UObject*>(pick->actor), kUseToggle, 0 };
        UObject::ProcessEvent(reinterpret_cast<UObject*>(pc), fnUse, &p);
    }

    inline void Reset()
    {
        s_queue.clear();
        s_head = 0;
        for (Plan& p : s_plan) p = Plan{};
        s_sent.clear();
        s_took.clear();
        s_on.total = 0;
        s_on.busy = false;
        s_fill.total = 0;
        s_fill.busy = false;
        s_onPrev = -1;
    }

    inline void Tick(APlayerController* pc, AActor* me)
    {
        if (!Settings::Misc::AutoForge)
        {
            if (!s_queue.empty() || s_onPrev != -1) Reset();
            return;
        }
        RequestFns();
        UWorld* world = UWorld::Get();
        if (!world || !pc || !ValidPtr(me)) return;
        if (MemBadPtr(me, 0x270)) return;
        USceneComponent* meRoot = *reinterpret_cast<USceneComponent**>(reinterpret_cast<uintptr_t>(me) + 0x268);
        if (!ValidPtr(meRoot) || MemBadPtr(meRoot, 0x200)) return;
        if (world != s_world)
        {
            s_world = world;
            s_targets.clear();
            s_sweep.clear();
            s_state.clear();
            s_level = s_actor = 0;
            Reset();
        }
        if (!EngineRefs::Ready()) return;
        Sweep(world);

        const DWORD now = GetTickCount();
        if (now - s_tickAt < kTickMs) return;
        s_tickAt = now;
        UObject* myInv = AutoDupe::GetPlayerInv(pc);
        if (!myInv || !EngineRefs::g_refs.pcTransferToRemoteInv) return;

        const FVector my = meRoot->Bounds.GetCenter();
        std::vector<Target*> forges, dedis;
        Reachable(pc, my, now, forges, dedis);

        int budget = kRpcPerTick;
        Drain(pc, budget);
        if (s_queue.empty())
        {
            if (Settings::Misc::AutoForgeGas)
            {
                std::vector<Target*> industrial;
                for (Target* t : forges) if (t->kind == kIndustrial) industrial.push_back(t);
                PlanDeposit(mGas, industrial, myInv, now);
            }
            if (Settings::Misc::AutoForgeMetal)
            {
                PlanDeposit(mMetal, forges, myInv, now);
                PlanDeposit(mScrap, forges, myInv, now);
            }
            Drain(pc, budget);
        }
        const bool filling = s_head < s_queue.size();
        s_fill.done = (int)s_head;
        if (s_fill.busy && !filling) s_fill.doneAt = now;
        s_fill.busy = filling;

        if (Settings::Misc::AutoForgeTurnOn) TurnOn(pc, forges, now);
        else if (s_onPrev != -1) { s_on.total = 0; s_on.busy = false; s_onPrev = -1; }
        if (Settings::Misc::AutoForgePullDedi) ToDedi(pc, myInv, dedis, my, now, budget);
        if ((Settings::Misc::AutoForgePull || Settings::Misc::AutoForgePullDedi) && Room(myInv, me, Settings::Misc::AutoForgePullDedi && !s_stuck)) Pull(pc, forges, myInv, now, budget);
    }

    // ---- overlay status (render thread): pass null font to skip ------------
    inline void Eta(char* out, size_t n, DWORD ms)
    {
        const unsigned s = (std::max)(1u, (unsigned)((ms + 999) / 1000));
        if (s >= 60) snprintf(out, n, "%um %02us", s / 60, s % 60);
        else snprintf(out, n, "%us", s);
    }

    inline void Say(ImDrawList* dl, ImFont* font, float& y, ImU32 col, const char* text)
    {
        ImFont* f = font ? font : ImGui::GetFont();
        const ImVec2 sz = f->CalcTextSizeA(kTextPx, FLT_MAX, 0.f, text);
        const ImVec2 at((ImGui::GetIO().DisplaySize.x - sz.x) * 0.5f, y);
        dl->AddText(f, kTextPx, ImVec2(at.x + 1.f, at.y + 1.f), IM_COL32(0, 0, 0, 220), text);
        dl->AddText(f, kTextPx, at, col, text);
        y += sz.y + 4.f;
    }

    inline void Render(ImDrawList* dl, ImFont* font, bool hidden)
    {
        if (!Settings::Misc::AutoForge || !dl || hidden) return;
        constexpr ImU32 kWhite = IM_COL32(235, 235, 240, 255);
        constexpr ImU32 kGreen = IM_COL32(70, 220, 90, 255);
        constexpr ImU32 kAmber = IM_COL32(255, 190, 60, 255);
        const DWORD now = GetTickCount();
        float y = ImGui::GetIO().DisplaySize.y * kTextTop;
        char line[160], eta[24];

        const int onTotal = s_on.total, on = s_on.done, stuck = s_on.extra;
        if (onTotal > 0 && s_on.busy)
        {
            Eta(eta, sizeof(eta), (DWORD)(onTotal - on - stuck) * kUseGapMs);
            snprintf(line, sizeof(line), "Turning on forges: %d/%d on  -  about %s left", on, onTotal, eta);
            Say(dl, font, y, kWhite, line);
        }
        else if (onTotal > 0 && now - s_on.doneAt < kDoneShowMs)
        {
            if (stuck) snprintf(line, sizeof(line), "%d/%d forges on  -  %d won't start (out of fuel?)", on, onTotal, stuck);
            else snprintf(line, sizeof(line), "All %d forges are on", onTotal);
            Say(dl, font, y, stuck ? kAmber : kGreen, line);
        }

        const int fillTotal = s_fill.total, sent = s_fill.done, forges = s_fill.extra;
        if (s_fill.busy && fillTotal > 0)
        {
            Eta(eta, sizeof(eta), (DWORD)((fillTotal - sent + kRpcPerTick - 1) / kRpcPerTick) * kTickMs);
            snprintf(line, sizeof(line), "Filling %d forges: %d%%  -  about %s left", forges, sent * 100 / fillTotal, eta);
            Say(dl, font, y, kWhite, line);
        }
        else if (forges > 0 && now - s_fill.doneAt < kDoneShowMs)
        {
            snprintf(line, sizeof(line), "All %d forges filled", forges);
            Say(dl, font, y, kGreen, line);
        }
    }

    // Called once from MainThread (already a worker thread).
    inline void Start()
    {
        RequestFns();
    }
}

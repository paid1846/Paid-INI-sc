#pragma once
// ============================================================================
// TekIndicator - while you hold a Tek Rifle, a compact panel for whatever you
// are aimed at, in the same style as the menu:
//
//     Tek Floor                         12m
//     [==============================]
//     15000 / 15000   100%         37 Shots
//
// Green bar while the target is within Tek Range (default 50 m, from your
// character to the aim point), red past it ("Out of Range").
//
// TARGET: ARK's own aim trace, APrimalCharacter::GetAimedActor(outHitResult,
// channel, max distance, radius, bForceUseCameraLocation, ...) - the hit's
// Actor is a weak pointer (FHitResult +0x60, resolved through GObjects with
// its serial).
//
// HEALTH, replicated (read live): structures APrimalTargetableActor::
// ReplicatedHealth / MaxHealth; dinos and players APrimalCharacter::
// ReplicatedCurrentHealth / ReplicatedMaxHealth. Offsets by reflection.
//
// SHOTS: learned. A health drop within 1.5 s of you firing is one hit; the
// last few are averaged per target class. "--" until the first hit.
//
// SPLIT ACROSS TWO THREADS:
//   Tick()   - game thread (DrawHUD): trace, health, learning -> snapshot
//   Render() - render thread (overlay, ImGui): draws the snapshot with the
//              menu's fonts and theme colours (rounded panel, border, text)
// ============================================================================
#include <Global.h>
#include <cmath>
#include <cstdio>
#include <cfloat>
#include <unordered_map>
#include "imgui.h"
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Misc/QuickPickup.h"            // PropOffset
#include "Client Manager/Modules/HUD/Crosshair.h"               // ShouldDraw (HUD up, no inventory)
#include "Client Manager/Modules/UI/Input Bridge/InputBridge.h"

namespace TekIndicator
{
    inline constexpr uintptr_t OFF_PC_PAWN   = 0x04E8;
    inline constexpr float     kMaxDistCm    = 30000.f;   // 300 m
    inline constexpr uint8_t   kChannelVis   = 3;         // ECC_Visibility
    inline constexpr uint64_t  kFireWindowMs = 1500;
    inline constexpr uint64_t  kStaleMs      = 250;       // snapshot older than this is not drawn

    // The tuned default placement. The menu's Scale 1.00 / X 0 / Y 0 mean exactly
    // this; the sliders move and size it from here.
    inline constexpr float     kBaseScale    = 1.19f;
    inline constexpr float     kBaseX        = -11.f;     // px at 1440p
    inline constexpr float     kBaseY        = -700.f;

    struct V3 { float x, y, z; };

    inline bool Valid(const void* p) { const uintptr_t v = reinterpret_cast<uintptr_t>(p); return v > 0x10000 && v < 0x7FFFFFFFFFFF; }
    template <typename T> inline T& At(const void* b, uintptr_t o) { return *reinterpret_cast<T*>(reinterpret_cast<uintptr_t>(b) + o); }

    // ---- what the overlay draws (game thread -> render thread) -----------------------
    struct Snapshot
    {
        bool      valid   = false;
        bool      inRange = false;
        float     frac    = 0.f;        // health 0..1
        char      name[128] = {};
        char      hp[48]    = {};
        char      pct[16]   = {};
        char      dist[16]  = {};
        char      right[32] = {};
        ULONGLONG stamp   = 0;
    };
    inline Snapshot g_snap;
    inline SRWLOCK  g_lock = SRWLOCK_INIT;

    inline void Clear()
    {
        AcquireSRWLockExclusive(&g_lock);
        g_snap.valid = false;
        ReleaseSRWLockExclusive(&g_lock);
    }

    // The overlay must keep drawing while a panel is up.
    inline bool Active()
    {
        AcquireSRWLockShared(&g_lock);
        const bool a = g_snap.valid && GetTickCount64() - g_snap.stamp < kStaleMs;
        ReleaseSRWLockShared(&g_lock);
        return a;
    }

    // ---- per class: where its health / name live --------------------------------
    struct ClassInfo { uint32_t cur = 0, max = 0, name = 0, tamed = 0; bool known = false; };

    inline bool ChainHas(const UObject* o, const char* name)
    {
        int depth = 0;
        for (UStruct* s = o->Class; Valid(s) && depth < 24; s = s->SuperField, depth++)
            if (s->GetName() == name) return true;
        return false;
    }

    inline const ClassInfo& InfoFor(const UObject* a)
    {
        static std::unordered_map<void*, ClassInfo> s_info;
        ClassInfo& ci = s_info[a->Class];
        if (ci.known) return ci;
        ci.known = true;
        if (ChainHas(a, "PrimalCharacter"))
        {
            ci.cur   = QuickPickup::PropOffset(a->Class, "ReplicatedCurrentHealth");
            ci.max   = QuickPickup::PropOffset(a->Class, "ReplicatedMaxHealth");
            ci.tamed = QuickPickup::PropOffset(a->Class, "TamedName");
        }
        else if (ChainHas(a, "PrimalTargetableActor"))
        {
            ci.cur = QuickPickup::PropOffset(a->Class, "ReplicatedHealth");
            ci.max = QuickPickup::PropOffset(a->Class, "MaxHealth");
        }
        ci.name = QuickPickup::PropOffset(a->Class, "DescriptiveName");
        return ci;
    }

    // FString -> UTF-8 (the overlay's font is UTF-8).
    inline bool ReadFString(const void* base, uint32_t off, char* out, int cap)
    {
        out[0] = 0;
        if (!off) return false;
        const wchar_t* d = At<wchar_t*>(base, off);
        const int n = At<int32_t>(base, off + 8);
        if (!Valid(d) || n <= 1 || n > 128) return false;
        const int w = WideCharToMultiByte(CP_UTF8, 0, d, n - 1, out, cap - 1, nullptr, nullptr);
        out[w > 0 ? w : 0] = 0;
        return out[0] != 0;
    }

    // ---- holding a Tek Rifle? -------------------------------------------------------
    inline bool HoldingTekRifle(void* pawn)
    {
        UFunction* fn = EngineRefs::g_refs.charGetWeapon;
        if (!fn) return false;
        struct { UObject* ReturnValue; } p{};
        UObject::ProcessEvent(pawn, fn, &p);
        if (!Valid(p.ReturnValue)) return false;
        static void* s_cls = nullptr; static bool s_tek = false;
        if (p.ReturnValue->Class != s_cls)
        {
            s_cls = p.ReturnValue->Class;
            s_tek = false;
            int depth = 0;
            for (UStruct* s = p.ReturnValue->Class; Valid(s) && depth < 8 && !s_tek; s = s->SuperField, depth++)
                if (s->GetName().find("WeapTekRifle") != std::string::npos) s_tek = true;
        }
        return s_tek;
    }

    // ---- the aimed actor ---------------------------------------------------------------
    inline UObject* AimedActor(void* pawn, V3& impact, uint8_t channel = kChannelVis)
    {
        UFunction* fn = EngineRefs::g_refs.charGetAimedActor;
        if (!fn) return nullptr;
        alignas(16) uint8_t parms[0xA0] = {};
        At<uint8_t>(parms, 0x88) = channel;            // CollisionChannel
        At<float>(parms, 0x8C)   = kMaxDistCm;         // MaxDistanceOverride
        At<float>(parms, 0x90)   = 0.f;                // CheckRadius
        At<bool>(parms, 0x94)    = true;               // bForceUseCameraLocation
        At<bool>(parms, 0x95)    = false;              // bForceUpdateAimedActors
        UObject::ProcessEvent(pawn, fn, parms);
        if (!(At<uint8_t>(parms, 0x00) & 1)) return nullptr;   // bBlockingHit (bitfield, bit 0)

        const int32_t idx = At<int32_t>(parms, 0x60), serial = At<int32_t>(parms, 0x64);
        auto& objs = UObject::GetGlobalObjects();
        if (idx <= 0 || idx >= objs.Count()) return nullptr;
        FUObjectItem* item = objs.GetItemByIndex(idx);
        if (!item || item->SerialNumber != serial || !Valid(item->Object)) return nullptr;
        impact = At<V3>(parms, 0x20);                  // ImpactPoint
        return item->Object;
    }

    // ---- learned damage per hit ----------------------------------------------------------
    struct Learn { float hits[4] = {}; int n = 0, next = 0; };
    inline std::unordered_map<void*, Learn> g_learn;     // per target class
    inline void*    g_lastTarget = nullptr;
    inline float    g_lastHealth = -1.f;
    inline uint64_t g_lastFireMs = 0;

    inline float AvgHit(void* cls)
    {
        auto it = g_learn.find(cls);
        if (it == g_learn.end() || it->second.n == 0) return 0.f;
        float s = 0.f;
        for (int i = 0; i < it->second.n; i++) s += it->second.hits[i];
        return s / it->second.n;
    }

    // ---- game thread, every frame (DrawHUD) ------------------------------------------------
    inline void Tick(AHUD* hud, bool menuOpen)
    {
        using S = Settings::Hud;
        auto none = [] { g_lastTarget = nullptr; Clear(); };
        if (!S::TekIndicator || !Valid(hud) || !EngineRefs::Ready()) { none(); return; }

        Crosshair::Icons(hud);   // sets up the HUD offsets ShouldDraw reads
        if (!Crosshair::ShouldDraw(hud, menuOpen)) { none(); return; }

        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        if (!Valid(pc)) { none(); return; }
        void* pawn = At<void*>(pc, OFF_PC_PAWN);
        if (!Valid(pawn)) { none(); return; }
        {
            static void* s_cls = nullptr; static bool s_char = false;   // on foot (not riding)
            const UObject* po = reinterpret_cast<const UObject*>(pawn);
            if (po->Class != s_cls) { s_cls = po->Class; s_char = ChainHas(po, "ShooterCharacter"); }
            if (!s_char) { none(); return; }
        }
        if (!S::TekAnyWeapon && !HoldingTekRifle(pawn)) { none(); return; }

        const uint64_t now = GetTickCount64();
        if (InputBridge::g_down[VK_LBUTTON]) g_lastFireMs = now;

        // Structures on the Visibility channel; dinos and players ignore that
        // channel (Unreal's Pawn preset), so also trace the Pawn channel - a
        // character hit there is the first thing in line.
        V3 impact{};
        UObject* target = AimedActor(pawn, impact);
        {
            V3 impact2{};
            UObject* t2 = AimedActor(pawn, impact2, 2 /*ECC_Pawn*/);
            if (t2 && t2 != pawn && ChainHas(t2, "PrimalCharacter")) { target = t2; impact = impact2; }
        }
        if (!target || target == pawn) { none(); return; }
        const ClassInfo& ci = InfoFor(target);
        if (!ci.cur || !ci.max) { none(); return; }
        const float cur = At<float>(target, ci.cur), max = At<float>(target, ci.max);
        if (!(max > 0.f) || !(cur > 0.f) || cur > max * 1.5f) { none(); return; }

        // Learn: a drop right after you fired is one hit on this kind of target.
        if (target == g_lastTarget && g_lastHealth > 0.f && cur < g_lastHealth - 0.5f && now - g_lastFireMs <= kFireWindowMs)
        {
            Learn& l = g_learn[target->Class];
            l.hits[l.next] = g_lastHealth - cur;
            l.next = (l.next + 1) % 4;
            if (l.n < 4) l.n++;
        }
        g_lastTarget = target;
        g_lastHealth = cur;

        // Range: from your character (not the camera) to the aim point.
        float distM = 0.f;
        {
            const void* root = At<void*>(pawn, 0x268);          // RootComponent
            if (Valid(root))
            {
                const V3 me = At<V3>(root, 0xF0);               // ComponentToWorld translation
                const float dx = impact.x - me.x, dy = impact.y - me.y, dz = impact.z - me.z;
                distM = sqrtf(dx * dx + dy * dy + dz * dz) / 100.f;
            }
        }
        const float range = S::TekRange > 1.f ? S::TekRange : 50.f;

        Snapshot sn;
        sn.valid   = true;
        sn.inRange = distM <= range;
        sn.frac    = cur / max > 1.f ? 1.f : cur / max;
        if (!(ci.tamed && ReadFString(target, ci.tamed, sn.name, sizeof(sn.name))) &&
            !ReadFString(target, ci.name, sn.name, sizeof(sn.name)))
        {
            const std::string cn = reinterpret_cast<const UObject*>(target->Class)->GetName();
            strncpy_s(sn.name, cn.c_str(), _TRUNCATE);
        }
        sprintf_s(sn.hp, "%.0f / %.0f", floorf(cur + 0.5f), floorf(max + 0.5f));
        sprintf_s(sn.pct, "%.0f%%", cur / max * 100.f);
        sprintf_s(sn.dist, "%.0fm", distM);
        if (!sn.inRange) strcpy_s(sn.right, "Out of range");
        else
        {
            const float avg = AvgHit(target->Class);
            if (avg > 0.f) { const int n = (int)ceilf(cur / avg); sprintf_s(sn.right, n == 1 ? "1 shot" : "%d shots", n); }
            else           strcpy_s(sn.right, "-- shots");
        }
        sn.stamp = now;

        AcquireSRWLockExclusive(&g_lock);
        g_snap = sn;
        ReleaseSRWLockExclusive(&g_lock);
    }

    // ---- render thread: the menu's look ---------------------------------------------------
    struct Palette
    {
        ImU32 panel, border, track, text, white, green, red;
    };

    // fTitle / fSmall: the menu's own fonts. Sizes follow Indicator Scale.
    inline void Render(ImDrawList* dl, ImFont* fTitle, ImFont* fSmall, const Palette& p)
    {
        using S = Settings::Hud;
        if (!S::TekIndicator || !dl || !fTitle || !fSmall) return;

        Snapshot sn;
        AcquireSRWLockShared(&g_lock);
        sn = g_snap;
        ReleaseSRWLockShared(&g_lock);
        if (!sn.valid || GetTickCount64() - sn.stamp >= kStaleMs) return;

        const ImVec2 disp = ImGui::GetIO().DisplaySize;
        if (!(disp.x > 0.f && disp.y > 0.f)) return;
        float hr = disp.y / 1440.f; if (hr < 0.25f) hr = 1.f;
        const float k = (S::TekScale > 0.2f ? S::TekScale : 1.f) * kBaseScale * hr;

        const float titleSz = 17.f * k, smallSz = 14.f * k;
        const float pad = roundf(11.f * k), gap = roundf(10.f * k), rounding = roundf(7.f * k);
        const float barH = roundf(6.f * k);

        auto size = [](ImFont* f, float sz, const char* t) { return f->CalcTextSizeA(sz, FLT_MAX, 0.f, t); };
        const ImVec2 nameS  = size(fTitle, titleSz, sn.name);
        const ImVec2 distS  = size(fSmall, smallSz, sn.dist);
        const ImVec2 hpS    = size(fSmall, smallSz, sn.hp);
        const ImVec2 pctS   = size(fSmall, smallSz, sn.pct);
        const ImVec2 rightS = size(fSmall, smallSz, sn.right);

        float inner = 250.f * k;
        if (nameS.x + distS.x + 2.f * gap > inner)                inner = nameS.x + distS.x + 2.f * gap;
        if (hpS.x + gap + pctS.x + rightS.x + 2.f * gap > inner)  inner = hpS.x + gap + pctS.x + rightS.x + 2.f * gap;
        inner = roundf(inner);
        const float W = inner + pad * 2.f;
        const float H = roundf(pad + nameS.y + 7.f * k + barH + 7.f * k + hpS.y + pad);

        // Default: the tuned spot; the X / Y sliders move it from there.
        const float x0 = roundf(disp.x * 0.5f - W * 0.5f + (kBaseX + S::TekOffsetX) * hr);
        const float y0 = roundf(disp.y * 0.5f + 40.f * k + (kBaseY + S::TekOffsetY) * hr);

        const ImU32 state = sn.inRange ? p.green : p.red;

        // Panel: soft shadow, rounded card, 1px border - the menu's child panels.
        dl->AddRectFilled(ImVec2(x0 + 2.f, y0 + 3.f), ImVec2(x0 + W + 2.f, y0 + H + 3.f), IM_COL32(0, 0, 0, 70), rounding);
        dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x0 + W, y0 + H), p.panel, rounding);
        dl->AddRect(ImVec2(x0, y0), ImVec2(x0 + W, y0 + H), p.border, rounding, 0, 1.f);

        // Title row.
        float y = y0 + pad;
        dl->AddText(fTitle, titleSz, ImVec2(roundf(x0 + pad), roundf(y)), p.white, sn.name);
        dl->AddText(fSmall, smallSz, ImVec2(roundf(x0 + W - pad - distS.x), roundf(y + (nameS.y - distS.y) * 0.5f)),
                    sn.inRange ? p.text : p.red, sn.dist);
        y += nameS.y + 7.f * k;

        // Bar: rounded track + rounded fill, like the menu's sliders.
        const float bx = x0 + pad;
        dl->AddRectFilled(ImVec2(bx, y), ImVec2(bx + inner, y + barH), p.track, barH * 0.5f);
        const float fw = roundf(inner * sn.frac);
        if (fw > 0.f) dl->AddRectFilled(ImVec2(bx, y), ImVec2(bx + (fw < barH ? barH : fw), y + barH), state, barH * 0.5f);
        y += barH + 7.f * k;

        // Bottom row.
        dl->AddText(fSmall, smallSz, ImVec2(roundf(x0 + pad), roundf(y)), p.white, sn.hp);
        dl->AddText(fSmall, smallSz, ImVec2(roundf(x0 + pad + hpS.x + gap), roundf(y)), p.text, sn.pct);
        dl->AddText(fSmall, smallSz, ImVec2(roundf(x0 + W - pad - rightS.x), roundf(y)), sn.inRange ? p.white : p.red, sn.right);
    }
}

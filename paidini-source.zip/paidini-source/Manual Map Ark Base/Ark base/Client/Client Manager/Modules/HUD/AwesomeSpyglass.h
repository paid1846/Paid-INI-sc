#pragma once
// ============================================================================
// Awesome Spyglass - a better spyglass: aim at anything and a panel under the
// crosshair says what it is. Drawn with ARK's own HUD canvas (DrawRect /
// DrawTexture / DrawText in SansationBold18) so it looks like part of the game
// and can show the real item icon.
//
//   STRUCTURES  item icon, name, owning tribe, "Offline 13:57:42" (time since
//               an owner was last in range - enemy / unowned only) or who
//               placed it, health
//   DINOS       name / tamed name, level, Wild or tribe, sex, KO / dead,
//               imprint, colour regions, health, torpor, stats when real;
//               baby age, neutered, mutations, who tamed it, who is riding it,
//               taming progress + effectiveness on a knocked-out wild dino
//   PLAYERS     held weapon / tool (name + icon in the box), name, level,
//               tribe, KO / dead / sleeping (logged out), platform name, and
//               just two bars: health (green) and torpor (purple)
//   CONTAINERS  locked / PIN locked; item count for your own and unowned
//               containers and every death bag (not enemy vaults / turrets);
//               a bag's "Decomposes in" timer
//   ANYTHING ELSE WITH HEALTH  name, owner, health
//
// DINO STATS - what is shown for each kind, all of it real:
//   wild        level, health, torpor (nothing else is sent - a note says so)
//   your tames  level (wild + levels since taming), health, torpor and the
//               full stat grid
//   enemy tames the grid only if the server sent their stats, else the note
//
// ONLY REAL DATA. What the server sends a client (read live, Store build):
//   - level (Base + Extra), replicated health / torpor, sex, colours, imprint:
//     always.
//   - MaxStatusValues: health always; the other stats only for some actors
//     (your tames, other players). For a wild dino every other entry is just
//     the species default - the same numbers as the status component class's
//     default object. So the stat grid only shows when at least one stat
//     differs from that default (= the server really sent them).
//   - NumberOfLevelUpPointsApplied / ...Tamed (the stat points) carry no
//     replication flag; read live they were 0 on every dino, own tames too.
//     They are read anyway, every frame, and shown as "(wild-tamed)" the moment
//     the server has put real numbers there - never computed or guessed. (The
//     old ArkHoles maths rebuilt them from class defaults and produced nonsense,
//     e.g. 150 points in food.) The first time real points are seen, one line
//     goes to debug.log.
//   - When those are empty (the usual case), the points are CALCULATED from
//     the real stat values with ARK's stat formula and the official server
//     multipliers - see "stat point estimate" below - in the same "(12-5)" form.
//     Wild dinos: health only (the one value the server sends). Your tames:
//     every stat, solved so the wild points add up to the wild level and the
//     tamed points to the levels gained since taming. A stat the formula
//     cannot place exactly is left blank instead of guessed.
// Offline timer: GameState NetworkTime - PrimalStructure.LastInAllyRangeTime,
// within 60 days (the same reading MonsterINI's spyglass makes).
//
// TARGETING: ARK's own aim trace, APrimalCharacter::GetAimedActor. Characters
// ignore the Visibility channel (Unreal's Pawn preset), so the Pawn channel is
// traced first for dinos / players, then Visibility for structures, then
// channel 1. Sleeping and dead bodies are ragdolls - their capsule no longer
// blocks any trace, so the ray goes straight through to the floor under them.
// For those, ARK's own HUD target is used (ShooterHUD.LastTargetedActor, a
// weak pointer the game sets while you look at something and clears when you
// look away - the same target its "<name> - Lvl 120 (Sleeping)" text uses):
// it wins whenever it is a character and the trace found no character. Kept: the 5 s linger after you look away (re-found through
// GObjects by index + serial, so a destroyed actor is never read), hiding while
// any game screen / the menu is open, dropping on a world change.
//
// Extra details (rider, tamer, mutations, baby age, taming, held item, lock,
// item count) are all read by NAME through reflection, cached per class. A
// field this build does not have, or that the server leaves at zero, simply
// drops its line - nothing is guessed. A logged-out player is one with
// bIsSleeping set and no torpor; a knocked-out one has torpor. (Not
// APawn::PlayerState - the client only ever has its own; read live, it is
// null on every other player, online or not.)
//
// Offsets (live): character ReplicatedCurrentHealth 0x964 / Max 0x968,
// ReplicatedCurrentTorpor 0x96C / Max 0x970, bIsSleeping 0x8B4, status
// component 0xD10; dino ColorSetIndices 0x15F0. Status component:
// MaxStatusValues 0xD8, BaseCharacterLevel 0x6CC, ExtraCharacterLevel 0x6D0
// (uint16), DinoImprintingQuality 0xB6C. Names / owners / structure health
// are found by reflection per class.
//
// LOCK (Settings::Hud::SpyglassLockKey): press the key while the panel shows
// something and the panel stays on it - wherever you look - with every value
// re-read each frame, until you press the key again or the thing is gone
// (destroyed, or out of render: the client drops an actor once it leaves
// network relevancy, and the index + serial check catches that the same
// frame). The lock survives game screens and the menu (the panel hides, the
// lock stays) and is dropped on a world change.
//
// THREADING: all on the game thread - Tick runs from the DrawHUD hook after
// ARK's own HUD, reads the target, then draws on the HUD canvas.
// ============================================================================
#include <Global.h>
#include <cmath>
#include <cstdio>
#include <cstdarg>
#include <algorithm>
#include <string>
#include <unordered_map>
#include <vector>
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Misc/QuickPickup.h"   // PropOffset
#include "Client Manager/Modules/HUD/Crosshair.h"      // ShouldDraw (HUD up, no inventory, no menu)
#include "Client Manager/Modules/Keybinds/Keybinds.h"   // ImGuiKeyToVk
#include "Client Manager/Modules/UI/Input Bridge/InputBridge.h"
#include "Client Manager/Modules/Notifications/Notifications.h"
#include "Client Manager/Modules/HUD/SpyglassBackground.h"   // ARK panel texture

namespace AwesomeSpyglass
{
    enum EStat : uint8_t { HEALTH = 0, STAMINA = 1, TORPOR = 2, OXYGEN = 3, FOOD = 4, WATER = 5,
                           TEMP = 6, WEIGHT = 7, MELEE = 8, SPEED = 9 };
    enum Kind : uint8_t { K_None = 0, K_Dino, K_Player, K_Character, K_Structure, K_Targetable };
    enum Rel  : uint8_t { R_Wild = 0, R_Tribe, R_Enemy, R_Unowned };

    inline constexpr uintptr_t OFF_MaxStatus      = 0x00D8;   // status comp float[12]
    inline constexpr uintptr_t OFF_BaseLevel      = 0x06CC;   // int32
    inline constexpr uintptr_t OFF_ExtraLevel     = 0x06D0;   // uint16
    inline constexpr uintptr_t OFF_Imprint        = 0x0B6C;   // float
    inline constexpr uintptr_t OFF_Team           = 0x0230;
    inline constexpr uintptr_t OFF_RepHealth      = 0x0964;
    inline constexpr uintptr_t OFF_RepMaxHealth   = 0x0968;
    inline constexpr uintptr_t OFF_RepTorpor      = 0x096C;
    inline constexpr uintptr_t OFF_RepMaxTorpor   = 0x0970;
    inline constexpr uintptr_t OFF_bIsSleeping    = 0x08B4;   // bit 0x01: knocked out
    inline constexpr uintptr_t OFF_StatusComp     = 0x0D10;
    inline constexpr uintptr_t OFF_ColorSet       = 0x15F0;   // uint8[6]
    inline constexpr uintptr_t OFF_PC_PAWN        = 0x04E8;
    inline constexpr uintptr_t OFF_ROOT           = 0x0268;
    inline constexpr uintptr_t OFF_C2W_POS        = 0x00F0;
    inline constexpr int32_t   kFirstPlayerTeam   = 50000;    // teams below this are wild

    inline constexpr uint64_t kLingerMs   = 5000;    // panel stays this long after you look away
    inline constexpr float    kMaxDistCm  = 100000.f;

    struct V3 { float x, y, z; };

    inline bool Valid(const void* p) { const uintptr_t v = reinterpret_cast<uintptr_t>(p); return v > 0x10000 && v < 0x7FFFFFFFFFFF; }
    template <typename T> inline T& At(const void* b, uintptr_t o) { return *reinterpret_cast<T*>(reinterpret_cast<uintptr_t>(b) + o); }

    // ---- what the panel shows --------------------------------------------------------------
    struct Target
    {
        bool      valid = false;
        Kind      kind = K_None;
        Rel       rel = R_Wild;
        char      name[96]  = {};      // species / player name / structure name
        char      sub[96]   = {};      // tamed name / platform name / placed by
        char      tribe[64] = {};      // tribe or owner name
        int       level = 0, baseLevel = 0, extraLevel = 0;
        bool      tamed = false, conscious = true, female = false, dead = false, hasStats = false;
        float     imprint = 0.f, distM = 0.f;
        float     cur[12] = {}, max[12] = {};
        uint8_t   colors[6] = {};
        bool      hasColors = false;
        uint8_t   wildPts[12] = {}, tamedPts[12] = {};   // as the server left them
        bool      hasPoints = false;                     // any of them non-zero
        int16_t   estW[12] = {}, estT[12] = {};          // calculated points (official multipliers)
        bool      estKnown[12] = {};                     // per stat: calculated and unambiguous
        bool      hasEst = false;
        double    offlineSec = -1.0;   // structures: since an owner was last in range (-1 = unknown)
        UTexture* icon = nullptr;      // structure: its item icon; player: the held item's icon

        // players
        char      held[64] = {};       // weapon / tool in hand
        bool      loggedOut = false;   // sleeping body, no PlayerState
        // dinos
        char      tamer[64] = {}, rider[64] = {};
        int       mutM = 0, mutF = 0;
        float     babyAge = -1.f;      // 0..1 while a baby
        bool      neutered = false;
        float     tameProgress = -1.f, tameEff = -1.f;   // knocked-out wild dino, 0..1
        // containers
        int       items = -1, maxItems = -1;
        bool      locked = false, pinLocked = false;
        bool      lootCache = false;    // death bag / item cache
        double    decaySec = -1.0;      // bag / dead body: seconds until it decomposes
    };

    inline bool ChainHas(const UObject* o, const char* name)
    {
        int depth = 0;
        for (UStruct* s = o->Class; Valid(s) && depth < 24; s = s->SuperField, depth++)
            if (s->GetName() == name) return true;
        return false;
    }

    // Any class in the chain whose name contains the text.
    inline bool ChainNameHas(const UObject* o, const char* part)
    {
        int depth = 0;
        for (UStruct* s = o->Class; Valid(s) && depth < 24; s = s->SuperField, depth++)
            if (s->GetName().find(part) != std::string::npos) return true;
        return false;
    }

    // Per-class facts, worked out once per class (class pointers live for the
    // whole session, so nothing is ever evicted and recomputed).
    struct ClassInfo { Kind kind = K_None; bool lootCache = false; };
    inline std::unordered_map<const void*, ClassInfo> g_classInfo;

    inline const ClassInfo& InfoOf(const UObject* o)
    {
        auto it = g_classInfo.find(o->Class);
        if (it != g_classInfo.end()) return it->second;
        ClassInfo ci;
        if      (ChainHas(o, "PrimalDinoCharacter"))   ci.kind = K_Dino;
        else if (ChainHas(o, "ShooterCharacter"))      ci.kind = K_Player;
        else if (ChainHas(o, "PrimalCharacter"))       ci.kind = K_Character;
        else if (ChainHas(o, "PrimalStructure"))       ci.kind = K_Structure;
        else if (ChainHas(o, "PrimalTargetableActor")) ci.kind = K_Targetable;
        ci.lootCache = ci.kind == K_Structure && ChainNameHas(o, "ItemCache");   // death bag / item cache
        return g_classInfo.emplace(o->Class, ci).first->second;
    }
    inline Kind KindOf(const UObject* o) { return InfoOf(o).kind; }
    inline bool IsCharacterKind(Kind k) { return k == K_Dino || k == K_Player || k == K_Character; }

    __declspec(noinline) inline bool CallBool(void* obj, UFunction* fn, bool fallback)
    {
        if (!fn) return fallback;
        __try { struct { bool R; } p{ fallback }; UObject::ProcessEvent(obj, fn, &p); return p.R; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return fallback; }
    }
    inline bool IsAlive(void* a) { return CallBool(a, EngineRefs::g_refs.charIsAlive, true); }

    // Knocked out? ARK's BPIsConscious, else its replicated bIsSleeping flag.
    inline bool IsConscious(void* a)
    {
        if (EngineRefs::g_refs.charIsConscious) return CallBool(a, EngineRefs::g_refs.charIsConscious, true);
        return (At<uint8_t>(a, OFF_bIsSleeping) & 0x01) == 0;
    }

    // A reflected property, cached per (class, name): offset, kind, bool mask.
    enum FType : uint8_t { F_None = 0, F_Other, F_Object, F_Weak, F_Bool };
    struct Field { uint32_t off = 0; FType type = F_None; uint8_t mask = 0; };

    inline Field FindFieldUncached(void* cls, const char* name)
    {
        Field f;
        int depth = 0;
        for (UStruct* s = reinterpret_cast<UStruct*>(cls); Valid(s) && depth < 24; s = s->SuperField, depth++)
            for (UField* p = s->Children; Valid(p); p = p->Next)
            {
                if (p->GetName() != name) continue;
                const std::string t = reinterpret_cast<UObject*>(p->Class)->GetName();
                if (t == "Function") continue;
                f.off = static_cast<uint32_t>(reinterpret_cast<UProperty*>(p)->Offset);
                if (t == "ObjectProperty" || t == "ClassProperty") f.type = F_Object;
                else if (t == "WeakObjectProperty")                f.type = F_Weak;
                else if (t == "BoolProperty")
                {
                    f.type = F_Bool;
                    f.off += At<uint8_t>(p, 0x71);   // ByteOffset
                    f.mask = At<uint8_t>(p, 0x73);   // FieldMask
                }
                else f.type = F_Other;
                return f;
            }
        return f;
    }

    // Keyed by (class, name literal). A few thousand entries at most over a
    // session; never evicted, so a field is looked up by walking the class once.
    struct FieldKey
    {
        const void* cls; const char* name;
        bool operator==(const FieldKey& o) const { return cls == o.cls && name == o.name; }
    };
    struct FieldKeyHash
    {
        size_t operator()(const FieldKey& k) const
        { return std::hash<const void*>()(k.cls) ^ (std::hash<const void*>()(k.name) * 0x9E3779B97F4A7C15ull); }
    };
    inline std::unordered_map<FieldKey, Field, FieldKeyHash> g_fieldCache;

    inline Field GetField(const UObject* o, const char* name)
    {
        const FieldKey key{ o->Class, name };
        auto it = g_fieldCache.find(key);
        if (it != g_fieldCache.end()) return it->second;
        const Field f = FindFieldUncached(o->Class, name);
        g_fieldCache.emplace(key, f);
        return f;
    }

    inline uint32_t Prop(const UObject* o, const char* name) { return GetField(o, name).off; }

    // Object or weak-object property -> live object (weak ones checked by serial).
    inline UObject* ReadObj(const UObject* o, const char* name)
    {
        const Field f = GetField(o, name);
        if (f.type == F_Object) { UObject* v = At<UObject*>(o, f.off); return Valid(v) ? v : nullptr; }
        if (f.type == F_Weak)
        {
            const int32_t idx = At<int32_t>(o, f.off), serial = At<int32_t>(o, f.off + 4);
            auto& objs = UObject::GetGlobalObjects();
            if (idx <= 0 || idx >= objs.Count() || !serial) return nullptr;
            FUObjectItem* item = objs.GetItemByIndex(idx);
            return (item && item->SerialNumber == serial && Valid(item->Object)) ? item->Object : nullptr;
        }
        return nullptr;
    }

    inline bool ReadBool(const UObject* o, const char* name)
    {
        const Field f = GetField(o, name);
        return f.type == F_Bool && f.mask && (At<uint8_t>(o, f.off) & f.mask) != 0;
    }
    inline float ReadF32(const UObject* o, const char* name, float fb = 0.f) { const Field f = GetField(o, name); return f.type == F_Other ? At<float>(o, f.off) : fb; }
    inline int   ReadI32(const UObject* o, const char* name, int fb = 0)     { const Field f = GetField(o, name); return f.type == F_Other ? At<int32_t>(o, f.off) : fb; }

    // FString property -> UTF-8.
    inline bool ReadFStr(const UObject* o, const char* propName, char* out, int cap)
    {
        out[0] = 0;
        const uint32_t off = Prop(o, propName);
        if (!off) return false;
        const wchar_t* d = At<wchar_t*>(o, off);
        const int n = At<int32_t>(o, off + 8);
        if (!Valid(d) || n <= 1 || n > 256) return false;
        const int w = WideCharToMultiByte(CP_UTF8, 0, d, n - 1, out, cap - 1, nullptr, nullptr);
        out[w > 0 ? w : 0] = 0;
        return out[0] != 0 && strcmp(out, "error") != 0;
    }

    // bIsFemale (0x14EE / 0x20 on this build), by reflection like every other bool.
    inline bool IsFemale(const UObject* a) { return ReadBool(a, "bIsFemale"); }

    // The class name, tidied ("Raptor_Character_BP_C" -> "Raptor").
    inline void ClassName(const UObject* a, char* out, int cap)
    {
        std::string cn = reinterpret_cast<const UObject*>(a->Class)->GetName();
        const size_t pos = cn.find("_Character");
        if (pos != std::string::npos) cn = cn.substr(0, pos);
        else for (const char* sfx : { "_BP_C", "_BP", "_C" })
        {
            const size_t sp = cn.rfind(sfx);
            if (sp != std::string::npos && sp + strlen(sfx) == cn.size()) { cn = cn.substr(0, sp); break; }
        }
        for (char& c : cn) if (c == '_') c = ' ';
        strncpy_s(out, cap, cn.c_str(), _TRUNCATE);
    }

    // The structure's icon: ConsumesPrimalItem (the item it is placed from) ->
    // that item class's default object -> ItemIcon. Cached per structure class.
    inline UTexture* StructureIcon(const UObject* a)
    {
        static void* s_cls[64] = {}; static UTexture* s_tex[64] = {}; static int s_n = 0, s_next = 0;
        for (int i = 0; i < s_n; i++) if (s_cls[i] == a->Class) return s_tex[i];
        UTexture* tex = nullptr;
        const uint32_t oc = Prop(a, "ConsumesPrimalItem");
        const UClass* itemCls = oc ? At<UClass*>(a, oc) : nullptr;
        const UObject* cdo = Valid(itemCls) ? itemCls->ClassDefaultObject : nullptr;
        if (Valid(cdo))
        {
            const uint32_t oi = Prop(cdo, "ItemIcon");
            UTexture* t = At<UTexture*>(cdo, oi ? oi : 0x05A0);
            if (Valid(t)) tex = t;
        }
        if (!tex) return nullptr;   // not cached: an icon still streaming in retries
        if (s_n < 64) { s_cls[s_n] = a->Class; s_tex[s_n] = tex; s_n++; }
        else { s_cls[s_next] = a->Class; s_tex[s_next] = tex; s_next = (s_next + 1) % 64; }
        return tex;
    }

    // "WeapTekRifle_C" -> "Tek Rifle": the weapon class name, tidied, for when
    // the item it belongs to is not known.
    inline void TidyWeaponName(const UObject* w, char* out, int cap)
    {
        std::string cn = reinterpret_cast<const UObject*>(w->Class)->GetName();
        for (const char* sfx : { "_C", "_Child", "_BP" })
        {
            const size_t sp = cn.rfind(sfx);
            if (sp != std::string::npos && sp + strlen(sfx) == cn.size()) cn = cn.substr(0, sp);
        }
        if (cn.rfind("Weap", 0) == 0) cn = cn.substr(4);
        std::string o;
        for (size_t i = 0; i < cn.size(); i++)
        {
            const char c = cn[i] == '_' ? ' ' : cn[i];
            if (i && c >= 'A' && c <= 'Z' && o.size() && o.back() != ' ' && !(cn[i - 1] >= 'A' && cn[i - 1] <= 'Z')) o += ' ';
            o += c;
        }
        strncpy_s(out, cap, o.c_str(), _TRUNCATE);
    }

    // A PrimalItem class -> its name and icon (from the class default object).
    // Cached per class once resolved; an unresolved one (icon still streaming)
    // is tried again next time.
    struct ItemInfo { char name[64]; UTexture* icon; };
    inline std::unordered_map<const void*, ItemInfo> g_itemInfo;

    inline bool ItemFromClass(const UClass* cls, char* name, int cap, UTexture** icon)
    {
        if (!Valid(cls)) return false;
        auto it = g_itemInfo.find(cls);
        if (it != g_itemInfo.end())
        {
            strncpy_s(name, cap, it->second.name, _TRUNCATE);
            if (it->second.icon) *icon = it->second.icon;
            return true;
        }
        const UObject* cdo = cls->ClassDefaultObject;
        if (!Valid(cdo) || cdo->Class != cls) return false;   // not really a class
        if (!ChainHas(cdo, "PrimalItem")) return false;
        ItemInfo ii{};
        ReadFStr(cdo, "DescriptiveNameBase", ii.name, sizeof(ii.name));
        const uint32_t oi = Prop(cdo, "ItemIcon");
        UTexture* t = oi ? At<UTexture*>(cdo, oi) : nullptr;
        ii.icon = Valid(t) ? t : nullptr;
        if (!ii.name[0]) return false;
        if (ii.icon) g_itemInfo.emplace(cls, ii);
        strncpy_s(name, cap, ii.name, _TRUNCATE);
        if (ii.icon) *icon = ii.icon;
        return true;
    }

    // What a player is holding: CurrentWeapon -> the item it was made from
    // (AssociatedItemNetInfo.ItemArchetype, else AssociatedPrimalItem's class),
    // else the weapon class name.
    inline void HeldItem(const UObject* player, Target& d)
    {
        const UObject* w = ReadObj(player, "CurrentWeapon");
        if (!w) return;
        const uint32_t on = Prop(w, "AssociatedItemNetInfo");
        if (on && ItemFromClass(At<UClass*>(w, on), d.held, sizeof(d.held), &d.icon)) return;
        if (const UObject* item = ReadObj(w, "AssociatedPrimalItem"))
            if (ItemFromClass(reinterpret_cast<const UClass*>(item->Class), d.held, sizeof(d.held), &d.icon)) return;
        TidyWeaponName(w, d.held, sizeof(d.held));
    }

    // GameState NetworkTime - the server clock LastInAllyRangeTime is stamped in.
    inline double NetworkTime()
    {
        UWorld* w = UWorld::Get();
        const void* gs = Valid(w) ? reinterpret_cast<void*>(w->GameState) : nullptr;
        return Valid(gs) ? At<double>(gs, 0x0598) : 0.0;
    }

    // ---- snapshots -------------------------------------------------------------------------
    // Stats the server really sent: any of them differing from the status
    // component class's defaults means the whole array is replicated for this
    // actor (equal ones are then genuinely unlevelled). Melee / speed are shown
    // as ARK shows them: (1 + value) x 100 %.
    inline void FillStats(const UObject* sc, Target& d)
    {
        static const int kIdx[] = { STAMINA, OXYGEN, FOOD, WEIGHT, MELEE, SPEED };
        const UClass* scCls = reinterpret_cast<const UClass*>(sc->Class);
        const UObject* cdo = Valid(scCls) ? scCls->ClassDefaultObject : nullptr;
        bool real = false;
        for (int i : kIdx)
        {
            d.max[i] = At<float>(sc, OFF_MaxStatus + i * 4);
            if (Valid(cdo) && fabsf(d.max[i] - At<float>(cdo, OFF_MaxStatus + i * 4)) > 0.01f) real = true;
        }
        // Your own tribe's tames always get their full stats from the server
        // (read live) - even one with no levels outside health is real data.
        if (d.rel == R_Tribe) real = true;
        d.max[MELEE] = (1.f + d.max[MELEE]) * 100.f;
        d.max[SPEED] = (1.f + d.max[SPEED]) * 100.f;
        for (int i : kIdx) d.cur[i] = d.max[i];
        d.hasStats = real;
    }

    // ---- stat point estimate -----------------------------------------------------------------
    // ARK's stat formula (the one ARK Smart Breeding uses):
    //
    //   V = ( B * (1 + Lw*Iw*IwM) * TBHM * (1 + IB*Imp*IBM) + Ta*TaM )
    //       * (1 + TE*Tm*TmM) * (1 + Ld*Id*IdM)
    //
    //   B base value (status component class default), Iw / Id per-level gain
    //   wild / tamed (AmountMaxGainedPerLevelUpValue[Tamed]), TBHM tamed base
    //   health multiplier (health only), IB imprint quality, Imp the species'
    //   imprint bonus per stat (DinoMaxStatAddMultiplierImprinting), Ta / Tm
    //   taming add / multiply (TamingMaxStatAdditions / ...Multipliers), TE
    //   taming effectiveness (not sent - solved for), Lw / Ld the points.
    //   Percent stats (melee, speed) use 1 + stored value; everything else the
    //   stored value as is.
    //   Checked live on a bred Tek Stego (lvl 160, no imprint): health
    //   12870.07 = 650 * (1 + 94 * 0.2) + 0.5 * 0.14 -> 94; weight 1150 =
    //   500 * (1 + 65 * 0.02) -> 65; melee 1.2583 = (1 + 0.07) * (1 + 0.4 * 0.44
    //   * TE 1.0) -> 0; stamina / oxygen / food at base -> 0; speed 1.964 =
    //   1 + Ta 0.964 -> 0. 94 + 65 = 159 = level - 1.
    //   Server multipliers: the official defaults - IwM 1 everywhere; health
    //   IdM 0.2, TaM 0.14, TmM 0.44; melee IdM 0.17, TaM 0.14, TmM 0.44; the
    //   rest 1. TaM / TmM only scale positive bonuses. IBM 1.
    //
    // Wild dinos: only health is sent, so only health is solved:
    //   Lw = (V / B - 1) / Iw. Read live on this server it lands on whole
    //   numbers (Ptero 504 / 210 -> 7, Dodo 160 / 40 -> 15, Dilo 312 / 130 -> 7),
    //   which is the formula agreeing with the server.
    // Tames: for each stat every (Lw, Ld) that reproduces the value exactly is
    //   collected (stats with a taming multiplier give a TE for each, and those
    //   TEs must agree); then the combination is kept whose points add up to
    //   the dino's own numbers - wild points = BaseLevel - 1, tamed points =
    //   ExtraCharacterLevel. A stat is shown only if every surviving solution
    //   agrees on it. On a server with changed multipliers the values stop
    //   fitting and the stats simply stay blank.
    inline constexpr int kEstStats[7] = { HEALTH, STAMINA, OXYGEN, FOOD, WEIGHT, MELEE, SPEED };
    inline float OffIdM(int s) { return s == HEALTH ? 0.2f : s == MELEE ? 0.17f : 1.f; }
    inline float OffTaM(int s) { return (s == HEALTH || s == MELEE) ? 0.14f : 1.f; }
    inline float OffTmM(int s) { return (s == HEALTH || s == MELEE) ? 0.44f : 1.f; }

    struct StatP { double V = 0, B = 0, Iw = 0, Id = 0, Ta = 0, Tm = 0, TB = 1, imp = 1; bool use = false; };
    struct Cand  { int16_t lw, ld; float te; };          // te < 0: this stat does not depend on TE

    inline bool LoadStatParams(const UObject* actor, const UObject* sc, float imprint, StatP sp[12])
    {
        const UClass* scCls = reinterpret_cast<const UClass*>(sc->Class);
        const UObject* cdo = Valid(scCls) ? scCls->ClassDefaultObject : nullptr;
        if (!Valid(cdo)) return false;
        auto off = [&](const char* n, uint32_t fb) { const uint32_t o = Prop(sc, n); return o ? o : fb; };
        const uint32_t oInc  = off("AmountMaxGainedPerLevelUpValue", 0x1E8);
        const uint32_t oIncT = off("AmountMaxGainedPerLevelUpValueTamed", 0x218);
        const uint32_t oImp  = off("DinoMaxStatAddMultiplierImprinting", 0xB3C);
        const uint32_t oTa = Prop(sc, "TamingMaxStatAdditions"), oTm = Prop(sc, "TamingMaxStatMultipliers");
        uint32_t oTb = Prop(sc, "TamedBaseHealthMultiplier");
        const UObject* tbObj = sc;
        if (!oTb) { oTb = Prop(actor, "TamedBaseHealthMultiplier"); tbObj = actor; }
        for (int st : kEstStats)
        {
            StatP& q = sp[st];
            // Melee and speed are the percentage stats (shown as 1 + value).
            // NOT MaxGainedPerLevelUpValueIsPercent - read live it is 1 on all
            // twelve stats (it means "levels add a percentage of base").
            const bool pct = st == MELEE || st == SPEED;
            const double stored = At<float>(sc, OFF_MaxStatus + st * 4), base = At<float>(cdo, OFF_MaxStatus + st * 4);
            q.V   = pct ? 1.0 + stored : stored;
            q.B   = pct ? 1.0 + base : base;
            q.Iw  = At<float>(sc, oInc + st * 4);
            q.Id  = At<float>(sc, oIncT + st * 4);
            q.Ta  = oTa ? At<float>(sc, oTa + st * 4) : 0.0;
            q.Tm  = oTm ? At<float>(sc, oTm + st * 4) : 0.0;
            q.TB  = (st == HEALTH && oTb) ? At<float>(tbObj, oTb) : 1.0;
            if (!(q.TB > 0.0)) q.TB = 1.0;
            q.imp = 1.0 + imprint * At<float>(sc, oImp + st * 4);
            q.use = q.B > 0.0 && q.V > 0.0 && q.V < 1.0e7;    // INF-weight servers: skip
        }
        return true;
    }

    // Every (Lw, Ld) reproducing this stat's value.
    inline void StatCandidates(const StatP& q, int st, int maxLw, int maxLd, std::vector<Cand>& out)
    {
        const double IdE = q.Id * OffIdM(st);
        const double TaE = q.Ta > 0 ? q.Ta * OffTaM(st) : q.Ta;
        const double TmE = q.Tm > 0 ? q.Tm * OffTmM(st) : q.Tm;
        const double baseK = q.B * q.TB * q.imp;
        for (int ld = 0; ld <= maxLd; ld++)
        {
            if (IdE <= 0.0 && ld > 0) break;
            const double X = q.V / (1.0 + ld * IdE);
            if (TmE == 0.0)
            {
                if (q.Iw <= 0.0)
                {
                    // wild points do nothing here: the value fixes Ld alone
                    if (fabs(X - (baseK + TaE)) <= 2.0e-4 * X) out.push_back({ 0, (int16_t)ld, -1.f });
                    continue;
                }
                const double lw = ((X - TaE) / baseK - 1.0) / q.Iw;
                const double r = floor(lw + 0.5);
                if (r < 0 || r > maxLw || fabs(lw - r) > 0.03) continue;
                out.push_back({ (int16_t)r, (int16_t)ld, -1.f });
            }
            else
            {
                for (int lw = 0; lw <= maxLw; lw++)
                {
                    if (q.Iw <= 0.0 && lw > 0) break;
                    const double w = baseK * (1.0 + lw * q.Iw) + TaE;
                    if (w <= 0.0) continue;
                    const double te = (X / w - 1.0) / TmE;
                    if (te >= -0.0005 && te <= 1.0005) out.push_back({ (int16_t)lw, (int16_t)ld, (float)te });
                    if (out.size() > 200000) return;
                }
            }
        }
    }

    inline void SolvePoints(const StatP sp[12], int wildTotal, int domTotal, Target& d)
    {
        if (wildTotal < 0 || domTotal < 0 || wildTotal > 2000 || domTotal > 1000) return;
        std::vector<Cand> cand[12];
        int indep[8], ni = 0, dep[8], nd = 0, unknown = 0;
        for (int st : kEstStats)
        {
            if (!sp[st].use) { unknown++; continue; }
            StatCandidates(sp[st], st, wildTotal, domTotal, cand[st]);
            if (cand[st].empty()) { unknown++; continue; }
            bool te = false;
            for (const Cand& c : cand[st]) if (c.te >= 0.f) { te = true; break; }
            (te ? dep[nd++] : indep[ni++]) = st;
        }
        if (nd > 2 || (unknown && nd > 1)) return;   // too open to pin down
        const bool exact = unknown == 0;

        // All combinations of the TE-free stats.
        struct Combo { int16_t ld, lw; uint16_t pick[8]; };
        std::vector<Combo> combos(1, Combo{ 0, 0, {} });
        for (int i = 0; i < ni; i++)
        {
            std::vector<Combo> nx;
            const auto& L = cand[indep[i]];
            for (const Combo& c : combos)
                for (size_t j = 0; j < L.size(); j++)
                {
                    Combo n = c;
                    n.ld = (int16_t)(n.ld + L[j].ld); n.lw = (int16_t)(n.lw + L[j].lw); n.pick[i] = (uint16_t)j;
                    if (n.ld <= domTotal && n.lw <= wildTotal) nx.push_back(n);
                }
            if (nx.empty() || nx.size() > 60000) return;
            combos.swap(nx);
        }
        auto fits = [&](int ld, int lw) { return exact ? (ld == domTotal && lw == wildTotal) : (ld <= domTotal && lw <= wildTotal); };

        // Solutions, as (combo, dep candidate a, dep candidate b).
        struct Sol { int combo; int a, b; };
        std::vector<Sol> sols;
        const size_t kMaxSols = 4096;
        if (nd == 0)
        {
            for (size_t c = 0; c < combos.size() && sols.size() < kMaxSols; c++)
                if (fits(combos[c].ld, combos[c].lw)) sols.push_back({ (int)c, -1, -1 });
        }
        else
        {
            // Index the combos by their sums for the exact case.
            std::unordered_map<int, std::vector<int>> byKey;
            if (exact) for (size_t c = 0; c < combos.size(); c++) byKey[combos[c].ld * 4096 + combos[c].lw].push_back((int)c);
            auto addFor = [&](int ld, int lw, int a, int b) {
                if (exact)
                {
                    const int needLd = domTotal - ld, needLw = wildTotal - lw;
                    if (needLd < 0 || needLw < 0) return;
                    auto it = byKey.find(needLd * 4096 + needLw);
                    if (it != byKey.end()) for (int c : it->second) { if (sols.size() >= kMaxSols) return; sols.push_back({ c, a, b }); }
                }
                else
                    for (size_t c = 0; c < combos.size() && sols.size() < kMaxSols; c++)
                        if (fits(combos[c].ld + ld, combos[c].lw + lw)) sols.push_back({ (int)c, a, b });
            };
            const auto& A = cand[dep[0]];
            if (nd == 1)
            {
                if (!exact && A.size() * combos.size() > 4000000) return;
                for (size_t i = 0; i < A.size() && sols.size() < kMaxSols; i++) addFor(A[i].ld, A[i].lw, (int)i, -1);
            }
            else
            {
                // Two TE stats (health + melee): their TEs must agree.
                std::vector<int> order(cand[dep[1]].size());
                for (size_t i = 0; i < order.size(); i++) order[i] = (int)i;
                const auto& Bv = cand[dep[1]];
                std::sort(order.begin(), order.end(), [&](int x, int y) { return Bv[x].te < Bv[y].te; });
                for (size_t i = 0; i < A.size() && sols.size() < kMaxSols; i++)
                {
                    const float lo = A[i].te - 0.002f, hi = A[i].te + 0.002f;
                    auto it = std::lower_bound(order.begin(), order.end(), lo, [&](int x, float v) { return Bv[x].te < v; });
                    for (; it != order.end() && Bv[*it].te <= hi && sols.size() < kMaxSols; ++it)
                        addFor(A[i].ld + Bv[*it].ld, A[i].lw + Bv[*it].lw, (int)i, *it);
                }
            }
        }
        if (sols.empty()) return;

        // Keep each stat only where every solution agrees.
        auto pickOf = [&](const Sol& so, int st, int16_t& lw, int16_t& ld) -> bool {
            for (int i = 0; i < ni; i++) if (indep[i] == st) { const Cand& c = cand[st][combos[so.combo].pick[i]]; lw = c.lw; ld = c.ld; return true; }
            if (nd > 0 && dep[0] == st && so.a >= 0) { lw = cand[st][so.a].lw; ld = cand[st][so.a].ld; return true; }
            if (nd > 1 && dep[1] == st && so.b >= 0) { lw = cand[st][so.b].lw; ld = cand[st][so.b].ld; return true; }
            return false;
        };
        for (int st : kEstStats)
        {
            int16_t lw0, ld0;
            if (!pickOf(sols[0], st, lw0, ld0)) continue;
            bool same = true;
            for (size_t k = 1; k < sols.size() && same; k++)
            {
                int16_t lw, ld;
                if (!pickOf(sols[k], st, lw, ld) || lw != lw0 || ld != ld0) same = false;
            }
            if (same) { d.estW[st] = lw0; d.estT[st] = ld0; d.estKnown[st] = true; d.hasEst = true; }
        }
    }

    // Cached per dino: recomputed only when its level, imprint or values change.
    struct EstCacheE { uint64_t sig; int16_t w[12], t[12]; bool known[12]; bool has; };
    inline std::unordered_map<const void*, EstCacheE> g_estCache;

    inline void EstimatePoints(const UObject* actor, const UObject* sc, Target& d)
    {
        if (d.kind != K_Dino || d.hasPoints || d.dead) return;
        const bool tamedReal = d.tamed && d.hasStats;
        if (!tamedReal && d.tamed) return;               // enemy tame without values: nothing to solve

        uint64_t sig = 1469598103934665603ull;
        auto mix = [&](uint64_t v) { sig = (sig ^ v) * 1099511628211ull; };
        mix((uint64_t)d.baseLevel); mix((uint64_t)d.extraLevel); mix((uint64_t)(d.imprint * 10000.f)); mix(tamedReal);
        for (int st : kEstStats) { uint32_t bits; const float v = At<float>(sc, OFF_MaxStatus + st * 4); memcpy(&bits, &v, 4); mix(bits); }
        { uint32_t bits; const float hp = d.max[HEALTH]; memcpy(&bits, &hp, 4); mix(bits); }

        auto it = g_estCache.find(actor);
        if (it == g_estCache.end() || it->second.sig != sig)
        {
            Target tmp;
            StatP sp[12];
            if (LoadStatParams(actor, sc, d.imprint, sp))
            {
                if (tamedReal) SolvePoints(sp, d.baseLevel - 1, d.extraLevel, tmp);
                else
                {
                    // Wild: health, the one stat the server sends.
                    const StatP& h = sp[HEALTH];
                    if (h.B > 0.0 && h.Iw > 0.0 && d.max[HEALTH] > 0.f)
                    {
                        const double lw = ((double)d.max[HEALTH] / h.B - 1.0) / h.Iw, r = floor(lw + 0.5);
                        if (r >= 0 && r <= d.baseLevel - 1 && fabs(lw - r) <= 0.03)
                        { tmp.estW[HEALTH] = (int16_t)r; tmp.estKnown[HEALTH] = true; tmp.hasEst = true; }
                    }
                }
            }
            if (g_estCache.size() > 512) g_estCache.clear();
            EstCacheE e{ sig, {}, {}, {}, tmp.hasEst };
            memcpy(e.w, tmp.estW, sizeof(e.w)); memcpy(e.t, tmp.estT, sizeof(e.t)); memcpy(e.known, tmp.estKnown, sizeof(e.known));
            it = g_estCache.insert_or_assign(actor, e).first;

            static int s_logged = 0;
            if (s_logged < 6)
            {
                s_logged++;
                Logger::Log("[Spyglass] points %s (%s lvl %d+%d imprint %.2f): HP %d-%d%s ST %d-%d%s OX %d-%d%s FD %d-%d%s WT %d-%d%s MEL %d-%d%s SPD %d-%d%s",
                            tmp.hasEst ? "calculated" : "not solvable", tamedReal ? "tame" : "wild", d.baseLevel, d.extraLevel, d.imprint,
                            tmp.estW[0], tmp.estT[0], tmp.estKnown[0] ? "" : "?", tmp.estW[1], tmp.estT[1], tmp.estKnown[1] ? "" : "?",
                            tmp.estW[3], tmp.estT[3], tmp.estKnown[3] ? "" : "?", tmp.estW[4], tmp.estT[4], tmp.estKnown[4] ? "" : "?",
                            tmp.estW[7], tmp.estT[7], tmp.estKnown[7] ? "" : "?", tmp.estW[8], tmp.estT[8], tmp.estKnown[8] ? "" : "?",
                            tmp.estW[9], tmp.estT[9], tmp.estKnown[9] ? "" : "?");
            }
        }
        memcpy(d.estW, it->second.w, sizeof(d.estW));
        memcpy(d.estT, it->second.t, sizeof(d.estT));
        memcpy(d.estKnown, it->second.known, sizeof(d.estKnown));
        d.hasEst = it->second.has;
    }

    // Dinos, players and other characters.
    inline void FillCharacter(const UObject* a, Target& d)
    {
        UObject* mut = const_cast<UObject*>(a);
        d.dead      = !IsAlive(mut);
        d.conscious = d.dead ? false : IsConscious(mut);

        d.cur[HEALTH] = At<float>(a, OFF_RepHealth);
        d.max[HEALTH] = At<float>(a, OFF_RepMaxHealth);
        d.cur[TORPOR] = At<float>(a, OFF_RepTorpor);
        d.max[TORPOR] = At<float>(a, OFF_RepMaxTorpor);
        ReadFStr(a, "TribeName", d.tribe, sizeof(d.tribe));

        if (d.kind == K_Dino)
        {
            d.tamed  = d.rel != R_Wild;
            d.female = IsFemale(a);
            for (int i = 0; i < 6; i++) d.colors[i] = At<uint8_t>(a, OFF_ColorSet + i);
            d.hasColors = true;
            d.neutered  = ReadBool(a, "bNeutered");
            if (ReadBool(a, "bIsBaby"))
            {
                const float age = ReadF32(a, "BabyAge", -1.f);
                if (age >= 0.f && age < 1.f) d.babyAge = age;
            }
            if (const UObject* rider = ReadObj(a, "Rider"))
                if (!ReadFStr(rider, "PlayerName", d.rider, sizeof(d.rider))) strcpy_s(d.rider, "someone");
            if (d.tamed)
            {
                ReadFStr(a, "TamedName", d.sub, sizeof(d.sub));
                ReadFStr(a, "TamerString", d.tamer, sizeof(d.tamer));
                d.mutM = ReadI32(a, "RandomMutationsMale");
                d.mutF = ReadI32(a, "RandomMutationsFemale");
                if (d.mutM < 0 || d.mutM > 10000) d.mutM = 0;
                if (d.mutF < 0 || d.mutF > 10000) d.mutF = 0;
            }
            else
            {
                // Taming a knocked-out wild dino: affinity is replicated so the
                // game can draw its own taming bar. Effectiveness drops by
                // 1 / (1 + TameIneffectivenessModifier).
                const float need = ReadF32(a, "RequiredTameAffinity"), have = ReadF32(a, "CurrentTameAffinity");
                if (need > 0.f && have > 0.f)
                {
                    d.tameProgress = (std::min)(1.f, have / need);
                    const float ineff = ReadF32(a, "TameIneffectivenessModifier", -1.f);
                    if (ineff >= 0.f) d.tameEff = 1.f / (1.f + ineff);
                }
            }
        }
        else if (d.kind == K_Player)
        {
            ReadFStr(a, "PlayerName", d.name, sizeof(d.name));
            ReadFStr(a, "PlatformProfileName", d.sub, sizeof(d.sub));
            // A logged-out body: ARK's bIsSleeping, with no torpor (a knocked-out
            // player has torpor). PlayerState is no use here - the client never
            // gets it for anyone but you (read live: null on every other player).
            if (!d.dead && ReadBool(a, "bIsSleeping") && d.cur[TORPOR] <= 0.5f) d.loggedOut = true;
            if (!d.dead) HeldItem(a, d);
        }

        // Dead body: CorpseDestructionTime is the server time it disappears
        // (read live: death time + CorpseLifespan, 1800 s for a player).
        if (d.dead)
        {
            const Field f = GetField(a, "CorpseDestructionTime");
            if (f.type == F_Other)
            {
                const double when = At<double>(a, f.off), now = NetworkTime();
                if (when > 0.0 && now > 0.0 && when > now && when - now < 86400.0) d.decaySec = when - now;
            }
        }

        const UObject* sc = At<UObject*>(a, OFF_StatusComp);
        if (!Valid(sc)) return;
        d.baseLevel  = At<int32_t>(sc, OFF_BaseLevel);
        d.extraLevel = (int)At<uint16_t>(sc, OFF_ExtraLevel);
        d.level      = d.baseLevel + d.extraLevel;

        // Stat points, exactly as they sit in the status component (0x138 wild /
        // 0x144 tamed on this build, found by name). Shown only when non-zero.
        if (d.kind == K_Dino)
        {
            uint32_t ow = Prop(sc, "NumberOfLevelUpPointsApplied"), ot = Prop(sc, "NumberOfLevelUpPointsAppliedTamed");
            if (!ow) ow = 0x138;
            if (!ot) ot = 0x144;
            for (int i = 0; i < 12; i++)
            {
                d.wildPts[i]  = At<uint8_t>(sc, ow + i);
                d.tamedPts[i] = At<uint8_t>(sc, ot + i);
                if (d.wildPts[i] || d.tamedPts[i]) d.hasPoints = true;
            }
            // A wild dino has at most BaseLevel - 1 points in total; anything
            // more is not points (defends against a wrong offset).
            int sum = 0;
            for (int i = 0; i < 12; i++) sum += d.wildPts[i];
            if (sum > d.baseLevel + 300) { d.hasPoints = false; memset(d.wildPts, 0, 12); memset(d.tamedPts, 0, 12); }
            static bool s_pointsLogged = false;
            if (d.hasPoints && !s_pointsLogged)
            {
                s_pointsLogged = true;
                Logger::Log("[Spyglass] real stat points seen (lvl %d+%d): wild %d %d %d %d %d %d %d %d | tamed %d %d %d %d %d %d %d %d",
                            d.baseLevel, d.extraLevel,
                            d.wildPts[0], d.wildPts[1], d.wildPts[3], d.wildPts[4], d.wildPts[7], d.wildPts[8], d.wildPts[9], d.wildPts[2],
                            d.tamedPts[0], d.tamedPts[1], d.tamedPts[3], d.tamedPts[4], d.tamedPts[7], d.tamedPts[8], d.tamedPts[9], d.tamedPts[2]);
            }
        }
        if (d.kind == K_Dino && d.tamed) { const float q = At<float>(sc, OFF_Imprint); if (q > 0.f && q <= 1.f) d.imprint = q; }
        FillStats(sc, d);
        EstimatePoints(a, sc, d);
    }

    // Structures and other targetable actors: name, owner, health, offline timer.
    inline void FillStructure(const UObject* a, Target& d)
    {
        ReadFStr(a, "OwnerName", d.tribe, sizeof(d.tribe));
        ReadFStr(a, "OwningPlayerName", d.sub, sizeof(d.sub));
        const uint32_t oh = Prop(a, "ReplicatedHealth"), om = Prop(a, "MaxHealth");
        if (oh) d.cur[HEALTH] = At<float>(a, oh);
        if (om) d.max[HEALTH] = At<float>(a, om);
        if (d.kind != K_Structure) return;
        d.icon = StructureIcon(a);
        d.locked    = ReadBool(a, "bIsLocked");
        d.pinLocked = ReadBool(a, "bIsPinLocked");
        // Item count: CurrentItemCount (MaxItemCount is NOT the slot limit -
        // read live it just mirrors the count, e.g. a heavy turret 58 / 58).
        // Shown for your own / unowned containers and for death bags; enemy
        // containers and turrets keep it to themselves (their lock shows).
        d.lootCache = InfoOf(a).lootCache;
        if (GetField(a, "CurrentItemCount").type == F_Other && (d.rel != R_Enemy || d.lootCache))
        {
            const int n = ReadI32(a, "CurrentItemCount");
            if (n >= 0 && n < 100000) d.items = n;
        }
        // Bags: NetDestructionTime is the server time it disappears.
        {
            const Field f = GetField(a, "NetDestructionTime");
            if (f.type == F_Other)
            {
                const double when = At<double>(a, f.off), now = NetworkTime();
                if (when > 0.0 && now > 0.0 && when > now && when - now < 86400.0) d.decaySec = when - now;
            }
        }
        if (const uint32_t ol = Prop(a, "LastInAllyRangeTime"))
        {
            const double last = At<double>(a, ol), now = NetworkTime();
            if (last > 0.0 && now > 0.0 && last <= now && now - last < 5184000.0) d.offlineSec = now - last;
        }
    }

    inline Target Snapshot(const UObject* a, const void* me, float distM)
    {
        Target d;
        d.kind  = KindOf(a);
        d.distM = distM;
        if (d.kind == K_None) return d;

        if (!ReadFStr(a, "DescriptiveName", d.name, sizeof(d.name))) ClassName(a, d.name, sizeof(d.name));

        const int32_t team = At<int32_t>(a, OFF_Team);
        const int32_t mine = me ? At<int32_t>(me, OFF_Team) : 0;
        if (mine > 0 && team == mine)     d.rel = R_Tribe;
        else if (team >= kFirstPlayerTeam) d.rel = R_Enemy;
        else if (team <= 0 && !IsCharacterKind(d.kind)) d.rel = R_Unowned;
        else                              d.rel = R_Wild;

        if (IsCharacterKind(d.kind)) FillCharacter(a, d);
        else                         FillStructure(a, d);
        d.valid = true;

        static bool s_logged[8] = {};
        if (!s_logged[d.kind])
        {
            s_logged[d.kind] = true;
            Logger::Log("[Spyglass] first %s: '%s' lvl=%d tribe='%s' sub='%s' hp=%.0f/%.0f stats=%d held='%s' loggedOut=%d "
                        "rider='%s' tamer='%s' mut=%d/%d baby=%.2f neutered=%d taming=%.2f eff=%.2f items=%d/%d locked=%d/%d offline=%.0f",
                        d.kind == K_Dino ? "dino" : d.kind == K_Player ? "player" : d.kind == K_Character ? "character" :
                        d.kind == K_Structure ? "structure" : "targetable",
                        d.name, d.level, d.tribe, d.sub, d.cur[HEALTH], d.max[HEALTH], (int)d.hasStats, d.held, (int)d.loggedOut,
                        d.rider, d.tamer, d.mutM, d.mutF, d.babyAge, (int)d.neutered, d.tameProgress, d.tameEff,
                        d.items, d.maxItems, (int)d.locked, (int)d.pinLocked, d.offlineSec);
        }
        return d;
    }

    // ---- target ----------------------------------------------------------------------------
    struct Hit { UObject* obj = nullptr; int32_t idx = 0, serial = 0; V3 impact{}; };

    inline Hit AimedOn(void* pawn, uint8_t channel)
    {
        Hit h;
        UFunction* fn = EngineRefs::g_refs.charGetAimedActor;
        if (!fn) return h;
        alignas(16) uint8_t parms[0xA0] = {};
        At<uint8_t>(parms, 0x88) = channel;
        At<float>(parms, 0x8C)   = kMaxDistCm;
        At<bool>(parms, 0x94)    = true;         // from the camera
        UObject::ProcessEvent(pawn, fn, parms);
        if (!(At<uint8_t>(parms, 0x00) & 1)) return h;
        const int32_t idx = At<int32_t>(parms, 0x60), serial = At<int32_t>(parms, 0x64);
        auto& objs = UObject::GetGlobalObjects();
        if (idx <= 0 || idx >= objs.Count()) return h;
        FUObjectItem* item = objs.GetItemByIndex(idx);
        if (!item || item->SerialNumber != serial || !Valid(item->Object)) return h;
        h.obj = item->Object; h.idx = idx; h.serial = serial; h.impact = At<V3>(parms, 0x20);
        return h;
    }

    // Re-find a held target; null once it is gone (destroyed / slot reused).
    inline UObject* Resolve(int32_t idx, int32_t serial)
    {
        auto& objs = UObject::GetGlobalObjects();
        if (idx <= 0 || idx >= objs.Count()) return nullptr;
        FUObjectItem* item = objs.GetItemByIndex(idx);
        if (!item || item->SerialNumber != serial || !Valid(item->Object)) return nullptr;
        return item->Object;
    }

    // What each trace hit last frame - for the status line in debug.log.
    inline char g_diag[3][64] = {};

    // ARK's own HUD target (ShooterHUD.LastTargetedActor, weak pointer).
    inline Hit HudTarget(AHUD* hud)
    {
        Hit h;
        const UObject* ho = reinterpret_cast<const UObject*>(hud);
        const Field f = GetField(ho, "LastTargetedActor");
        if (f.type != F_Weak) return h;
        const int32_t idx = At<int32_t>(ho, f.off), serial = At<int32_t>(ho, f.off + 4);
        UObject* o = Resolve(idx, serial);
        if (!o) return h;
        h.obj = o; h.idx = idx; h.serial = serial;
        // Where it is: a character's mesh (a ragdoll moves away from its capsule);
        // anything else, its root. Character.Mesh (0x510) only exists on characters.
        const void* comp = IsCharacterKind(KindOf(o)) ? At<void*>(o, 0x510) : nullptr;
        if (!Valid(comp)) comp = At<void*>(o, OFF_ROOT);
        if (Valid(comp)) h.impact = At<V3>(comp, OFF_C2W_POS);
        return h;
    }

    // Characters on the Pawn channel, then structures / anything on Visibility,
    // then channel 1. The first hit that is something the panel can describe
    // wins - except that ARK's own HUD target takes over when it is a character
    // (sleeping / dead ragdolls) and the traces found none.
    inline Hit AimedTargetUncached(void* pawn, void* me, AHUD* hud);

    // Up to three aim traces + the HUD target: at most 30 times a second (the
    // last result is re-used in between, re-validated by index + serial) -
    // every frame cost real CPU at high frame rates for no visible gain.
    inline Hit AimedTarget(void* pawn, void* me, AHUD* hud)
    {
        static Hit      s_last;
        static uint64_t s_at = 0;
        static void*    s_pawn = nullptr;
        const uint64_t now = GetTickCount64();
        if (pawn == s_pawn && now - s_at < 33)
        {
            if (!s_last.obj) return s_last;
            if (Resolve(s_last.idx, s_last.serial) == s_last.obj) return s_last;
        }
        s_last = AimedTargetUncached(pawn, me, hud);
        s_at = now; s_pawn = pawn;
        return s_last;
    }

    inline Hit AimedTargetUncached(void* pawn, void* me, AHUD* hud)
    {
        static const uint8_t kChannels[] = { 2 /*Pawn*/, 3 /*Visibility*/, 1 /*original*/ };
        Hit found;
        for (int c = 0; c < 3; c++)
        {
            const Hit h = AimedOn(pawn, kChannels[c]);
            if (!h.obj) { strcpy_s(g_diag[c], "nothing"); continue; }
            const bool self = h.obj == pawn || h.obj == me;
            const Kind k = KindOf(h.obj);
            {
                const std::string n = reinterpret_cast<const UObject*>(h.obj->Class)->GetName();
                sprintf_s(g_diag[c], "%.40s%s", n.c_str(), self ? " (you)" : (k == K_None ? " (skipped)" : ""));
            }
            if (found.obj || self || k == K_None) continue;
            if (c == 0 && !IsCharacterKind(k)) continue;   // the Pawn channel is for characters
            found = h;
        }
        if (!found.obj || !IsCharacterKind(KindOf(found.obj)))
        {
            const Hit ht = HudTarget(hud);
            if (ht.obj && ht.obj != pawn && ht.obj != me && IsCharacterKind(KindOf(ht.obj))) return ht;
        }
        return found;
    }

    // ---- state (game thread) --------------------------------------------------------------
    inline Target    g_cached;
    inline UObject*  g_cachedActor = nullptr;
    inline int32_t   g_cachedIdx = 0, g_cachedSerial = 0;
    inline uint64_t  g_lastTargetMs = 0;
    inline UWorld*   g_lastWorld = nullptr;
    inline uint64_t  g_cursorHiddenSince = 0;
    inline bool      g_show = false;

    inline void Reset()
    {
        g_cachedActor = nullptr;
        g_cached.valid = false;
        g_lastTargetMs = 0;
        g_show = false;
    }

    // ---- lock ---------------------------------------------------------------------------
    inline bool    g_locked = false;
    inline void*   g_meChar = nullptr;   // your player character: a new one means you respawned
    inline int32_t g_lockIdx = 0, g_lockSerial = 0;
    inline bool    g_lockKeyWas = false;

    inline void Unlock(const char* why)
    {
        if (!g_locked) return;
        g_locked = false;
        if (why) Notifications::Push(std::string("Spyglass lock: ") + why, IM_COL32(255, 190, 60, 255));
    }

    // Your character, dead or not. POD-only under __try (C2712).
    static bool MeAlive(void* me)
    {
        UFunction* f = EngineRefs::g_refs.charIsAlive;
        if (!f || !me) return true;
        __try
        {
            struct { bool ReturnValue; } p{ false };
            UObject::ProcessEvent(me, f, &p);
            return p.ReturnValue;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return true; }
    }

    // Where a held actor is: a character's mesh (ragdolls drift from the capsule), else its root.
    inline bool ActorPos(const UObject* o, V3& out)
    {
        const void* comp = IsCharacterKind(KindOf(o)) ? At<void*>(o, 0x510) : nullptr;
        if (!Valid(comp)) comp = At<void*>(o, OFF_ROOT);
        if (!Valid(comp)) return false;
        out = At<V3>(comp, OFF_C2W_POS);
        return true;
    }

    inline float DistanceTo(void* pawn, const V3& at)
    {
        const void* root = At<void*>(pawn, OFF_ROOT);
        if (!Valid(root)) return 0.f;
        const V3 me = At<V3>(root, OFF_C2W_POS);
        const float dx = at.x - me.x, dy = at.y - me.y, dz = at.z - me.z;
        return sqrtf(dx * dx + dy * dy + dz * dz) / 100.f;
    }

    // Reads the target (fresh every frame - everything is replicated state, cheap).
    inline void Update(AHUD* hud, bool menuOpen)
    {
        using S = Settings::Hud;
        g_show = false;
        if (!S::Spyglass || !Valid(hud) || !EngineRefs::Ready()) { if (g_cachedActor) Reset(); return; }

        // Any game UI or the menu: gone at once. The OS cursor is the signal ARK
        // gives for its own screens; it must stay hidden for 0.5 s before the
        // panel comes back.
        Crosshair::Icons(hud);
        bool uiOpen = !Crosshair::ShouldDraw(hud, menuOpen);
        {
            CURSORINFO ci{}; ci.cbSize = sizeof(ci);
            const bool cursor = GetCursorInfo(&ci) && (ci.flags & CURSOR_SHOWING);
            const uint64_t t = GetTickCount64();
            if (cursor) g_cursorHiddenSince = 0;
            else if (!g_cursorHiddenSince) g_cursorHiddenSince = t;
            if (cursor || (g_cursorHiddenSince && t - g_cursorHiddenSince < 500)) uiOpen = true;
        }
        // Lock key: edge-triggered, only while the game has focus and no screen is up.
        bool lockPressed = false;
        {
            const int vk = Keybinds::ImGuiKeyToVk(S::SpyglassLockKey);
            const bool down = vk > 0 && vk <= 0xFF && InputBridge::g_down[vk] && !uiOpen && QuickPickup::GameFocused();
            lockPressed = down && !g_lockKeyWas;
            g_lockKeyWas = down;
        }

        if (uiOpen) { Reset(); return; }

        // World change (transfer, loading, main menu): drop everything.
        UWorld* w = UWorld::Get();
        if (w != g_lastWorld) { g_lastWorld = w; g_locked = false; SpyglassBackground::Release(); Reset(); return; }

        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        if (!Valid(pc)) { Reset(); return; }
        void* pawn = At<void*>(pc, OFF_PC_PAWN);          // you, or the dino you ride
        if (!Valid(pawn)) { Reset(); return; }
        void* me = pawn;                                   // team owner
        if (KindOf(reinterpret_cast<const UObject*>(pawn)) != K_Player)
        {
            AActor* rider = pc->LastControlledPlayerCharacter.Get();
            if (Valid(rider)) me = rider;
        }

        // Death drops the lock: a dead character, or a different character
        // (respawn), never keeps watching the old target. Mounting a dino
        // doesn't touch this — `me` stays your player character.
        if (!MeAlive(me) || (me != g_meChar && g_meChar))
        {
            if (g_locked) Unlock("you died");
            Reset();
            g_meChar = me;
            if (!MeAlive(me)) return;
        }
        g_meChar = me;

        const uint64_t now = GetTickCount64();

        // Press: lock what the panel is showing, or let go of the lock.
        if (lockPressed)
        {
            if (g_locked) Unlock("released");
            else if (g_cachedActor && g_cached.valid && Resolve(g_cachedIdx, g_cachedSerial) == g_cachedActor)
            {
                g_locked = true; g_lockIdx = g_cachedIdx; g_lockSerial = g_cachedSerial;
                Notifications::Push(std::string("Spyglass locked: ") + g_cached.name, IM_COL32(90, 220, 255, 255));
            }
        }

        // Locked: follow that one actor, live, until it is gone.
        if (g_locked)
        {
            UObject* o = Resolve(g_lockIdx, g_lockSerial);
            V3 at{};
            if (!o || !ActorPos(o, at)) { Unlock("target out of render"); Reset(); return; }
            g_cached = Snapshot(o, me, DistanceTo(pawn, at));
            g_cachedActor = o; g_cachedIdx = g_lockIdx; g_cachedSerial = g_lockSerial;
            g_lastTargetMs = now;
            g_show = g_cached.valid;
            return;
        }

        const Hit hit = AimedTarget(pawn, me, hud);
        {
            // Logged when the target changes (at most once a second), not on a timer.
            static UObject* s_lastObj = reinterpret_cast<UObject*>(1);
            static uint64_t s_lastLog = 0;
            if (hit.obj != s_lastObj && now - s_lastLog >= 1000)
            {
                s_lastObj = hit.obj; s_lastLog = now;
                Logger::Log("[Spyglass] aim: pawn=%s | visibility=%s | ch1=%s | target %s",
                            g_diag[0], g_diag[1], g_diag[2],
                            hit.obj ? reinterpret_cast<const UObject*>(hit.obj->Class)->GetName().c_str() : "none");
            }
        }

        if (hit.obj)
        {
            g_cached = Snapshot(hit.obj, me, DistanceTo(pawn, hit.impact));
            g_cachedActor = hit.obj; g_cachedIdx = hit.idx; g_cachedSerial = hit.serial;
            g_lastTargetMs = now;
            g_show = g_cached.valid;
            return;
        }

        // Looked away: linger 5 s with live values, then hide.
        UObject* held = g_cachedActor ? Resolve(g_cachedIdx, g_cachedSerial) : nullptr;
        if (!held || held != g_cachedActor || !g_lastTargetMs || now - g_lastTargetMs >= kLingerMs)
        {
            if (g_cachedActor) Reset();
            return;
        }
        const float dist = g_cached.distM;
        g_cached = Snapshot(held, me, dist);
        g_show = g_cached.valid;
    }

    // ---- the panel: ARK's own HUD canvas, straight after DrawHUD ----------------------------
    //
    //   +-------------------------------------------------------------+
    //   | +------+  Tek Floor                                    84m  |
    //   | | icon |  Tribe of Jay                                      |
    //   | +------+  Offline 13:57:42                                  |
    //   | ----------------------------------------------------------- |
    //   | [ 12 ][ 37 ][ 0 ][ 21 ][ 6 ][ 0 ]           (dino colours)   |
    //   | [================= 15K / 15K  Health ===================]  |
    //   | [=================== 0 / 840  Torpor ====================]  |
    //   | Stamina          652 | Weight          INF                  |
    //   | Oxygen           172 | Melee          696%                  |
    //   | Food            5520 | Speed          120%                  |
    //   +-------------------------------------------------------------+
    //
    // Centred under the crosshair. Name colours: your tribe green, enemy red,
    // everyone else grey; the health bar follows (amber for wild / unowned).

    inline UFont* Font() { return EngineRefs::g_refs.fontSansation ? EngineRefs::g_refs.fontSansation : EngineRefs::g_refs.font18; }

    // Panel opacity for the fade in / out; every draw call multiplies by it.
    inline float g_alpha = 1.f;
    inline FLinearColor Fade(const FLinearColor& c) { return FLinearColor(c.R, c.G, c.B, c.A * g_alpha); }

    inline void Rect(AHUD* hud, float x, float y, float w, float h, const FLinearColor& c)
    {
        if (w <= 0.f || h <= 0.f || c.A * g_alpha <= 0.003f) return;
        struct { FLinearColor RectColor; float ScreenX, ScreenY, ScreenW, ScreenH; } p{ Fade(c), x, y, w, h };
        UObject::ProcessEvent(hud, EngineRefs::g_refs.hudDrawRect, &p);
    }

    inline void Frame(AHUD* hud, float x, float y, float w, float h, float t, const FLinearColor& c)
    {
        Rect(hud, x, y, w, t, c);
        Rect(hud, x, y + h - t, w, t, c);
        Rect(hud, x, y + t, t, h - 2.f * t, c);
        Rect(hud, x + w - t, y + t, t, h - 2.f * t, c);
    }

    inline void Texture(AHUD* hud, UTexture* tex, float x, float y, float w, float h)
    {
        if (!EngineRefs::g_refs.hudDrawTexture || !Valid(tex)) return;
        struct { UTexture* Texture; float ScreenX, ScreenY, ScreenW, ScreenH, TextureU, TextureV, TextureUWidth, TextureVHeight;
                 FLinearColor TintColor; EBlendMode BlendMode; unsigned char pad0[3]; float Scale; bool bScalePosition;
                 unsigned char pad1[3]; float Rotation; FVector2D RotPivot; } p{};
        p.Texture = tex; p.ScreenX = x; p.ScreenY = y; p.ScreenW = w; p.ScreenH = h;
        p.TextureUWidth = 1.f; p.TextureVHeight = 1.f;
        p.TintColor = FLinearColor(1.f, 1.f, 1.f, g_alpha);
        p.BlendMode = EBlendMode::BLEND_Translucent;
        p.Scale = 1.f; p.RotPivot = FVector2D(0.5f, 0.5f);
        UObject::ProcessEvent(hud, EngineRefs::g_refs.hudDrawTexture, &p);
    }

    inline void Material(AHUD* hud, UMaterialInterface* mat, float x, float y, float w, float h)
    {
        if (!EngineRefs::g_refs.hudDrawMaterialSimple || !Valid(mat) || g_alpha <= 0.003f) return;
        struct { UMaterialInterface* Material; float ScreenX, ScreenY, ScreenW, ScreenH, Scale; bool bScalePosition; } p{};
        p.Material = mat; p.ScreenX = x; p.ScreenY = y; p.ScreenW = w; p.ScreenH = h; p.Scale = 1.f;
        UObject::ProcessEvent(hud, EngineRefs::g_refs.hudDrawMaterialSimple, &p);
    }

    inline FVector2D TextSize(AHUD* hud, const wchar_t* s, float scale)
    {
        FVector2D out(0.f, 0.f);
        if (!EngineRefs::g_refs.hudGetTextSize || !s[0]) return out;
        struct { FString Text; float OutWidth, OutHeight; UFont* Font; float Scale; } p{};
        p.Text = FString(s); p.Font = Font(); p.Scale = scale;
        UObject::ProcessEvent(hud, EngineRefs::g_refs.hudGetTextSize, &p);
        out.X = p.OutWidth; out.Y = p.OutHeight;
        return out;
    }

    // Plain text, whole pixels (the font is a bitmap - keeps it sharp).
    inline void Text(AHUD* hud, const wchar_t* s, float x, float y, const FLinearColor& c, float scale)
    {
        if (!s[0] || c.A * g_alpha <= 0.003f) return;
        struct { FString Text; FLinearColor TextColor; float ScreenX, ScreenY; UFont* Font; float Scale; bool bScalePosition; } p{};
        p.Text = FString(s); p.TextColor = Fade(c); p.ScreenX = floorf(x + 0.5f); p.ScreenY = floorf(y + 0.5f);
        p.Font = Font(); p.Scale = scale;
        UObject::ProcessEvent(hud, EngineRefs::g_refs.hudDrawText, &p);
    }

    // Text with a 1 px drop shadow (on bars and swatches).
    inline void TextShadow(AHUD* hud, const wchar_t* s, float x, float y, const FLinearColor& c, float scale)
    {
        Text(hud, s, x + 1.f, y + 1.f, FLinearColor(0.f, 0.f, 0.f, 0.7f * c.A), scale);
        Text(hud, s, x, y, c, scale);
    }

    inline void Wide(const char* s, wchar_t* out, int cap)
    {
        const int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, out, cap);
        if (n <= 0) out[0] = 0;
    }

    inline void FormatVal(float v, wchar_t* b, int cap)
    {
        if (v >= 1.0e8f)        swprintf_s(b, cap, L"INF");
        else if (v >= 1.0e6f)   swprintf_s(b, cap, L"%.1fM", v / 1.0e6f);
        else if (v >= 10000.f)  swprintf_s(b, cap, L"%.1fK", v / 1000.f);
        else if (v == (int)v)   swprintf_s(b, cap, L"%.0f", v);
        else                    swprintf_s(b, cap, L"%.1f", v);
    }

    // A text line made of coloured pieces.
    struct Seg  { wchar_t t[112]; FLinearColor c; };
    struct Line { Seg s[12]; int n = 0; float scale = 1.f, w = 0.f, h = 0.f; };

    inline void Add(Line& l, const FLinearColor& c, const wchar_t* fmt, ...)
    {
        if (l.n >= 12) return;
        va_list ap; va_start(ap, fmt);
        vswprintf_s(l.s[l.n].t, fmt, ap);
        va_end(ap);
        l.s[l.n].c = c;
        l.n++;
    }

    // " · " then the piece, unless it is the first on the line.
    inline void AddDot(Line& l, const FLinearColor& dotCol, const FLinearColor& c, const wchar_t* s)
    {
        if (l.n) Add(l, dotCol, L"   \x00B7   ");
        Add(l, c, L"%ls", s);
    }

    inline void Measure(AHUD* hud, Line& l)
    {
        l.w = 0.f; l.h = 0.f;
        for (int i = 0; i < l.n; i++)
        {
            const FVector2D ts = TextSize(hud, l.s[i].t, l.scale);
            l.w += ts.X; if (ts.Y > l.h) l.h = ts.Y;
        }
        if (l.n && l.h <= 1.f) l.h = 18.f * l.scale;
    }

    inline void DrawSegs(AHUD* hud, const Line& l, float x, float y)
    {
        for (int i = 0; i < l.n; i++)
        {
            Text(hud, l.s[i].t, x, y, l.s[i].c, l.scale);
            x += TextSize(hud, l.s[i].t, l.scale).X;
        }
    }

    // ARK's dye colours by ColorSetIndices value (0 = region unused).
    inline FLinearColor DyeColor(uint8_t i)
    {
        static const uint32_t k[] = {
            0x000000, 0xE60E0E, 0x216DDF, 0x6CB158, 0xF1F926, 0x232323, 0xFFFFFF, 0x7C7C7C, 0x9C5226, 0xCB6E20,
            0xE5B41F, 0xFB05CD, 0x8C00B4, 0x0C1E89, 0x4C84B2, 0x83E3D3, 0xAEFAB4, 0xF59092, 0xFCD6CC, 0xFEC4B5,
            0xFBE2D4, 0xE9D2C2, 0xD9B69A, 0xA67953, 0x844F2A, 0x673819, 0x412411, 0x97DA56, 0x5B7637, 0x365621,
            0x223C0C, 0xDAE7E5, 0xC3D5D5, 0x8F8F8F, 0x4D4D4D, 0xC0BFBF, 0x52462E, 0x6E5739, 0x917447, 0xB59461,
            0xCEB582, 0x6E7491, 0x4E5470, 0x35395A, 0x1C2042, 0xB0AAB8, 0x8E889B, 0x6E647D, 0x4F4360, 0xC5AAB0,
            0x9A7B86, 0x745765, 0x4F3447, 0xDCDC3B, 0xC3C61B, 0xA0A60D, 0x7A8002, 0xFFE9A8, 0xFFDD79, 0xFFCA4A,
            0xFFAB1F, 0xFF6D1A, 0xC74015, 0x8C2A11, 0x511808, 0xC2F2FF, 0x8FD7F0, 0x59B2DE, 0x2E81B8, 0x174D7F,
            0x092A52, 0x05133A, 0xC3F0C8, 0x90D29B, 0x5DA56F, 0x357945, 0x174C24, 0xFFC4DD, 0xFF8FC1, 0xFC5BA5,
            0xC83F84, 0x8C2862 };
        const uint32_t c = i < sizeof(k) / sizeof(k[0]) ? k[i] : 0x9A9A9A;
        return FLinearColor(((c >> 16) & 0xFF) / 255.f, ((c >> 8) & 0xFF) / 255.f, (c & 0xFF) / 255.f, 1.f);
    }

    // Smoothed bar fill (about a 150 ms half-life), snapping on a new target.
    inline float    g_dispFrac[12] = {};
    inline UObject* g_dispActor = nullptr;
    inline uint64_t g_dispMs = 0;
    inline uint64_t g_fadeStart = 0;   // when the current target first appeared

    inline void Draw(AHUD* hud)
    {
        using S = Settings::Hud;
        const Target& d = g_cached;
        if (!Valid(hud) || !Valid(hud->Canvas) || !EngineRefs::g_refs.hudDrawRect || !EngineRefs::g_refs.hudDrawText) return;
        const float clipX = At<float>(hud->Canvas, 0x30), clipY = At<float>(hud->Canvas, 0x34);
        if (!(clipX > 0.f && clipY > 0.f)) return;

        // Bar fills ease towards the live value.
        float frac[12];
        for (int i = 0; i < 12; i++) { float r = d.max[i] > 0.f ? d.cur[i] / d.max[i] : 0.f; frac[i] = r < 0.f ? 0.f : (r > 1.f ? 1.f : r); }
        const uint64_t now = GetTickCount64();
        if (g_dispActor != g_cachedActor || now - g_dispMs > 1000)
        {
            memcpy(g_dispFrac, frac, sizeof(frac));
            if (now - g_dispMs > 1000) g_fadeStart = now;   // fade in only from nothing, not between targets
            g_dispActor = g_cachedActor;
        }
        else
        {
            float dt = (float)(now - g_dispMs); if (dt > 250.f) dt = 250.f;
            const float kk = 1.f - powf(0.5f, dt / 150.f);
            for (int i = 0; i < 12; i++) g_dispFrac[i] += (frac[i] - g_dispFrac[i]) * kk;
        }
        g_dispMs = now;

        // Fade in over 140 ms; fade out over the last 400 ms of the linger.
        {
            float a = (float)(now - g_fadeStart) / 140.f;
            if (g_lastTargetMs && now > g_lastTargetMs)
            {
                const float left = (float)kLingerMs - (float)(now - g_lastTargetMs);
                if (left < 400.f) a = (std::min)(a, left / 400.f);
            }
            g_alpha = a < 0.f ? 0.f : (a > 1.f ? 1.f : a);
        }

        float hr = clipY / 1440.f; if (hr < 0.25f) hr = 1.f;
        const float k = (S::SpyglassScale > 0.2f ? S::SpyglassScale : 1.f) * hr;
        auto R = [](float v) { return floorf(v + 0.5f); };
        const float t = (std::max)(1.f, R(2.f * k));   // border thickness

        // ---- palette ----
        const FLinearColor cFill  (0.04f, 0.13f, 0.16f, 0.88f);
        const FLinearColor cEdge  (0.40f, 0.85f, 0.93f, 1.f);
        const FLinearColor cDim   (0.40f, 0.85f, 0.93f, 0.22f);
        const FLinearColor cWell  (0.01f, 0.05f, 0.07f, 0.92f);
        const FLinearColor cWhite (1.f, 1.f, 1.f, 1.f);
        const FLinearColor cGrey  (0.66f, 0.76f, 0.80f, 1.f);
        const FLinearColor cFaint (0.45f, 0.55f, 0.58f, 1.f);
        const FLinearColor cGreen (0.42f, 0.95f, 0.52f, 1.f);
        const FLinearColor cRed   (1.f, 0.33f, 0.31f, 1.f);
        const FLinearColor cAmber (1.f, 0.78f, 0.24f, 1.f);
        const FLinearColor cPurple(0.80f, 0.60f, 1.f, 1.f);
        const FLinearColor cCyan  (0.45f, 0.86f, 1.f, 1.f);

        const bool isChar   = IsCharacterKind(d.kind);
        const bool isPerson = d.kind == K_Player || d.kind == K_Character;
        const FLinearColor& relCol = d.rel == R_Tribe ? cGreen : d.rel == R_Enemy ? cRed : cGrey;
        // Players: health is always green, torpor purple. Everything else
        // colours its health bar by who owns it.
        const FLinearColor  hpCol  = isPerson          ? FLinearColor(0.16f, 0.72f, 0.30f, 1.f)
                                   : d.rel == R_Tribe ? FLinearColor(0.15f, 0.66f, 0.27f, 1.f)
                                   : d.rel == R_Enemy ? FLinearColor(0.78f, 0.06f, 0.06f, 1.f)
                                                      : FLinearColor(0.85f, 0.53f, 0.07f, 1.f);
        const FLinearColor  accent = d.rel == R_Tribe ? FLinearColor(0.30f, 0.90f, 0.45f, 1.f)
                                   : d.rel == R_Enemy ? FLinearColor(1.f, 0.28f, 0.26f, 1.f)
                                   : d.rel == R_Wild  ? FLinearColor(1.f, 0.72f, 0.20f, 1.f)
                                                      : FLinearColor(0.55f, 0.65f, 0.70f, 1.f);
        const FLinearColor  torCol (0.48f, 0.22f, 0.78f, 1.f);

        wchar_t name[96], sub[96], tribe[64];
        Wide(d.name, name, 96); Wide(d.sub, sub, 96); Wide(d.tribe, tribe, 64);

        // ---- text ----
        Line title, l2, l3, l4, dist;
        title.scale = 1.35f * k; l2.scale = l3.scale = 1.0f * k; l4.scale = 0.92f * k; dist.scale = 0.95f * k;

        if (d.kind == K_Dino && d.tamed && sub[0]) Add(title, cWhite, L"%ls", sub);
        else Add(title, cWhite, L"%ls", name[0] ? name : (d.kind == K_Player ? L"Survivor" : L"Unknown"));
        if (isChar && d.level > 0) Add(title, cCyan, L"   Lvl %d", d.level);
        if (d.kind == K_Dino && d.tamed && d.extraLevel > 0 && d.baseLevel > 0)
            Add(title, cFaint, L"  (%d + %d)", d.baseLevel, d.extraLevel);   // tamed at + levelled since
        if (g_locked) Add(dist, cCyan, L"LOCKED   ");
        Add(dist, cFaint, L"%.0fm", d.distM);

        wchar_t buf[96];
        switch (d.kind)
        {
        case K_Dino:
            if (d.tamed) AddDot(l2, cFaint, relCol, tribe[0] ? tribe : (d.rel == R_Tribe ? L"Your tribe" : L"Enemy tame"));
            else         AddDot(l2, cFaint, cAmber, L"Wild");
            AddDot(l2, cFaint, cGrey, d.female ? L"Female" : L"Male");
            if (d.dead)              AddDot(l2, cFaint, cRed, L"Dead");
            else if (!d.conscious)   AddDot(l2, cFaint, cPurple, L"Knocked out");
            if (d.tamed)
            {
                if (sub[0]) AddDot(l3, cFaint, cGrey, name);
                if (d.imprint > 0.f) { swprintf_s(buf, L"Imprint %.0f%%", d.imprint * 100.f); AddDot(l3, cFaint, cCyan, buf); }
                if (d.mutM || d.mutF) { swprintf_s(buf, L"Mutations %d / %d", d.mutM, d.mutF); AddDot(l3, cFaint, cPurple, buf); }
            }
            if (!d.dead && d.tameProgress >= 0.f)
            {
                swprintf_s(buf, L"Taming %.0f%%", d.tameProgress * 100.f);
                AddDot(l3, cFaint, cGreen, buf);
                if (d.tameEff >= 0.f) { swprintf_s(buf, L"Effectiveness %.0f%%", d.tameEff * 100.f); AddDot(l3, cFaint, cGrey, buf); }
            }
            if (d.dead && d.decaySec >= 0.0)
            {
                const int sec = (int)d.decaySec;
                swprintf_s(buf, L"Decomposes in %d:%02d", sec / 60, sec % 60);
                AddDot(l4, cFaint, cAmber, buf);
            }
            if (d.babyAge >= 0.f) { swprintf_s(buf, L"Baby %.1f%%", d.babyAge * 100.f); AddDot(l4, cFaint, cCyan, buf); }
            if (d.neutered)       AddDot(l4, cFaint, cGrey, d.female ? L"Spayed" : L"Neutered");
            if (d.tamer[0])       { wchar_t w[64]; Wide(d.tamer, w, 64); swprintf_s(buf, L"Tamed by %ls", w); AddDot(l4, cFaint, cGrey, buf); }
            if (d.rider[0])       { wchar_t w[64]; Wide(d.rider, w, 64); swprintf_s(buf, L"Ridden by %ls", w); AddDot(l4, cFaint, cAmber, buf); }
            break;
        case K_Player:
        case K_Character:
            AddDot(l2, cFaint, relCol, tribe[0] ? tribe : L"No tribe");
            if (d.dead)              AddDot(l2, cFaint, cRed, L"Dead");
            else if (d.loggedOut)    AddDot(l2, cFaint, cPurple, L"Sleeping (logged out)");
            if (d.dead && d.decaySec >= 0.0)
            {
                const int sec = (int)d.decaySec;
                swprintf_s(buf, L"Decomposes in %d:%02d", sec / 60, sec % 60);
                AddDot(l4, cFaint, cAmber, buf);
            }
            else if (!d.conscious)   AddDot(l2, cFaint, cPurple, L"Knocked out");
            if (d.held[0])           { wchar_t w[64]; Wide(d.held, w, 64); swprintf_s(buf, L"Holding %ls", w); AddDot(l3, cFaint, cWhite, buf); }
            if (sub[0])              AddDot(l3, cFaint, cGrey, sub);
            break;
        default:
            AddDot(l2, cFaint, relCol, tribe[0] ? tribe : L"Unowned");
            if (d.rel != R_Tribe && d.offlineSec >= 0.0)
            {
                const long long s = (long long)d.offlineSec;
                const int days = (int)(s / 86400), hh = (int)(s % 86400 / 3600), mm = (int)(s % 3600 / 60), ss = (int)(s % 60);
                if (days > 0) swprintf_s(buf, L"Offline %dd %d:%02d:%02d", days, hh, mm, ss);
                else          swprintf_s(buf, L"Offline %d:%02d:%02d", hh, mm, ss);
                AddDot(l3, cFaint, cAmber, buf);
            }
            else if (sub[0]) { swprintf_s(buf, L"Placed by %ls", sub); AddDot(l3, cFaint, cGrey, buf); }
            if (d.decaySec >= 0.0)
            {
                const int sec = (int)d.decaySec;
                if (sec >= 3600) swprintf_s(buf, L"Decomposes in %d:%02d:%02d", sec / 3600, sec % 3600 / 60, sec % 60);
                else             swprintf_s(buf, L"Decomposes in %d:%02d", sec / 60, sec % 60);
                AddDot(l4, cFaint, cAmber, buf);
            }
            if (!d.lootCache)
            {
                if (d.pinLocked)   AddDot(l4, cFaint, cAmber, L"PIN locked");
                else if (d.locked) AddDot(l4, cFaint, cAmber, L"Locked");
            }
            if (d.items >= 0)      { swprintf_s(buf, L"Items %d", d.items); AddDot(l4, cFaint, cGrey, buf); }
            break;
        }
        Measure(hud, title); Measure(hud, l2); Measure(hud, l3); Measure(hud, l4); Measure(hud, dist);

        // ---- layout ----
        const bool  hasBox = Valid(d.icon);
        const bool  colors = d.kind == K_Dino && d.hasColors && !d.dead;
        const bool  hpBar  = d.max[HEALTH] > 0.f;
        const bool  torBar = isChar && !d.dead && d.max[TORPOR] > 0.f;
        const bool  grid   = d.kind == K_Dino && (d.hasStats || d.hasPoints) && !d.dead;   // players: bars only
        const bool  note   = d.kind == K_Dino && !d.hasStats && !d.hasPoints && !d.dead;   // nothing sent

        // "(12)" wild points, "(12-5)" wild-tamed - only real, non-zero data.
        auto points = [&](int st, wchar_t* b, int cap) {
            b[0] = 0;
            if (d.hasPoints)
            {
                if (d.tamedPts[st]) swprintf_s(b, cap, L"(%d-%d)", d.wildPts[st], d.tamedPts[st]);
                else                swprintf_s(b, cap, L"(%d)", d.wildPts[st]);
            }
            else if (d.hasEst && d.estKnown[st])
            {
                // calculated (official multipliers); same "(wild-tamed)" format
                if (d.estT[st]) swprintf_s(b, cap, L"(%d-%d)", d.estW[st], d.estT[st]);
                else            swprintf_s(b, cap, L"(%d)", d.estW[st]);
            }
        };
        const float noteS = 0.82f * k;
        const wchar_t* noteText = d.tamed ? L"Stats not sent for enemy tames - health and torpor only"
                                          : L"Wild stats are not sent by the server - health and torpor only";
        const FVector2D noteSz = note ? TextSize(hud, noteText, noteS) : FVector2D(0.f, 0.f);
        const float noteH = note ? R(noteSz.Y + 2.f * k) : 0.f;

        // ARK's panel art: a thin glowing edge (SpyglassBackground) - content
        // sits clear of it.
        const bool  arkBg = S::SpyglassArkBg && SpyglassBackground::Ready();
        const float pad = arkBg ? R((std::max)(14.f * k, SpyglassBackground::EdgePx(hud, hr) + 10.f * k)) : R(14.f * k),
                    lineGap = R(4.f * k), secGap = R(10.f * k);
        const float box = hasBox ? R(78.f * k) : 0.f, boxGap = hasBox ? R(16.f * k) : 0.f;
        const float swH = R(24.f * k), barH = R(28.f * k), torH = R(20.f * k), rowH = R(23.f * k);

        float textH = title.h;
        if (l2.n) textH += lineGap + l2.h;
        if (l3.n) textH += lineGap + l3.h;
        if (l4.n) textH += lineGap + l4.h;
        const float headH = (std::max)(box, textH);
        const float textX = pad + box + boxGap;
        const float textW = (std::max)((std::max)(title.w + R(24.f * k) + dist.w, l2.w), (std::max)(l3.w, l4.w));

        const float W = R((std::max)((std::max)(520.f * k, textX + textW + pad), noteSz.X + pad * 2.f + R(8.f * k)));
        const bool  body = colors || hpBar || torBar || grid || note;

        float H = pad + headH;
        if (body)   H += secGap + 1.f + secGap;              // separator
        float bodyH = 0.f;
        auto addBody = [&](float h) { if (bodyH > 0.f) bodyH += R(6.f * k); bodyH += h; };
        if (colors) addBody(swH);
        if (hpBar)  addBody(barH);
        if (torBar) addBody(torH);
        if (grid)   addBody(R(4.f * k) + rowH * 3.f);
        if (note)   addBody(noteH);
        H = R(H + bodyH + pad);

        // Default: centred, near the top (84 px down at 1440p - what used to be
        // Y -700 from under the crosshair). X / Y move it from there.
        const float x0 = R((std::max)(0.f, (std::min)(clipX - W, (clipX - W) * 0.5f + S::SpyglassX * hr)));
        const float y0 = R((std::max)(0.f, (std::min)(clipY - H, 84.f * hr + S::SpyglassY * hr)));
        const float ix = x0 + pad, iw = W - pad * 2.f;

        // ---- panel: ARK's own panel art (ToolTipBg + PanelBorderHighlight,
        // 9-sliced - see SpyglassBackground.h), or the flat look ----
        if (arkBg)
        {
            SpyglassBackground::Draw(hud, x0, y0, W, H, g_alpha, hr);
            if (g_locked) Frame(hud, x0, y0, W, H, t, cCyan);   // cyan edge while locked
        }
        else
        {
            Rect(hud, x0, y0, W, H, cFill);
            Rect(hud, x0 + t, y0 + t, W - 2.f * t, R(H * 0.35f), FLinearColor(0.40f, 0.85f, 0.93f, 0.04f));   // soft top sheen
            Frame(hud, x0, y0, W, H, t, g_locked ? cCyan : cEdge);   // cyan frame while locked
            const float in = R(4.f * k) + t;
            Frame(hud, x0 + in, y0 + in, W - in * 2.f, H - in * 2.f, 1.f, cDim);
        }
        (void)accent;
        const auto& ui = EngineRefs::g_refs;
        const float edgeS = SpyglassBackground::g_scale;   // ARK UI scale (set by the background draw)

        // ---- header ----
        if (hasBox)
        {
            const float bx = ix, by = R(y0 + pad + (headH - box) * 0.5f);
            if (arkBg && Valid(ui.uiItemSlot))
                Texture(hud, reinterpret_cast<UTexture*>(ui.uiItemSlot), bx, by, box, box);   // ARK's inventory slot
            else
            {
                Rect(hud, bx, by, box, box, cWell);
                Frame(hud, bx, by, box, box, t, cEdge);
            }
            const float ins = R(7.f * k);
            Texture(hud, d.icon, bx + ins, by + ins, box - ins * 2.f, box - ins * 2.f);
        }
        {
            float y = R(y0 + pad + (headH - textH) * 0.5f);
            const float tx = x0 + textX;
            DrawSegs(hud, title, tx, y);
            DrawSegs(hud, dist, x0 + W - pad - dist.w, y + (title.h - dist.h) * 0.5f);
            y += title.h;
            if (l2.n) { y += lineGap; DrawSegs(hud, l2, tx, y); y += l2.h; }
            if (l3.n) { y += lineGap; DrawSegs(hud, l3, tx, y); y += l3.h; }
            if (l4.n) { y += lineGap; DrawSegs(hud, l4, tx, y); }
        }
        if (!body) return;

        float y = y0 + pad + headH + secGap;
        if (arkBg && Valid(ui.uiTabSeparator))
        {
            const float sh = R(6.f * k);
            Texture(hud, reinterpret_cast<UTexture*>(ui.uiTabSeparator), ix, y - sh * 0.5f, iw, sh);   // ARK's divider
        }
        else
            Rect(hud, ix, y, iw, 1.f, cDim);
        y += 1.f + secGap;
        bool first = true;
        auto next = [&](float h) { if (!first) y += R(6.f * k); first = false; const float at = y; y += h; return at; };

        // ---- colour regions ----
        if (colors)
        {
            const float sy = next(swH), g = R(6.f * k), cw = (iw - g * 5.f) / 6.f, ns = 0.78f * k;
            for (int i = 0; i < 6; i++)
            {
                const float sx = R(ix + i * (cw + g)), sw = R(cw);
                const bool unused = d.colors[i] == 0;
                Rect(hud, sx, sy, sw, swH, unused ? cWell : DyeColor(d.colors[i]));
                Frame(hud, sx, sy, sw, swH, 1.f, unused ? cDim : FLinearColor(0.f, 0.f, 0.f, 0.45f));
                wchar_t n[8];
                if (unused) swprintf_s(n, L"-"); else swprintf_s(n, L"%u", (unsigned)d.colors[i]);
                const FVector2D ts = TextSize(hud, n, ns);
                TextShadow(hud, n, sx + (sw - ts.X) * 0.5f, sy + (swH - ts.Y) * 0.5f, unused ? cFaint : cWhite, ns);
            }
        }

        // ---- bars ----
        auto bar = [&](float bh, int s, const FLinearColor& fill, const wchar_t* label, float ts) {
            const float by = next(bh);
            if (arkBg)
            {
                // ARK style: dark well, flat fill, ARK's thin glowing edge.
                Rect(hud, ix, by, iw, bh, FLinearColor(0.f, 0.02f, 0.03f, 0.55f));
                const float ins = R(2.f * k), inner = iw - ins * 2.f, fh = bh - ins * 2.f;
                const float fw = R(inner * g_dispFrac[s]);
                Rect(hud, ix + ins, by + ins, fw, fh, FLinearColor(fill.R, fill.G, fill.B, 0.85f));
                if (Valid(ui.uiBorderGlow))
                    SpyglassBackground::DrawEdge(hud, reinterpret_cast<UTexture*>(ui.uiBorderGlow), ix, by, iw, bh, (std::max)(2.f, 3.f * edgeS), g_alpha);
                wchar_t a[16], b[16], txt[80], pct[12], pt[24];
                FormatVal(d.cur[s] > 0.f ? d.cur[s] : 0.f, a, 16); FormatVal(d.max[s], b, 16);
                if (d.kind == K_Dino) points(s, pt, 24); else pt[0] = 0;
                if (pt[0]) swprintf_s(txt, L"%ls / %ls  %ls  %ls", a, b, label, pt);
                else       swprintf_s(txt, L"%ls / %ls  %ls", a, b, label);
                const float rr = d.max[s] > 0.f ? (std::min)(1.f, (std::max)(0.f, d.cur[s] / d.max[s])) : 0.f;
                swprintf_s(pct, L"%.0f%%", rr * 100.f);
                const FVector2D sz = TextSize(hud, txt, ts), ps = TextSize(hud, pct, ts * 0.92f);
                TextShadow(hud, txt, ix + (iw - sz.X) * 0.5f, by + (bh - sz.Y) * 0.5f, cWhite, ts);
                TextShadow(hud, pct, ix + iw - ins - R(8.f * k) - ps.X, by + (bh - ps.Y) * 0.5f, FLinearColor(1.f, 1.f, 1.f, 0.85f), ts * 0.92f);
                return;
            }
            Rect(hud, ix, by, iw, bh, cWell);
            const float ins = t + 1.f, inner = iw - ins * 2.f, fh = bh - ins * 2.f;
            const float fw = R(inner * g_dispFrac[s]);
            // Empty part: a faint wash of the bar colour so an empty bar still reads.
            Rect(hud, ix + ins + fw, by + ins, inner - fw, fh, FLinearColor(fill.R, fill.G, fill.B, 0.12f));
            // Fill with depth: gloss on top, shade underneath, bright cap at the end.
            Rect(hud, ix + ins, by + ins, fw, fh, fill);
            Rect(hud, ix + ins, by + ins, fw, R(fh * 0.45f), FLinearColor(1.f, 1.f, 1.f, 0.13f));
            Rect(hud, ix + ins, by + ins + R(fh * 0.62f), fw, fh - R(fh * 0.62f), FLinearColor(0.f, 0.f, 0.f, 0.18f));
            if (fw >= 3.f && fw < inner) Rect(hud, ix + ins + fw - 2.f, by + ins, 2.f, fh, FLinearColor(1.f, 1.f, 1.f, 0.45f));
            // Quarter ticks.
            for (int q = 1; q < 4; q++)
                Rect(hud, R(ix + ins + inner * q * 0.25f), by + ins, 1.f, fh, FLinearColor(0.f, 0.f, 0.f, 0.28f));
            Frame(hud, ix, by, iw, bh, t, cEdge);

            wchar_t a[16], b[16], txt[80], pct[12], pt[24];
            FormatVal(d.cur[s] > 0.f ? d.cur[s] : 0.f, a, 16); FormatVal(d.max[s], b, 16);
            if (d.kind == K_Dino) points(s, pt, 24); else pt[0] = 0;
            if (pt[0]) swprintf_s(txt, L"%ls / %ls  %ls  %ls", a, b, label, pt);
            else       swprintf_s(txt, L"%ls / %ls  %ls", a, b, label);
            const float rr = d.max[s] > 0.f ? (std::min)(1.f, (std::max)(0.f, d.cur[s] / d.max[s])) : 0.f;
            swprintf_s(pct, L"%.0f%%", rr * 100.f);
            const FVector2D sz = TextSize(hud, txt, ts), ps = TextSize(hud, pct, ts * 0.92f);
            TextShadow(hud, txt, ix + (iw - sz.X) * 0.5f, by + (bh - sz.Y) * 0.5f, cWhite, ts);
            TextShadow(hud, pct, ix + iw - ins - R(6.f * k) - ps.X, by + (bh - ps.Y) * 0.5f, FLinearColor(1.f, 1.f, 1.f, 0.85f), ts * 0.92f);
        };
        if (hpBar)  bar(barH, HEALTH, hpCol, L"Health", 0.88f * k);
        if (torBar) bar(torH, TORPOR, torCol, L"Torpor", 0.76f * k);

        // ---- stats (only when the server sent them) ----
        if (grid)
        {
            const float gy = next(R(4.f * k) + rowH * 3.f) + R(4.f * k);
            const float gs = 0.88f * k, colGap = R(28.f * k), colW = (iw - colGap) * 0.5f;
            auto cell = [&](float cx, float cy, int s, const wchar_t* label, bool pct) {
                wchar_t v[24], pt[24];
                if (!d.hasStats)  swprintf_s(v, L"-");                  // points only, no value sent
                else if (pct)     swprintf_s(v, L"%.1f%%", d.cur[s]);
                else              FormatVal(d.cur[s], v, 24);
                points(s, pt, 24);
                const FVector2D ls = TextSize(hud, label, gs), vs = TextSize(hud, v, gs);
                const float ty = cy + (rowH - ls.Y) * 0.5f;
                Text(hud, label, cx, ty, cGrey, gs);
                // value right-aligned, points in a fixed column just left of it
                float vx = cx + colW - vs.X;
                if (pt[0])
                {
                    const float ps = gs * 0.9f;
                    const FVector2D pz = TextSize(hud, pt, ps);
                    Text(hud, pt, cx + colW - pz.X, ty + (ls.Y - pz.Y) * 0.5f, cCyan, ps);
                    vx = cx + colW - pz.X - R(10.f * k) - vs.X;
                }
                Text(hud, v, vx, ty, cWhite, gs);
            };
            for (int r = 1; r < 3; r++) Rect(hud, ix, R(gy + rowH * r), iw, 1.f, FLinearColor(0.40f, 0.85f, 0.93f, 0.08f));
            const float rx = ix + colW + colGap;
            cell(ix, gy,            STAMINA, L"Stamina", false);
            cell(ix, gy + rowH,     OXYGEN,  L"Oxygen",  false);
            cell(ix, gy + rowH * 2, FOOD,    L"Food",    false);
            cell(rx, gy,            WEIGHT,  L"Weight",  false);
            cell(rx, gy + rowH,     MELEE,   L"Melee",   true);
            cell(rx, gy + rowH * 2, SPEED,   L"Speed",   true);
            Rect(hud, R(ix + colW + colGap * 0.5f), gy + 3.f, 1.f, rowH * 3.f - 6.f, cDim);
        }
        if (note)
        {
            const float ny = next(noteH);
            const FVector2D ns = TextSize(hud, noteText, noteS);
            Text(hud, noteText, R(ix + (iw - ns.X) * 0.5f), ny, cFaint, noteS);
        }
    }

    // ---- game thread, every frame (DrawHUD hook, after ARK's own HUD) ----------------------
    inline void Tick(AHUD* hud, bool menuOpen)
    {
        Update(hud, menuOpen);
        if (g_show && g_cached.valid) Draw(hud);
    }
}

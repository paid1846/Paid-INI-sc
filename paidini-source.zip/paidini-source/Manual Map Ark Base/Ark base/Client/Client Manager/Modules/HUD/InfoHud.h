#pragma once
// ============================================================================
// InfoHud - top-left text overlay, laid out like ArkHoles' HudDisplay.
//
// Plain text lines at the top-left, no panel: Tahoma Bold with a 1px black
// outline (readable over snow and sky without a backing box), optional
// rolling rainbow. Lines draw in a fixed order and each has its own toggle,
// so a line never moves when a neighbour is switched off - the gap closes.
//
// SPLIT ACROSS TWO THREADS:
//   Tick()  - game thread (DrawHUD). Reads the replicated AShooterGameState,
//             the player state, the inventory and the level actor list into a
//             snapshot. Only runs the reads for lines that are switched on.
//   Draw()  - render thread (Present, ImGui). Formats and paints the snapshot.
//
// AShooterGameState offsets, verified live on the Store build (v962.2):
//   NumPlayerConnected 0x568, ServerFramerate 0x578, ServerSessionName 0x948,
//   LimitTurretsRange 0xA00.
// Ping, RootComponent and Bounds come from reflection.
// ============================================================================
#include <Global.h>
#include <cmath>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include "imgui.h"
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Misc/QuickPickup.h" // PropOffset (reflection)

namespace InfoHud
{
    inline constexpr uintptr_t OFF_GS_NUM_CONNECTED = 0x0568;
    inline constexpr uintptr_t OFF_GS_SERVER_FPS    = 0x0578;
    inline constexpr uintptr_t OFF_GS_SESSION_NAME  = 0x0948;
    inline constexpr uintptr_t OFF_GS_TURRET_RANGE  = 0x0A00;

    inline constexpr uintptr_t OFF_PC_PAWN          = 0x04E8; // AcknowledgedPawn
    inline constexpr uintptr_t OFF_PAWN_INVENTORY   = 0x0D20;
    inline constexpr uintptr_t OFF_INV_ITEMS        = 0x0118;

    inline constexpr ULONGLONG kTurretSweepMs    = 1000;
    inline constexpr float     kTurretFallbackCm = 10000.f;

    struct Snapshot
    {
        bool      valid            = false;
        int       ping             = 0;
        float     serverFps        = 0.f;
        int       numConnected     = 0;
        int       turretsNear      = 0; // enemy
        int       turretsFriendly  = 0;
        char      serverName[128]  = {};
        int       invUsed          = 0;
        int       invMax           = 0;
        ULONGLONG stamp            = 0;
    };

    inline Snapshot g_snap;              // written by Tick, copied by Draw
    inline SRWLOCK  g_lock = SRWLOCK_INIT;

    inline bool Ptr(const void* p)
    {
        const uintptr_t v = reinterpret_cast<uintptr_t>(p);
        return v > 0x10000 && v < 0x7FFFFFFFFFFF;
    }
    template <typename T> inline T At(const void* base, uintptr_t off)
    {
        return *reinterpret_cast<const T*>(reinterpret_cast<uintptr_t>(base) + off);
    }

    inline bool WantsGameData()
    {
        using S = Settings::Hud;
        return S::Ping || S::ServerFPS || S::ServerName || S::ConnectedPlayers ||
               S::TurretsInRange || S::InventorySlots;
    }

    inline void CopyFString(uintptr_t addr, char* out, int cap)
    {
        out[0] = '\0';
        const wchar_t* data = *reinterpret_cast<wchar_t* const*>(addr);
        const int count = *reinterpret_cast<const int32_t*>(addr + 8);
        if (!Ptr(data) || count <= 0 || count > 4096) return;
        int n = 0;
        for (; n < cap - 1 && n < count; ++n)
        {
            const wchar_t w = data[n];
            if (!w) break;
            out[n] = (w < 0x80) ? static_cast<char>(w) : '?';
        }
        out[n] = '\0';
    }

    // ---- turrets in range ---------------------------------------------------
    // AActor::RootComponent found once by reflection. Bounds is not a reflected
    // property on this build, so the position is the root's ComponentToWorld
    // translation (USceneComponent +0xF0, verified live against RelativeLocation).
    inline uint32_t g_offRoot = 0;
    inline constexpr uintptr_t OFF_C2W_POS = 0x00F0;

    inline bool LocationOf(const void* actor, FVector& out)
    {
        if (!g_offRoot) return false;
        const void* rc = At<void*>(actor, g_offRoot);
        if (!Ptr(rc)) return false;
        out = At<FVector>(rc, OFF_C2W_POS);
        return true;
    }

    inline bool IsTurret(const UObject* o, const UClass* turret)
    {
        int depth = 0;
        for (const UStruct* s = o->Class; Ptr(s) && depth < 24; s = s->SuperField, depth++)
            if (s == turret) return true;
        return false;
    }

    // AActor::TargetingTeam (0x230 on the Store build) - the tribe / team id a
    // turret and the local player share when the turret is friendly.
    inline uint32_t g_offTeam = 0;

    // One actor, SEH-isolated so a dying actor skips instead of ending the sweep.
    // 0 = not a turret in range, 1 = enemy turret, 2 = friendly turret.
    inline int TurretNear(const UObject* a, const UClass* turret, const FVector& me, float r2, int32_t myTeam)
    {
        __try
        {
            if (!Ptr(a) || !IsTurret(a, turret)) return 0;
            FVector p;
            if (!LocationOf(a, p)) return 0;
            const float dx = p.X - me.X, dy = p.Y - me.Y, dz = p.Z - me.Z;
            if (dx * dx + dy * dy + dz * dz > r2) return 0;
            return (g_offTeam && myTeam != 0 && At<int32_t>(a, g_offTeam) == myTeam) ? 2 : 1;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    struct TurretCount { int enemy = 0; int friendly = 0; };

    inline TurretCount CountTurretsNear(UWorld* world, const void* pawn, float radiusCm)
    {
        static ULONGLONG   s_last = 0;
        static TurretCount s_cached;
        const ULONGLONG now = GetTickCount64();
        if (s_last && now - s_last < kTurretSweepMs) return s_cached;
        s_last = now;

        const UClass* turret = EngineRefs::g_refs.clsTurret;
        if (!turret || !world || !Ptr(world->PersistentLevel) || !Ptr(pawn)) return s_cached;

        const UObject* pawnObj = reinterpret_cast<const UObject*>(pawn);
        if (!g_offRoot) g_offRoot = QuickPickup::PropOffset(pawnObj->Class, "RootComponent");
        if (!g_offTeam) g_offTeam = QuickPickup::PropOffset(pawnObj->Class, "TargetingTeam");

        FVector me;
        if (!LocationOf(pawn, me)) return s_cached;
        const int32_t myTeam = g_offTeam ? At<int32_t>(pawn, g_offTeam) : 0;

        TArray<AActor*>& actors = world->PersistentLevel->Actors;
        const int count = actors.Count();
        if (count <= 0 || count > 400000) return s_cached;

        const float r2 = radiusCm * radiusCm;
        TurretCount found;
        for (int i = 0; i < count; ++i)
        {
            const int k = TurretNear(reinterpret_cast<const UObject*>(actors[i]), turret, me, r2, myTeam);
            if (k == 1) ++found.enemy;
            else if (k == 2) ++found.friendly;
        }

        s_cached = found;
        return s_cached;
    }

    // ---- game thread --------------------------------------------------------
    inline void Tick()
    {
        if (!Settings::Hud::InfoHud || !WantsGameData() || !EngineRefs::Ready())
        {
            AcquireSRWLockExclusive(&g_lock);
            g_snap.valid = false;
            ReleaseSRWLockExclusive(&g_lock);
            return;
        }

        Snapshot out;
        UWorld* world = UWorld::Get();
        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        const void* pawn = Ptr(pc) ? At<void*>(pc, OFF_PC_PAWN) : nullptr;
        if (!Ptr(pawn)) pawn = nullptr;

        // ping: APlayerState::Ping, a byte of quarter-milliseconds
        if (Settings::Hud::Ping && Ptr(pc))
        {
            static void*    s_pcCls = nullptr;
            static uint32_t s_offPS = 0, s_offPing = 0;
            const UObject* pco = reinterpret_cast<const UObject*>(pc);
            if (pco->Class != s_pcCls) { s_pcCls = pco->Class; s_offPS = QuickPickup::PropOffset(pco->Class, "PlayerState"); }
            const UObject* ps = s_offPS ? At<UObject*>(pc, s_offPS) : nullptr;
            if (Ptr(ps))
            {
                if (!s_offPing) s_offPing = QuickPickup::PropOffset(ps->Class, "Ping");
                if (s_offPing) out.ping = static_cast<int>(At<uint8_t>(ps, s_offPing)) * 4;
            }
        }

        float turretRange = 0.f;
        const void* gs = world ? reinterpret_cast<void*>(world->GameState) : nullptr;
        if (Ptr(gs))
        {
            auto sane = [](int v) { return (v >= 0 && v < 10000000) ? v : 0; };
            out.numConnected     = sane(At<int32_t>(gs, OFF_GS_NUM_CONNECTED));
            out.serverFps        = At<float>(gs, OFF_GS_SERVER_FPS);
            turretRange          = At<float>(gs, OFF_GS_TURRET_RANGE);
            if (!(out.serverFps >= 0.f && out.serverFps < 10000.f)) out.serverFps = 0.f;
            if (Settings::Hud::ServerName)
                CopyFString(reinterpret_cast<uintptr_t>(gs) + OFF_GS_SESSION_NAME, out.serverName, sizeof(out.serverName));
        }

        // inventory: items minus engrams (bIsEngram, item+0x53 bit 4) / max slots
        if (Settings::Hud::InventorySlots && pawn)
        {
            UObject* inv = At<UObject*>(pawn, OFF_PAWN_INVENTORY);
            if (Ptr(inv))
            {
                const TArray<UObject*>& items = *reinterpret_cast<const TArray<UObject*>*>(
                    reinterpret_cast<uintptr_t>(inv) + OFF_INV_ITEMS);
                const int count = items.Count();
                int used = 0;
                if (count > 0 && count < 20000)
                    for (int i = 0; i < count; ++i)
                    {
                        const UObject* it = items.Data()[i];
                        if (!Ptr(it) || (At<uint8_t>(it, 0x53) & 0x10)) continue;
                        ++used;
                    }
                out.invUsed = used;

                // The replicated MaxInventoryItems field (0x1B8) reads -1 on the
                // client, so ask the game (includes bonus slots) and fall back
                // to ARK's player default of 300.
                int maxItems = 0;
                if (UFunction* fn = EngineRefs::g_refs.invGetMaxItems)
                {
                    struct { bool bIgnoreHiddenDefaultInventory; uint8_t pad[3]; int32_t ReturnValue; } p{ false, {}, 0 };
                    UObject::ProcessEvent(inv, fn, &p);
                    if (p.ReturnValue > 0 && p.ReturnValue < 100000) maxItems = p.ReturnValue;
                    static bool s_logged = false;
                    if (!s_logged) { s_logged = true; Logger::Log("[InfoHud] GetMaxInventoryItems -> %d", p.ReturnValue); }
                }
                out.invMax = maxItems > 0 ? maxItems : 300;
            }
        }

        if (Settings::Hud::TurretsInRange && pawn)
        {
            const TurretCount tc = CountTurretsNear(world, pawn, turretRange > 1.f ? turretRange : kTurretFallbackCm);
            out.turretsNear     = tc.enemy;
            out.turretsFriendly = tc.friendly;
        }

        out.valid = Ptr(gs);
        out.stamp = GetTickCount64();

        AcquireSRWLockExclusive(&g_lock);
        g_snap = out;
        ReleaseSRWLockExclusive(&g_lock);
    }

    // ---- render thread ------------------------------------------------------
    inline float SnapPx(float px)
    {
        px = floorf(px + 0.5f);
        return px < 8.f ? 8.f : (px > 48.f ? 48.f : px);
    }

    // Text size for the current scale (16 px at 1.0, as in ArkHoles).
    inline float FontPx()
    {
        float s = Settings::Hud::InfoHudScale;
        if (!(s > 0.1f && s < 10.f)) s = 1.f;
        return SnapPx(16.f * s);
    }

    inline void DrawLabel(ImDrawList* dl, ImFont* font, float size, ImVec2 pos, ImU32 col, const char* text)
    {
        pos.x = floorf(pos.x);
        pos.y = floorf(pos.y);
        const ImU32 ring = IM_COL32(0, 0, 0, (col >> IM_COL32_A_SHIFT) & 0xFF);
        static const ImVec2 kRing[4] = { { 0.f, -1.f }, { -1.f, 0.f }, { 1.f, 0.f }, { 0.f, 1.f } };
        for (const ImVec2& o : kRing)
            dl->AddText(font, size, ImVec2(pos.x + o.x, pos.y + o.y), ring, text);
        dl->AddText(font, size, pos, col, text);
    }

    inline void Draw(ImFont* font)
    {
        using S = Settings::Hud;
        if (!S::InfoHud) return;
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        if (!font) font = ImGui::GetFont();
        if (!dl || !font) return;

        Snapshot sn;
        AcquireSRWLockShared(&g_lock);
        sn = g_snap;
        ReleaseSRWLockShared(&g_lock);
        const bool live = sn.valid && GetTickCount64() - sn.stamp < 2000;

        char lines[20][160];
        int  n = 0;
        auto add = [&](const char* fmt, ...) {
            if (n >= IM_ARRAYSIZE(lines)) return;
            va_list ap; va_start(ap, fmt);
            vsnprintf(lines[n], sizeof(lines[n]), fmt, ap);
            va_end(ap);
            ++n;
        };

        // Fixed order: watermark, local, then server facts.
        if (S::Watermark) add("Paid INI");
        if (S::ShowFPS)   add("FPS: %d", (int)(ImGui::GetIO().Framerate + 0.5f));
        if (live)
        {
            if (S::Ping)             add("Ping: %d", sn.ping);
            if (S::ServerFPS)        add("Server FPS: %.0f", sn.serverFps);
            if (S::ConnectedPlayers) add("Connected Players: %d", sn.numConnected);
            if (S::TurretsInRange)
            {
                if (S::FriendlyTurrets) add("Nearby Turrets: %d | Friendly: %d", sn.turretsNear, sn.turretsFriendly);
                else                    add("Nearby Turrets: %d", sn.turretsNear);
            }
            if (S::InventorySlots)   add("Inventory Slots: %d / %d", sn.invUsed, sn.invMax);
            if (S::ServerName)       add("Server Name: %s", sn.serverName[0] ? sn.serverName : "--");
        }
        if (n == 0) return;

        float scale = S::InfoHudScale;
        if (!(scale > 0.1f && scale < 10.f)) scale = 1.f;
        const float size  = FontPx();
        const float lineH = size + 4.f * scale;
        const float baseX = 12.f, baseY = 12.f;

        for (int i = 0; i < n; ++i)
        {
            ImU32 col = IM_COL32(236, 238, 245, 255);
            if (S::Rainbow)
            {
                // One hue cycle per 3 s at 1.0x; per-line offset rolls it down the list.
                const float hue = fmodf((float)(GetTickCount64() % 3600000) / 3000.f * S::RainbowSpeed
                                        + (float)i * 0.06f, 1.0f);
                float r, g, b;
                ImGui::ColorConvertHSVtoRGB(hue < 0.f ? hue + 1.f : hue, 0.65f, 1.0f, r, g, b);
                col = IM_COL32((int)(r * 255), (int)(g * 255), (int)(b * 255), 255);
            }
            DrawLabel(dl, font, size, ImVec2(baseX, baseY + lineH * i), col, lines[i]);
        }
    }
}

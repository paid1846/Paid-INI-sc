#pragma once
// ============================================================================
// SpyglassBackground - ARK's own animated panel background behind the
// Awesome Spyglass, drawn the way ARK's inventory panel looks.
//
//   background  PanelBackgroundAnimation (Material) through HUD.DrawMaterial
//               (the full one, with UVs - read live: Material 0x0, X/Y/W/H
//               0x8-0x14, U/V/UW/VH 0x18-0x24, Scale 0x28, bScalePosition 0x2C,
//               Rotation 0x30, RotPivot 0x34), tiled at 630 x 1000 UI units so
//               the pattern has ARK's own density at any panel size.
//   UI scale    VictoryCore.GetUIScale x WidgetLayoutLibrary.GetViewportScale
//               (re-read once a second), so it matches the game's UI scale.
//   fade        a dynamic instance of the material whose MaxOpacity scalar
//               (default 0.82) is scaled by the spyglass fade; the instance is
//               root-set so the GC leaves it alone, and released on eject.
//   border      PanelBorderHighlight (Texture2D) 9-sliced, 3 UI units deep,
//               1/3 of the texture as the corner.
//
// Same approach as the reference ArkBackground.h, on this build's EngineRefs.
//
// THREADING: game thread (DrawHUD hook).
// ============================================================================
#include <Global.h>
#include "Client Manager/Modules/Engine/EngineRefs.h"

namespace SpyglassBackground
{
    inline constexpr float kTileW      = 630.f;
    inline constexpr float kTileH      = 1000.f;
    inline constexpr float kEdge       = 3.f;
    inline constexpr float kPad        = 2.f;
    inline constexpr float kEdgeUv     = 1.f / 3.f;
    inline constexpr float kMaxOpacity = 0.82f;
    inline constexpr int32_t RF_RootSet = 0x80;

    inline bool Valid(const void* p) { const uintptr_t v = reinterpret_cast<uintptr_t>(p); return v > 0x10000 && v < 0x7FFFFFFFFFFF; }

    inline UObject* MaterialBase() { return EngineRefs::g_refs.uiPanelBgAnim; }
    inline UObject* EdgeTexture()  { return EngineRefs::g_refs.uiBorderGlow; }

    // True when the panel art can be drawn; asks for a background retry when not.
    inline bool Ready()
    {
        if (Valid(MaterialBase()) && EngineRefs::g_refs.hudDrawMaterial) return true;
        EngineRefs::RequestUiArt();
        return false;
    }

    // ---- UI scale -------------------------------------------------------------------------
    inline float    g_scale = 1.f;
    inline uint64_t g_scaleAt = 0;

    inline UObject* CdoOf(UFunction* fn)
    {
        if (!fn) return nullptr;
        UClass* cls = reinterpret_cast<UClass*>(reinterpret_cast<UObject*>(fn)->Outer);
        return Valid(cls) ? cls->ClassDefaultObject : nullptr;
    }

    inline float UiScale(AHUD* hud, float fallback)
    {
        const uint64_t now = GetTickCount64();
        if (now - g_scaleAt < 1000) return g_scale;
        g_scaleAt = now;
        const auto& r = EngineRefs::g_refs;
        float ui = 1.f, vp = fallback;
        bool ok = false;
        if (UObject* cdo = CdoOf(r.victoryGetUIScale))
        {
            struct { float ReturnValue; } p{ 1.f };
            UObject::ProcessEvent(cdo, r.victoryGetUIScale, &p);
            if (p.ReturnValue > 0.05f && p.ReturnValue < 20.f) ui = p.ReturnValue;
        }
        if (UObject* cdo = CdoOf(r.wllGetViewportScale))
        {
            struct { UObject* WorldContextObject; float ReturnValue; } p{ reinterpret_cast<UObject*>(hud), 1.f };
            UObject::ProcessEvent(cdo, r.wllGetViewportScale, &p);
            if (p.ReturnValue > 0.05f && p.ReturnValue < 20.f) { vp = p.ReturnValue; ok = true; }
        }
        const float s = ui * vp;
        g_scale = (ok && s > 0.05f && s < 20.f) ? s : fallback;
        return g_scale;
    }

    // ---- fade: a dynamic instance with MaxOpacity ------------------------------------------
    inline UObject* g_mid = nullptr;
    inline int32_t  g_midIdx = -1;
    inline UObject* g_midBase = nullptr;
    inline float    g_applied = -1.f;

    inline bool Alive(UObject* o, int32_t idx)
    {
        auto& objs = UObject::GetGlobalObjects();
        return o && idx > 0 && idx < objs.Count() && objs.GetByIndex(idx) == o;
    }

    inline void Release()
    {
        if (Alive(g_mid, g_midIdx)) g_mid->Flags &= ~RF_RootSet;
        g_mid = nullptr; g_midBase = nullptr; g_midIdx = -1; g_applied = -1.f;
    }

    // WORLD SAFETY. The instance is root-set (so the GC leaves it alone), and a
    // root-set object keeps its whole Outer chain alive. Created with the HUD
    // as world context, its Outer WAS the HUD -> level -> world, so leaving a
    // map kept the old world alive and UE fataled on every sub-level
    // ("World /Game/Maps/Extinction/... not cleaned up by garbage collection",
    // x31, the load never finished). Now: no world context (Outer = the
    // transient package, as the reference does), and released on any world
    // change regardless.
    inline UWorld* g_midWorld = nullptr;

    inline UObject* Faded(AHUD* hud, UObject* base, float alpha)
    {
        const auto& r = EngineRefs::g_refs;
        UWorld* world = UWorld::Get();
        if (world != g_midWorld) { Release(); g_midWorld = world; }
        if (Alive(g_mid, g_midIdx) && g_midBase != base) Release();
        if (!Alive(g_mid, g_midIdx))
        {
            g_mid = nullptr;
            if (!r.kismetCreateMID || !r.kismetMaterialCDO || !r.midSetScalar || r.nameMaxOpacity <= 0) return base;
            struct { UObject* WorldContextObject; UObject* Parent; UObject* ReturnValue; } p{ nullptr, base, nullptr };
            UObject::ProcessEvent(r.kismetMaterialCDO, r.kismetCreateMID, &p);
            if (!Valid(p.ReturnValue)) return base;
            g_mid = p.ReturnValue;
            g_midIdx = g_mid->InternalIndex;
            g_midBase = base;
            g_mid->Flags |= RF_RootSet;
            g_applied = -1.f;
        }
        if (alpha != g_applied)
        {
            struct { FName ParameterName; float Value; } p{ FName(r.nameMaxOpacity), kMaxOpacity * alpha };
            UObject::ProcessEvent(g_mid, r.midSetScalar, &p);
            g_applied = alpha;
        }
        return g_mid;
    }

    // ---- drawing --------------------------------------------------------------------------
    inline void EdgeQuad(AHUD* hud, UTexture* tex, float x, float y, float w, float h, float u, float v, float uw, float vh, float alpha)
    {
        if (w <= 0.f || h <= 0.f || !EngineRefs::g_refs.hudDrawTexture) return;
        struct { UTexture* Texture; float ScreenX, ScreenY, ScreenW, ScreenH, TextureU, TextureV, TextureUWidth, TextureVHeight;
                 FLinearColor TintColor; EBlendMode BlendMode; unsigned char pad0[3]; float Scale; bool bScalePosition;
                 unsigned char pad1[3]; float Rotation; FVector2D RotPivot; } p{};
        p.Texture = tex; p.ScreenX = x; p.ScreenY = y; p.ScreenW = w; p.ScreenH = h;
        p.TextureU = u; p.TextureV = v; p.TextureUWidth = uw; p.TextureVHeight = vh;
        p.TintColor = FLinearColor(1.f, 1.f, 1.f, alpha);
        p.BlendMode = EBlendMode::BLEND_Translucent;
        p.Scale = 1.f; p.RotPivot = FVector2D(0.5f, 0.5f);
        UObject::ProcessEvent(hud, EngineRefs::g_refs.hudDrawTexture, &p);
    }

    inline void DrawEdge(AHUD* hud, UTexture* tex, float x, float y, float w, float h, float e, float alpha)
    {
        const float xs[4] = { x, x + e, x + w - e, x + w };
        const float ys[4] = { y, y + e, y + h - e, y + h };
        const float uv[4] = { 0.f, kEdgeUv, 1.f - kEdgeUv, 1.f };
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                EdgeQuad(hud, tex, xs[i], ys[j], xs[i + 1] - xs[i], ys[j + 1] - ys[j], uv[i], uv[j], uv[i + 1] - uv[i], uv[j + 1] - uv[j], alpha);
    }

    // Edge thickness on screen (for the spyglass's inner padding).
    inline float EdgePx(AHUD* hud, float fallback) { return (kEdge + kPad) * UiScale(hud, fallback); }

    inline void Draw(AHUD* hud, float x, float y, float w, float h, float alpha, float fallbackScale)
    {
        UObject* base = MaterialBase();
        if (!Valid(base) || alpha <= 0.f) return;
        const float s = UiScale(hud, fallbackScale);
        if (UObject* edge = EdgeTexture(); Valid(edge))
            DrawEdge(hud, reinterpret_cast<UTexture*>(edge), x, y, w, h, kEdge * s, alpha);
        const float p = kPad * s;
        x += p; y += p; w -= p * 2.f; h -= p * 2.f;

        struct { UObject* Material; float ScreenX, ScreenY, ScreenW, ScreenH, MaterialU, MaterialV, MaterialUWidth, MaterialVHeight, Scale;
                 bool bScalePosition; uint8_t pad[3]; float Rotation; FVector2D RotPivot; } m{};
        m.Material = Faded(hud, base, alpha);
        m.ScreenX = x; m.ScreenY = y; m.ScreenW = w; m.ScreenH = h;
        m.MaterialU = 0.f; m.MaterialV = 0.f;
        m.MaterialUWidth = w / (kTileW * s); m.MaterialVHeight = h / (kTileH * s);
        m.Scale = 1.f; m.RotPivot = FVector2D(0.5f, 0.5f);
        UObject::ProcessEvent(hud, EngineRefs::g_refs.hudDrawMaterial, &m);
    }
}

#pragma once
#include <Global.h>
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "imgui.h"
#include <algorithm>
#include <string>

// ============================================================================
//  Armor HUD - ported from ArkHoles' DrawArmor. Drawn from the AShooterHUD::
//  DrawHUD hook on the game thread through the engine's own HUD/Canvas calls,
//  so it shows the real item icons (colorized HUD material, or the icon
//  texture) and Roboto text. Stacked bottom-up on the right edge.
// ============================================================================

namespace ArmorHud
{
    constexpr uintptr_t kInventory   = 0x0D20; // AShooterCharacter -> UPrimalInventoryComponent*
    constexpr uintptr_t kInvItems    = 0x0118; // TArray<UPrimalItem*> InventoryItems
    constexpr uintptr_t kEquipped    = 0x0128; // TArray<UPrimalItem*> EquippedItems
    constexpr uintptr_t kQuality     = 0x0298; // UPrimalItem::ItemQualityIndex
    constexpr uintptr_t kDurability  = 0x057C; // UPrimalItem::ItemDurability
    constexpr uintptr_t kIconTexture = 0x05A0; // UPrimalItem::ItemIcon (Texture2D)
    constexpr uintptr_t kIconMat     = 0x05B8; // UPrimalItem colorized HUD icon material

    inline bool Valid(const void* p) { return reinterpret_cast<uintptr_t>(p) >= 0x10000; }

    // Engine UFunctions / fonts come from the shared background resolver.
    inline EngineRefs::Refs& g_refs = EngineRefs::g_refs;

    // Roboto18 - the font ARK's own HUD text (structure / owner info) uses.
    inline UFont* Font() { return g_refs.font18; }

    // ---- engine draw wrappers (param layouts match the SDK's AHUD/UCanvas) -
    inline void DrawTexture(AHUD* hud, UTexture* tex, float x, float y, float w, float h)
    {
        if (!g_refs.hudDrawTexture) return;
        struct { UTexture* Texture; float ScreenX, ScreenY, ScreenW, ScreenH, TextureU, TextureV, TextureUWidth, TextureVHeight;
                 FLinearColor TintColor; EBlendMode BlendMode; unsigned char pad0[3]; float Scale; bool bScalePosition;
                 unsigned char pad1[3]; float Rotation; FVector2D RotPivot; } p{};
        p.Texture = tex; p.ScreenX = x; p.ScreenY = y; p.ScreenW = w; p.ScreenH = h;
        p.TextureUWidth = 1.f; p.TextureVHeight = 1.f;
        p.TintColor = FLinearColor(1.f, 1.f, 1.f, 1.f);
        p.BlendMode = EBlendMode::BLEND_Translucent;
        p.Scale = 1.f; p.RotPivot = FVector2D(0.5f, 0.5f);
        UObject::ProcessEvent(hud, g_refs.hudDrawTexture, &p);
    }

    inline void DrawMaterial(AHUD* hud, UMaterialInterface* mat, float x, float y, float w, float h)
    {
        if (!g_refs.hudDrawMaterialSimple) return;
        struct { UMaterialInterface* Material; float ScreenX, ScreenY, ScreenW, ScreenH, Scale; bool bScalePosition; } p{};
        p.Material = mat; p.ScreenX = x; p.ScreenY = y; p.ScreenW = w; p.ScreenH = h; p.Scale = 1.f;
        UObject::ProcessEvent(hud, g_refs.hudDrawMaterialSimple, &p);
    }

    inline void DrawRect(AHUD* hud, const FLinearColor& c, float x, float y, float w, float h)
    {
        if (!g_refs.hudDrawRect) return;
        struct { FLinearColor RectColor; float ScreenX, ScreenY, ScreenW, ScreenH; } p{};
        p.RectColor = c; p.ScreenX = x; p.ScreenY = y; p.ScreenW = w; p.ScreenH = h;
        UObject::ProcessEvent(hud, g_refs.hudDrawRect, &p);
    }

    inline FVector2D TextSize(AHUD* hud, const wchar_t* text, float scale)
    {
        FVector2D out(0.f, 0.f);
        if (!g_refs.hudGetTextSize) return out;
        struct { FString Text; float OutWidth, OutHeight; UFont* Font; float Scale; } p{};
        p.Text = FString(text); p.Font = Font(); p.Scale = scale;
        UObject::ProcessEvent(hud, g_refs.hudGetTextSize, &p);
        out.X = p.OutWidth; out.Y = p.OutHeight;
        return out;
    }

    // Plain HUD text (AHUD::DrawText): no outline, no shadow, scalable - the
    // Canvas K2_DrawText path drew black borders and couldn't scale.
    inline void DrawTextRaw(AHUD* hud, const wchar_t* text, float x, float y, const FLinearColor& color, float scale)
    {
        struct { FString Text; FLinearColor TextColor; float ScreenX, ScreenY; UFont* Font; float Scale; bool bScalePosition; } p{};
        p.Text = FString(text); p.TextColor = color; p.ScreenX = x; p.ScreenY = y; p.Font = Font(); p.Scale = scale;
        UObject::ProcessEvent(hud, g_refs.hudDrawText, &p);
    }

    // Plain Roboto text - no outline, no shadow. Whole-pixel positions keep
    // the bitmap font sharp.
    inline void DrawText(AHUD* hud, const wchar_t* text, float x, float y, const FLinearColor& color, float scale)
    {
        if (!g_refs.hudDrawText) return;
        DrawTextRaw(hud, text, floorf(x + 0.5f), floorf(y + 0.5f), color, scale);
    }

    // ---- data -------------------------------------------------------------
    template <typename T> inline T Read(const void* base, uintptr_t off)
    {
        return *reinterpret_cast<const T*>(reinterpret_cast<const uint8_t*>(base) + off);
    }

    // Walks the object's class chain instead of AActor::IsPlayer(), whose
    // FindClass() does the same full GObjects scan on first use.
    inline bool IsShooterCharacter(const UObject* o)
    {
        int depth = 0;
        for (UStruct* s = o->Class; Valid(s) && depth < 16; s = s->SuperField, depth++)
            if (s->GetName() == "ShooterCharacter") return true;
        return false;
    }

    inline void Note(int reason, const char* msg, int extra = 0)
    {
        static int s_last = -1;
        if (reason == s_last) return;
        s_last = reason;
        Logger::Log("[ArmorHud] %s (%d)", msg, extra);
    }

    struct MaxEntry { void* item; void* cls; float maxSeen; };
    inline MaxEntry s_max[32];
    inline int      s_maxCount = 0;

    // ARK exposes no readable max durability; the highest value seen is it.
    inline float ObservedMax(UObject* item, float cur)
    {
        for (int i = 0; i < s_maxCount; i++)
            if (s_max[i].item == item && s_max[i].cls == item->Class)
            {
                if (cur > s_max[i].maxSeen) s_max[i].maxSeen = cur;
                return s_max[i].maxSeen;
            }
        static int s_next = 0;
        if (s_maxCount < 32) s_max[s_maxCount++] = { item, item->Class, cur };
        else { s_max[s_next] = { item, item->Class, cur }; s_next = (s_next + 1) % 32; }
        return cur;
    }

    inline int SlotFromName(const std::string& n)
    {
        if (n.find("Shield") != std::string::npos) return 5;
        if (n.find("Helmet") != std::string::npos || n.find("Hat") != std::string::npos) return 4;
        if (n.find("Shirt") != std::string::npos || n.find("Chest") != std::string::npos) return 3;
        if (n.find("Gloves") != std::string::npos || n.find("Gauntlets") != std::string::npos) return 2;
        if (n.find("Pants") != std::string::npos || n.find("Legs") != std::string::npos) return 1;
        if (n.find("Boots") != std::string::npos || n.find("Feet") != std::string::npos) return 0;
        return 99;
    }

    inline FLinearColor QualityColor(int q)
    {
        static const float c[][3] = { {0.5f, 0.5f, 0.5f}, {0.f, 0.8f, 0.f}, {0.2f, 0.4f, 1.f},
                                      {0.6f, 0.2f, 0.8f}, {1.f, 0.85f, 0.f}, {0.f, 1.f, 1.f} };
        if (q < 0 || q > 5) q = 0;
        return FLinearColor(c[q][0], c[q][1], c[q][2], 1.f);
    }

    // ArkHoles ResolveArmorIconEx: colorized HUD material (+0x5B8), else icon
    // texture (+0x5A0), else GetHUDIconMaterial / BPGetItemIcon. Resolved
    // results are cached per item so the UFunctions run at most once each.
    inline void ResolveIcon(UObject* item, APlayerController* pc, UMaterialInterface** outMat, UTexture** outTex)
    {
        struct Entry { void* item; void* cls; UMaterialInterface* mat; UTexture* tex; };
        static Entry cache[32] = {};
        static int count = 0, next = 0;

        *outMat = nullptr; *outTex = nullptr;
        for (int i = 0; i < count; i++)
            if (cache[i].item == item && cache[i].cls == item->Class)
            {
                *outMat = cache[i].mat; *outTex = cache[i].tex;
                return;
            }

        UMaterialInterface* mat = Read<UMaterialInterface*>(item, kIconMat);
        UTexture* tex = Valid(mat) ? nullptr : Read<UTexture*>(item, kIconTexture);
        if (!Valid(mat) && !Valid(tex))
        {
            if (g_refs.itemGetHudIcon)
            {
                struct { UMaterialInterface* ReturnValue; } p{};
                UObject::ProcessEvent(item, g_refs.itemGetHudIcon, &p);
                if (Valid(p.ReturnValue)) mat = p.ReturnValue;
            }
            if (!Valid(mat) && g_refs.itemBPGetItemIcon)
            {
                struct { APlayerController* ForPC; UTexture* ReturnValue; } p{};
                p.ForPC = pc;
                UObject::ProcessEvent(item, g_refs.itemBPGetItemIcon, &p);
                if (Valid(p.ReturnValue)) tex = p.ReturnValue;
            }
        }
        if (Valid(mat)) *outMat = mat;
        if (Valid(tex)) *outTex = tex;

        // Unresolved items are not cached so a still-streaming icon retries.
        if (*outMat || *outTex)
        {
            Entry e{ item, item->Class, *outMat, *outTex };
            if (count < 32) cache[count++] = e;
            else { cache[next] = e; next = (next + 1) % 32; }
        }
    }

    struct Piece
    {
        int                 slot;
        float               durability;
        float               maxSeen;
        int                 quality;
        int                 spares;
        UMaterialInterface* mat;
        UTexture*           tex;
    };

    // Called from the DrawHUD hook (game thread) under SEH.
    inline void DrawOnHud(AHUD* hud)
    {
        if (!Settings::Ini::DrawArmor || !Valid(hud) || !Valid(hud->Canvas)) return;
        if (!EngineRefs::Ready()) return;

        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        if (!pc) { Note(1, "no local PlayerController"); return; }

        AActor* actor = reinterpret_cast<AActor*>(pc->AcknowledgedPawn);
        if (!Valid(actor)) { Note(2, "no pawn"); return; }
        if (!IsShooterCharacter(actor))
        {
            // Mounted: the pawn is the dino, so use the rider's character.
            actor = pc->LastControlledPlayerCharacter.Get();
            if (!Valid(actor) || !IsShooterCharacter(actor)) { Note(3, "pawn is not a ShooterCharacter"); return; }
        }

        UObject* inv = Read<UObject*>(actor, kInventory);
        if (!Valid(inv)) { Note(4, "no inventory component"); return; }
        const auto& equipped  = *reinterpret_cast<const TArray<UObject*>*>(reinterpret_cast<const uint8_t*>(inv) + kEquipped);
        const auto& inventory = *reinterpret_cast<const TArray<UObject*>*>(reinterpret_cast<const uint8_t*>(inv) + kInvItems);

        Piece pieces[12];
        int count = 0;
        const int n = equipped.Count();
        for (int i = 0; i < n && count < (int)_countof(pieces); i++)
        {
            UObject* item = equipped[i];
            if (!Valid(item) || !Valid(item->Class)) continue;

            const std::string name = item->GetName();
            if (name.find("Saddle") != std::string::npos) continue;
            if (name.find("PrimalItemArmor") == std::string::npos &&
                name.find("ArmorPrimalItem") == std::string::npos &&
                name.find("Shield") == std::string::npos) continue;

            Piece p{};
            p.slot       = SlotFromName(name);
            p.durability = Read<float>(item, kDurability);
            p.maxSeen    = ObservedMax(item, p.durability);
            p.quality    = Read<uint8_t>(item, kQuality);
            ResolveIcon(item, pc, &p.mat, &p.tex);
            if (Settings::Ini::DrawArmorCount)
            {
                const int m = inventory.Count();
                for (int j = 0; j < m; j++)
                {
                    UObject* other = inventory[j];
                    if (Valid(other) && other->Class == item->Class) p.spares++;
                }
            }
            pieces[count++] = p;
        }
        if (count == 0) { Note(5, "no armor among equipped items", n); return; }
        Note(6, "drawing armor pieces", count);
        std::sort(pieces, pieces + count, [](const Piece& a, const Piece& b) { return a.slot < b.slot; });

        // ArkHoles layout: canvas clip size (UCanvas ClipX/ClipY at +0x30/+0x34)
        // is the screen, 1440p reference height scales everything.
        const float clipX = Read<float>(hud->Canvas, 0x30);
        const float clipY = Read<float>(hud->Canvas, 0x34);
        const ImVec2 screen = (clipX > 0.f && clipY > 0.f) ? ImVec2(clipX, clipY) : ImGui::GetIO().DisplaySize;
        float hr = screen.y / 1440.f;
        if (hr < 0.25f) hr = 1.f;
        const float scale     = Settings::Ini::ArmorHudScale * hr;
        // Whole-pixel icon size / spacing / positions keep the icons crisp.
        const float iconSize  = roundf(40.f * scale);
        const float spacing   = roundf(25.f * scale);

        const float x = roundf(screen.x - 50.f * scale);
        float y = roundf(screen.y - Settings::Ini::ArmorHudYOffset * hr);

        // Text has its own scale and can be moved relative to its icon.
        const float textScale = Settings::Ini::ArmorTextScale;
        const float textDX    = Settings::Ini::ArmorTextOffsetX * hr;
        const float textDY    = Settings::Ini::ArmorTextOffsetY * hr;

        for (int i = 0; i < count; i++)
        {
            const Piece& p = pieces[i];
            if (p.mat)      DrawMaterial(hud, p.mat, x, y, iconSize, iconSize);
            else if (p.tex) DrawTexture(hud, p.tex, x, y, iconSize, iconSize);
            else            DrawRect(hud, FLinearColor(0.15f, 0.15f, 0.15f, 0.75f), x, y, iconSize, iconSize);

            if (Settings::Ini::DrawArmorDurability || Settings::Ini::DrawArmorPercent)
            {
                float pct = -1.f;
                if (p.maxSeen > 0.1f) pct = std::clamp(p.durability / p.maxSeen * 100.f, 0.f, 100.f);

                wchar_t buf[32];
                if (Settings::Ini::DrawArmorPercent && pct >= 0.f) swprintf_s(buf, L"%.1f%%", pct);
                else swprintf_s(buf, L"%.0f", p.durability);

                FLinearColor col = QualityColor(p.quality);
                if (pct >= 0.f)
                    col = pct > 66.f ? FLinearColor(0.1f, 1.f, 0.1f, 1.f)
                        : pct > 33.f ? FLinearColor(1.f, 0.7f, 0.f, 1.f)
                                     : FLinearColor(1.f, 0.15f, 0.15f, 1.f);

                // Centred under the icon by default, moved by Text X / Text Y,
                // kept 4px inside both screen edges.
                const FVector2D ts = TextSize(hud, buf, textScale);
                const float halfW = ts.X * 0.5f;
                const float kEdgePad = 4.f;
                float cx = x + iconSize * 0.5f + textDX;
                if (cx + halfW > screen.x - kEdgePad) cx = screen.x - kEdgePad - halfW;
                if (cx - halfW < kEdgePad) cx = kEdgePad + halfW;
                DrawText(hud, buf, cx - halfW, y + iconSize + 1.f * scale + textDY, col, textScale);
            }

            if (Settings::Ini::DrawArmorCount && p.spares > 0)
            {
                // ARK's own count style ("x2", like the hotbar), vertically
                // centred on the icon with a gap proportional to its size.
                wchar_t buf[16];
                swprintf_s(buf, L"x%d", p.spares);
                const FVector2D cs = TextSize(hud, buf, textScale);
                DrawText(hud, buf, x - iconSize * 0.18f - cs.X, y + (iconSize - cs.Y) * 0.5f,
                         FLinearColor(1.f, 0.8f, 0.f, 1.f), textScale);
            }

            y -= iconSize + spacing;
        }
    }
}

#pragma once
// ============================================================================
// Crosshair - a custom crosshair that replaces ARK's, drawn by ARK's HUD.
//
// ARK's crosshair is AShooterHUD::Crosshair[5], five FCanvasIcons cut from the
// HUDMain atlas (0x18 each: Texture, U, V, UL, VL - read live):
//     [0] left arm 25x9   [1] right arm 25x9   [2] top arm 9x25
//     [3] bottom arm 9x25 [4] centre dot 7x7
//
// While on:
//   - the game's own crosshair is blanked for the duration of ARK's DrawHUD
//     (the five icon textures are nulled, then put back right after)
//   - ours is drawn straight after with the HUD's own DrawRect / DrawLine:
//     solid, pixel-snapped shapes (Classic, Cross, Dot, X). ARK's atlas pieces were
//     used first, but they are tapered with dark edges baked in, which gave
//     every style a black outline. UI scale = canvas height / 1080.
// Nothing is drawn by our overlay - it is ARK's HUD canvas.
//
// THREADING: game thread, from the DrawHUD hook.
// ============================================================================
#include <Global.h>
#include <cmath>
#include "Client Manager/Modules/Engine/EngineRefs.h"
#include "Client Manager/Modules/Misc/QuickPickup.h"   // PropOffset

namespace Crosshair
{
    struct FCanvasIcon { UTexture* Texture; float U, V, UL, VL; };
    enum { Left = 0, Right = 1, Top = 2, Bottom = 3, Center = 4 };

    inline constexpr uintptr_t OFF_CROSSHAIR_DEFAULT = 0x08A8;
    inline constexpr uintptr_t OFF_PAWN_INVFLAGS     = 0x1260;   // bit 5: inventory open
    inline constexpr uintptr_t OFF_PC_PAWN           = 0x04E8;

    inline uint32_t g_offIcons   = 0;
    inline uint32_t g_offHidden  = 0;   // bHudHidden
    inline uint32_t g_offOpenInv = 0;   // CurrentOpenedInventory
    inline void*    g_hudClass   = nullptr;

    inline UTexture* g_saved[5] = {};
    inline bool      g_hidden   = false;

    inline bool Valid(const void* p) { return reinterpret_cast<uintptr_t>(p) > 0x10000; }
    template <typename T> inline T& At(const void* b, uintptr_t o) { return *reinterpret_cast<T*>(reinterpret_cast<uintptr_t>(b) + o); }

    inline FCanvasIcon* Icons(AHUD* hud)
    {
        const UObject* h = reinterpret_cast<const UObject*>(hud);
        if (h->Class != g_hudClass)
        {
            g_hudClass   = h->Class;
            g_offIcons   = QuickPickup::PropOffset(h->Class, "Crosshair");
            g_offHidden  = QuickPickup::PropOffset(h->Class, "bHudHidden");
            g_offOpenInv = QuickPickup::PropOffset(h->Class, "CurrentOpenedInventory");
            if (!g_offIcons) g_offIcons = OFF_CROSSHAIR_DEFAULT;
        }
        return &At<FCanvasIcon>(hud, g_offIcons);
    }

    // Around ARK's DrawHUD: blank the game's own crosshair.
    inline void HideBegin(AHUD* hud)
    {
        g_hidden = false;
        if (!Settings::Hud::Crosshair || !Valid(hud)) return;
        FCanvasIcon* ic = Icons(hud);
        if (!Valid(ic[Center].Texture)) return;   // not set up (yet)
        for (int i = 0; i < 5; i++) { g_saved[i] = ic[i].Texture; ic[i].Texture = nullptr; }
        g_hidden = true;
    }

    inline void HideEnd(AHUD* hud)
    {
        if (!g_hidden || !Valid(hud)) { g_hidden = false; return; }
        FCanvasIcon* ic = Icons(hud);
        for (int i = 0; i < 5; i++) ic[i].Texture = g_saved[i];
        g_hidden = false;
    }

    // When ARK itself shows a crosshair: HUD up, no inventory open, a character.
    inline bool ShouldDraw(AHUD* hud, bool menuOpen)
    {
        if (menuOpen) return false;
        if (g_offHidden && At<bool>(hud, g_offHidden)) return false;
        if (g_offOpenInv && Valid(At<void*>(hud, g_offOpenInv))) return false;
        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        if (!Valid(pc)) return false;
        void* pawn = At<void*>(pc, OFF_PC_PAWN);
        if (!Valid(pawn)) return false;
        if (At<uint8_t>(pawn, OFF_PAWN_INVFLAGS) & (1u << 5)) return false;
        return true;
    }

    inline void Draw(AHUD* hud, bool menuOpen)
    {
        using S = Settings::Hud;
        if (!S::Crosshair || !Valid(hud) || !Valid(hud->Canvas) || !EngineRefs::Ready()) return;
        if (!ShouldDraw(hud, menuOpen)) return;

        const float clipX = At<float>(hud->Canvas, 0x30), clipY = At<float>(hud->Canvas, 0x34);
        if (!(clipX > 0.f && clipY > 0.f)) return;
        UFunction* rectFn = EngineRefs::g_refs.hudDrawRect;
        if (!rectFn) return;

        // Every style is solid shapes from the HUD's own DrawRect - no texture,
        // so no outline (ARK's crosshair pieces have dark edges baked into the
        // HUDMain atlas). Whole pixels on one shared centre block, so edges stay
        // sharp and every piece lines up; nothing overlaps, so lower opacity
        // stays even.
        const float ui    = clipY / 1080.f;
        const float size  = S::CrossSize > 0.1f ? S::CrossSize : 1.f;
        const float alpha = S::CrossOpacity / 100.f;
        const int   style = S::CrossStyle;
        float T = roundf(S::CrossThickness * ui);
        if (T < 1.f) T = 1.f;
        const float c0x = roundf(clipX * 0.5f - T * 0.5f);   // centre block [c0x, c0x+T)
        const float c0y = roundf(clipY * 0.5f - T * 0.5f);
        const FLinearColor col(S::CrossColor[0], S::CrossColor[1], S::CrossColor[2], alpha);
        auto rect = [&](float x, float y, float w, float h) {
            if (w <= 0.f || h <= 0.f) return;
            struct { FLinearColor RectColor; float ScreenX, ScreenY, ScreenW, ScreenH; } p{ col, x, y, w, h };
            UObject::ProcessEvent(hud, rectFn, &p);
        };

        switch (style)
        {
        case 1:   // Cross: one solid plus
        {
            float a = roundf((20.f * ui * size - T) * 0.5f);   // arm beyond the centre block
            if (a < T) a = T;
            rect(c0x - a, c0y, a * 2.f + T, T);                // horizontal bar
            rect(c0x, c0y - a, T, a);                          // top
            rect(c0x, c0y + T, T, a);                          // bottom
            break;
        }
        case 2:   // Dot: a solid square
        {
            float d = roundf(4.f * ui * size);
            if (d < T) d = T;
            rect(roundf(clipX * 0.5f - d * 0.5f), roundf(clipY * 0.5f - d * 0.5f), d, d);
            break;
        }
        case 3:   // X: four diagonal arms past the gap
        {
            // The HUD's DrawLine (DrawRect can't rotate). Each arm is T exact 45°
            // one-pixel lines side by side - one pixel per row each, so they
            // tile into a solid diagonal T pixels wide with nothing drawn twice.
            UFunction* lineFn = EngineRefs::g_refs.hudDrawLine;
            if (!lineFn) break;
            float a = roundf(10.f * ui * size);
            if (a < T) a = T;
            const float G  = roundf(S::CrossGap * ui);
            const float px = floorf(clipX * 0.5f) + 0.5f;      // pixel centre
            const float py = floorf(clipY * 0.5f) + 0.5f;
            const int   Ti = (int)T;
            static const float kDir[4][2] = { { 1.f, 1.f }, { -1.f, 1.f }, { 1.f, -1.f }, { -1.f, -1.f } };
            for (const auto& d : kDir)
                for (int k = 0; k < Ti; k++)
                {
                    const float off = (float)(k - Ti / 2);
                    struct { float StartScreenX, StartScreenY, EndScreenX, EndScreenY; FLinearColor LineColor; } p{
                        px + d[0] * G + off,       py + d[1] * G,
                        px + d[0] * (G + a) + off, py + d[1] * (G + a), col };
                    UObject::ProcessEvent(hud, lineFn, &p);
                }
            break;
        }
        default:  // Classic (0): dot + four arms past the gap
        {
            float A = roundf(8.f * ui * size);
            if (A < T) A = T;
            const float G = roundf(S::CrossGap * ui);
            rect(c0x, c0y, T, T);                              // centre dot
            rect(c0x - G - A, c0y, A, T);                      // left
            rect(c0x + T + G, c0y, A, T);                      // right
            rect(c0x, c0y + T + G, T, A);                      // bottom
            rect(c0x, c0y - G - A, T, A);                      // top
            break;
        }
        }
    }
}

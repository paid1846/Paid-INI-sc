#pragma once
#include <Windows.h>
#include "imgui.h"
#include "headers/includes.h"
#include "Client Manager/Modules/UI/Input Bridge/InputBridge.h"

// ============================================================================
//  Keybinds - evaluates the Past Owl checkbox keybinds every frame, menu open
//  or closed. Binds are stored as ImGuiKey (the framework's format, shown by
//  get_key_name); key state comes from InputBridge::g_down, the only reliable
//  source in UWP (GetAsyncKeyState on the AttachThreadInput'd input thread).
// ============================================================================

namespace Keybinds
{
    struct KeyPair { int vk; ImGuiKey key; };

    // Generic VK_SHIFT/CONTROL/MENU are omitted; the left/right variants map.
    inline const KeyPair kKeyMap[] = {
        { VK_TAB, ImGuiKey_Tab }, { VK_LEFT, ImGuiKey_LeftArrow }, { VK_RIGHT, ImGuiKey_RightArrow },
        { VK_UP, ImGuiKey_UpArrow }, { VK_DOWN, ImGuiKey_DownArrow }, { VK_PRIOR, ImGuiKey_PageUp },
        { VK_NEXT, ImGuiKey_PageDown }, { VK_HOME, ImGuiKey_Home }, { VK_END, ImGuiKey_End },
        { VK_INSERT, ImGuiKey_Insert }, { VK_DELETE, ImGuiKey_Delete }, { VK_BACK, ImGuiKey_Backspace },
        { VK_SPACE, ImGuiKey_Space }, { VK_RETURN, ImGuiKey_Enter }, { VK_ESCAPE, ImGuiKey_Escape },
        { VK_LCONTROL, ImGuiKey_LeftCtrl }, { VK_LSHIFT, ImGuiKey_LeftShift }, { VK_LMENU, ImGuiKey_LeftAlt },
        { VK_LWIN, ImGuiKey_LeftSuper }, { VK_RCONTROL, ImGuiKey_RightCtrl }, { VK_RSHIFT, ImGuiKey_RightShift },
        { VK_RMENU, ImGuiKey_RightAlt }, { VK_RWIN, ImGuiKey_RightSuper }, { VK_APPS, ImGuiKey_Menu },
        { '0', ImGuiKey_0 }, { '1', ImGuiKey_1 }, { '2', ImGuiKey_2 }, { '3', ImGuiKey_3 }, { '4', ImGuiKey_4 },
        { '5', ImGuiKey_5 }, { '6', ImGuiKey_6 }, { '7', ImGuiKey_7 }, { '8', ImGuiKey_8 }, { '9', ImGuiKey_9 },
        { 'A', ImGuiKey_A }, { 'B', ImGuiKey_B }, { 'C', ImGuiKey_C }, { 'D', ImGuiKey_D }, { 'E', ImGuiKey_E },
        { 'F', ImGuiKey_F }, { 'G', ImGuiKey_G }, { 'H', ImGuiKey_H }, { 'I', ImGuiKey_I }, { 'J', ImGuiKey_J },
        { 'K', ImGuiKey_K }, { 'L', ImGuiKey_L }, { 'M', ImGuiKey_M }, { 'N', ImGuiKey_N }, { 'O', ImGuiKey_O },
        { 'P', ImGuiKey_P }, { 'Q', ImGuiKey_Q }, { 'R', ImGuiKey_R }, { 'S', ImGuiKey_S }, { 'T', ImGuiKey_T },
        { 'U', ImGuiKey_U }, { 'V', ImGuiKey_V }, { 'W', ImGuiKey_W }, { 'X', ImGuiKey_X }, { 'Y', ImGuiKey_Y },
        { 'Z', ImGuiKey_Z },
        { VK_F1, ImGuiKey_F1 }, { VK_F2, ImGuiKey_F2 }, { VK_F3, ImGuiKey_F3 }, { VK_F4, ImGuiKey_F4 },
        { VK_F5, ImGuiKey_F5 }, { VK_F6, ImGuiKey_F6 }, { VK_F7, ImGuiKey_F7 }, { VK_F8, ImGuiKey_F8 },
        { VK_F9, ImGuiKey_F9 }, { VK_F10, ImGuiKey_F10 }, { VK_F11, ImGuiKey_F11 }, { VK_F12, ImGuiKey_F12 },
        { VK_F13, ImGuiKey_F13 }, { VK_F14, ImGuiKey_F14 }, { VK_F15, ImGuiKey_F15 }, { VK_F16, ImGuiKey_F16 },
        { VK_F17, ImGuiKey_F17 }, { VK_F18, ImGuiKey_F18 }, { VK_F19, ImGuiKey_F19 }, { VK_F20, ImGuiKey_F20 },
        { VK_F21, ImGuiKey_F21 }, { VK_F22, ImGuiKey_F22 }, { VK_F23, ImGuiKey_F23 }, { VK_F24, ImGuiKey_F24 },
        { VK_OEM_7, ImGuiKey_Apostrophe }, { VK_OEM_COMMA, ImGuiKey_Comma }, { VK_OEM_MINUS, ImGuiKey_Minus },
        { VK_OEM_PERIOD, ImGuiKey_Period }, { VK_OEM_2, ImGuiKey_Slash }, { VK_OEM_1, ImGuiKey_Semicolon },
        { VK_OEM_PLUS, ImGuiKey_Equal }, { VK_OEM_4, ImGuiKey_LeftBracket }, { VK_OEM_5, ImGuiKey_Backslash },
        { VK_OEM_6, ImGuiKey_RightBracket }, { VK_OEM_3, ImGuiKey_GraveAccent },
        { VK_CAPITAL, ImGuiKey_CapsLock }, { VK_SCROLL, ImGuiKey_ScrollLock }, { VK_NUMLOCK, ImGuiKey_NumLock },
        { VK_SNAPSHOT, ImGuiKey_PrintScreen }, { VK_PAUSE, ImGuiKey_Pause },
        { VK_NUMPAD0, ImGuiKey_Keypad0 }, { VK_NUMPAD1, ImGuiKey_Keypad1 }, { VK_NUMPAD2, ImGuiKey_Keypad2 },
        { VK_NUMPAD3, ImGuiKey_Keypad3 }, { VK_NUMPAD4, ImGuiKey_Keypad4 }, { VK_NUMPAD5, ImGuiKey_Keypad5 },
        { VK_NUMPAD6, ImGuiKey_Keypad6 }, { VK_NUMPAD7, ImGuiKey_Keypad7 }, { VK_NUMPAD8, ImGuiKey_Keypad8 },
        { VK_NUMPAD9, ImGuiKey_Keypad9 }, { VK_DECIMAL, ImGuiKey_KeypadDecimal }, { VK_DIVIDE, ImGuiKey_KeypadDivide },
        { VK_MULTIPLY, ImGuiKey_KeypadMultiply }, { VK_SUBTRACT, ImGuiKey_KeypadSubtract }, { VK_ADD, ImGuiKey_KeypadAdd },
        { VK_BROWSER_BACK, ImGuiKey_AppBack }, { VK_BROWSER_FORWARD, ImGuiKey_AppForward },
    };

    // Mouse buttons reach ImGui as mouse events (it derives the Mouse keys
    // itself), so they only appear in the bind-check direction.
    inline const KeyPair kMouseMap[] = {
        { VK_LBUTTON, ImGuiKey_MouseLeft }, { VK_RBUTTON, ImGuiKey_MouseRight }, { VK_MBUTTON, ImGuiKey_MouseMiddle },
        { VK_XBUTTON1, ImGuiKey_MouseX1 }, { VK_XBUTTON2, ImGuiKey_MouseX2 },
    };

    inline ImGuiKey VkToImGuiKey(int vk)
    {
        for (const auto& p : kKeyMap) if (p.vk == vk) return p.key;
        return ImGuiKey_None;
    }

    inline int ImGuiKeyToVk(int key)
    {
        for (const auto& p : kKeyMap)   if (p.key == key) return p.vk;
        for (const auto& p : kMouseMap) if (p.key == key) return p.vk;
        return 0;
    }

    // Options that can't be on together (mirrors the click handling in gui.cpp).
    // Plain constant arrays: no function-local statics with constructors (the
    // manually mapped DLL has no TLS for thread-safe static init).
    inline constexpr const char* kExclusiveGroups[][3] = {
        { "Normal INI", "Hard INI", "FPS+ (Potato)" },
        { "Show Durability", "Show Percent", nullptr },
    };

    inline void ApplyExclusive(const std::string& turnedOn)
    {
        for (const auto& g : kExclusiveGroups)
        {
            bool member = false;
            for (const char* n : g) if (n && turnedOn == n) member = true;
            if (!member) continue;
            for (const char* n : g)
                if (n && turnedOn != n)
                    if (checkbox_t* o = cfg->fill<checkbox_t>(n)) o->enabled = false;
        }
    }

    // Last seen key state per bind (by keybind idx). Fixed-size POD at
    // namespace scope - this used to be a function-local unordered_map whose
    // constructor never ran in the manually mapped DLL, so the first lookup
    // after adding a hotkey read address 0x8 and crashed the game.
    struct PrevState { int idx; bool down; };
    inline PrevState g_prev[512];
    inline int       g_prevCount = 0;

    inline PrevState* FindPrev(int idx)
    {
        for (int i = 0; i < g_prevCount; i++) if (g_prev[i].idx == idx) return &g_prev[i];
        return nullptr;
    }

    // Call once per frame before the cfg -> Settings sync.
    inline void Evaluate(bool menuOpen)
    {
        // While a bind is being captured or a text field has focus, keys are
        // input, not triggers.
        const bool suppress = menuOpen &&
            (ImGui::GetFrameCount() - widgets->keybind_capture_frame <= 2 || ImGui::GetIO().WantTextInput);

        for (const auto& [name, type] : cfg->order)
        {
            if (type != checkbox_type) continue;
            checkbox_t* cb = cfg->fill<checkbox_t>(name);
            if (!cb || !cb->keybinds_enabled) continue;

            for (const keybind_t& kb : cb->keybinds_list)
            {
                const int  vk   = ImGuiKeyToVk(kb.key);
                const bool down = vk && InputBridge::g_down[vk];

                PrevState* prev = FindPrev(kb.idx);
                if (!prev)
                {
                    // First sight: remember the state, no edge (a key held
                    // while the bind is created must not fire it).
                    if (g_prevCount < (int)_countof(g_prev)) g_prev[g_prevCount++] = { kb.idx, down };
                    continue;
                }
                const bool was = prev->down;
                prev->down = down;
                if (suppress || down == was) continue;

                const bool before = cb->enabled;
                if (kb.mode == 0) { if (down) cb->enabled = !cb->enabled; } // toggle on press
                else              cb->enabled = down;                       // hold
                if (cb->enabled != before)
                {
                    cb->last_keybind = kb;
                    if (cb->enabled) ApplyExclusive(name);
                }
            }
        }
    }
}

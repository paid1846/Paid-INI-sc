// ============================================================================
//  paidini - internal base (ARK: Survival Evolved - Microsoft Store/UWP)
//  DELETE = toggle menu. g_status exported for injector polling.
//
//  UWP notes:
//   - The input window is the CoreWindow child of ApplicationFrameWindow,
//     NOT the swapchain OutputWindow (which is null/foreign on the Store build).
//   - GetAsyncKeyState only returns real key state when called from the thread
//     that owns the CoreWindow. The Present hook runs on the RHI/render thread,
//     so it reads 0. We poll input on a dedicated thread that AttachThreadInput's
//     to ARK's UI thread, store the state, and Present just feeds it to ImGui.
// ============================================================================

#include <Windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <stdio.h>
#include <mutex>

#include "MinHook.h"
// Past Owl menu framework (its own ImGui 1.91.3 - include dirs must resolve
// "imgui.h" to the framework copy, NOT Client/ImGui)
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_dx11.h"
#include "headers/includes.h"
#include "Logger/Logger.h"
#include "Global.h"
#include "Client Manager/Modules/INI Presets/IniPresets.h"
#include "Client Manager/Modules/INI Presets/StalkerVision.h"
#include "Client Manager/Modules/Camera/CustomFov.h"
#include "Client Manager/Modules/HUD/ArmorHud.h"
#include "Client Manager/Modules/HUD/InfoHud.h"
#include "Client Manager/Modules/HUD/Crosshair.h"
#include "Client Manager/Modules/HUD/TekIndicator.h"
#include "Client Manager/Modules/HUD/AwesomeSpyglass.h"
#include "Client Manager/Modules/Keybinds/Keybinds.h"
#include "Client Manager/Modules/Misc/QuickPickup.h"
#include "Client Manager/Modules/Misc/StructureSnap.h"
#include "Client Manager/Modules/Misc/BetterInput.h"
#include "Client Manager/Modules/Misc/ChatBypass.h"
#include "Client Manager/Modules/Misc/TakeAll.h"
#include "Client Manager/Modules/Misc/TurretFiller.h"
#include "Client Manager/Modules/Engine/CrashGuard.h"
#include "Client Manager/Modules/Misc/AutoForge.h"
#include "Client Manager/Modules/Dino/Breeding.h"
#include "Client Manager/Modules/Visual/ColorFilter.h"
#include "Client Manager/Modules/UI/Input Bridge/InputBridge.h"
#include "Client Manager/Hooks/Crash/LowLevelFatal.h"
#include "Client Manager/Modules/Notifications/Notifications.h"
#include "helpers/config_system.h"

extern IMGUI_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

// ---------------------------------------------------------------------------
// Menu cursor fix - folded in (was Client/CursorFix.cpp/.h, file removed).
// UWP CoreWindow menu cursor: WndProc subclass + SetCursor hooks + SDK
// bShowMouseCursor + DisableInput block + per-frame cursor feed.
// ---------------------------------------------------------------------------
namespace CursorFix
{
    typedef BOOL(WINAPI* SetCursorPos_t)(int, int);
    typedef HCURSOR(WINAPI* SetCursor_t)(HCURSOR);

    static SetCursorPos_t oSetCursorPos = nullptr;
    static SetCursor_t    oSetCursor    = nullptr;
    static WNDPROC        oWndProc      = nullptr;
    static HWND           s_hookedWnd   = nullptr;
    static volatile bool  s_menuActive  = false;

    inline bool InitGameSdk()
    {
        static bool s_ok = false;
        if (s_ok) return true;
        s_ok = ::InitSDK();
        return s_ok;
    }

    static APlayerController* ResolvePlayerController()
    {
        ULocalPlayer* lp = ULocalPlayer::Get();
        return lp ? lp->PlayerController : nullptr;
    }

    inline void* GetPlayerController()
    {
        return ResolvePlayerController();
    }

    static void SetGameMouseCursor(APlayerController* pc, bool shown)
    {
        if (!pc) return;
        pc->bShowMouseCursor = shown;
    }

    // Menu-open input block. The render thread only records the wanted state;
    // ApplyInputBlock() runs on the game thread (DrawHUD hook) because
    // ProcessEvent is not safe off the game thread. The UFunctions come from
    // EngineRefs - the SDK's FindObject here used to freeze for seconds.
    static volatile bool s_wantBlock = false;
    static volatile bool s_blocked   = false;

    // The controller the block was applied to (index + serial), and its cursor
    // setting before we forced it on. A disconnect / transfer replaces the
    // controller: the block then belongs to one that is gone, and must never be
    // "undone" on the new one - that switched the main menu's cursor off (the
    // vanishing mouse).
    static APlayerController* volatile s_blockedPc = nullptr;
    static int32_t s_blockedIdx = 0, s_blockedSerial = 0;
    static bool    s_savedCursor = false;

    static bool SameObject(const void* obj, int32_t idx, int32_t serial)
    {
        auto& objs = UObject::GetGlobalObjects();
        if (!obj || idx <= 0 || idx >= objs.Count()) return false;
        FUObjectItem* item = objs.GetItemByIndex(idx);
        return item && item->Object == obj && item->SerialNumber == serial;
    }

    // Forget a block whose controller has been replaced or destroyed (nothing
    // to undo: the engine took it down with its world). Any thread.
    static void DropStaleBlock()
    {
        s_blocked   = false;
        s_blockedPc = nullptr;
    }

    static void SyncPlayerInputBlock(bool want) { s_wantBlock = want; }

    // Game thread only.
    static void ApplyInputBlock()
    {
        if (!EngineRefs::Ready()) return;
        APlayerController* pc = ResolvePlayerController();

        // Blocked controller replaced (disconnect, transfer, respawn into a new
        // controller): drop the block instead of applying the undo elsewhere.
        if (s_blocked && (pc != s_blockedPc || !SameObject(s_blockedPc, s_blockedIdx, s_blockedSerial)))
            DropStaleBlock();

        const bool want = s_wantBlock;
        if (want == s_blocked || !pc) return;

        if (want)
        {
            s_savedCursor = pc->bShowMouseCursor;
            SetGameMouseCursor(pc, true);
        }
        else
            SetGameMouseCursor(pc, s_savedCursor);   // back to what the game had

        const auto& r = EngineRefs::g_refs;
        if (r.actorDisableInput && r.actorEnableInput)
        {
            UFunction* fn = want ? r.actorDisableInput : r.actorEnableInput;
            struct { APlayerController* PlayerController; } params{ pc };
            UObject::ProcessEvent(pc, fn, &params);

            if (r.pcGetPlayerCharacter)
            {
                struct { AActor* ReturnValue; } out{};
                UObject::ProcessEvent(pc, r.pcGetPlayerCharacter, &out);
                if (out.ReturnValue)
                    UObject::ProcessEvent(out.ReturnValue, fn, &params);
            }
        }

        if (want)
        {
            const int32_t idx = reinterpret_cast<UObject*>(pc)->InternalIndex;
            FUObjectItem* item = UObject::GetGlobalObjects().GetItemByIndex(idx);
            s_blockedIdx = idx; s_blockedSerial = item ? item->SerialNumber : 0;
            s_blockedPc = pc;
        }
        else
            s_blockedPc = nullptr;
        s_blocked = want;
    }

    static BOOL WINAPI hkSetCursorPos(int X, int Y)
    {
        if (s_menuActive) return 0;
        return oSetCursorPos(X, Y);
    }

    static HCURSOR WINAPI hkSetCursor(HCURSOR hCursor)
    {
        if (s_menuActive) return nullptr;
        return oSetCursor(hCursor);
    }

    inline void CreateHooks()
    {
        HMODULE user32 = GetModuleHandleA("user32.dll");
        if (!user32) return;

        void* pSetCursorPos = reinterpret_cast<void*>(GetProcAddress(user32, "SetCursorPos"));
        void* pSetCursor    = reinterpret_cast<void*>(GetProcAddress(user32, "SetCursor"));

        if (pSetCursorPos)
            MH_CreateHook(pSetCursorPos, &hkSetCursorPos, reinterpret_cast<void**>(&oSetCursorPos));
        if (pSetCursor)
            MH_CreateHook(pSetCursor, &hkSetCursor, reinterpret_cast<void**>(&oSetCursor));
    }

    static bool IsInputMsg(UINT msg)
    {
        if (msg >= WM_KEYFIRST     && msg <= WM_KEYLAST)         return true;
        if (msg >= WM_MOUSEFIRST   && msg <= WM_MOUSELAST)       return true;
        if (msg >= WM_NCMOUSEMOVE  && msg <= WM_NCXBUTTONDBLCLK) return true;
        if (msg >= 0x0240          && msg <= 0x0257)             return true;
        if (msg == WM_INPUT)                                     return true;
        if (msg == WM_SETCURSOR)                                 return true;
        return false;
    }

    // Written by hkWndProc (game UI thread), consumed once per frame by
    // PerFrame (render thread). ImGui is NOT thread-safe: calling it from the
    // WndProc raced the render thread's NewFrame (corrupted menu state,
    // double clicks, an ever-growing input queue at high mouse polling rates).
    static volatile LONG64 s_ptrClient = 0;   // lo32 = x, hi32 = y (client px)
    static volatile LONG64 s_ptrSize   = 0;   // lo32 = client w, hi32 = client h
    static volatile LONG   s_ptrValid  = 0;   // a pointer update arrived this menu session
    static volatile LONG   s_wheel     = 0;   // accumulated wheel delta (WHEEL_DELTA units)

    static LRESULT WINAPI hkWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
        // UWP/Store build sends WM_POINTERWHEEL (0x024E) instead of WM_MOUSEWHEEL.
        constexpr UINT WM_POINTERWHEEL_ = 0x024E;
        if (msg == WM_POINTERWHEEL_ || msg == WM_MOUSEWHEEL)
        {
            InterlockedExchangeAdd(&s_wheel, (LONG)GET_WHEEL_DELTA_WPARAM(wParam));
            if (s_menuActive) return 0;   // swallow from game while menu is open
        }

        // UWP CoreWindow: the cursor is locked in FPS mode, so GetCursorPos()
        // returns a fixed center. WM_POINTERUPDATE (0x0245) carries the real
        // screen-space position - keep only the latest one.
        constexpr UINT WM_POINTERUPDATE_ = 0x0245;
        if (msg == WM_POINTERUPDATE_ && s_menuActive)
        {
            POINT pt = { (short)LOWORD(lParam), (short)HIWORD(lParam) };
            RECT cr{};
            if (ScreenToClient(hWnd, &pt) && GetClientRect(hWnd, &cr) && cr.right > 0 && cr.bottom > 0)
            {
                InterlockedExchange64(&s_ptrSize, (LONG64)(uint32_t)cr.right | ((LONG64)(uint32_t)cr.bottom << 32));
                InterlockedExchange64(&s_ptrClient, (LONG64)(uint32_t)pt.x | ((LONG64)(uint32_t)pt.y << 32));
                InterlockedExchange(&s_ptrValid, 1);
            }
        }

        // Keys/chars come from InputBridge and buttons from the InputThread
        // poll, so nothing here is forwarded to ImGui; while the menu is open
        // the game just doesn't see input.
        if (s_menuActive && IsInputMsg(msg)) return 0;
        if (oWndProc)
            return CallWindowProcW(oWndProc, hWnd, msg, wParam, lParam);
        return DefWindowProcW(hWnd, msg, wParam, lParam);
    }

    static void HookWndProc(HWND hWnd)
    {
        if (!hWnd || !IsWindow(hWnd)) return;
        if (reinterpret_cast<WNDPROC>(GetWindowLongPtrW(hWnd, GWLP_WNDPROC)) == hkWndProc) return;
        oWndProc = reinterpret_cast<WNDPROC>(SetWindowLongPtrW(hWnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(hkWndProc)));
        s_hookedWnd = hWnd;
    }

    static void UnhookWndProc(HWND hWnd)
    {
        if (!hWnd || !oWndProc) return;
        if (reinterpret_cast<WNDPROC>(GetWindowLongPtrW(hWnd, GWLP_WNDPROC)) == hkWndProc)
            SetWindowLongPtrW(hWnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(oWndProc));
        oWndProc    = nullptr;
        s_hookedWnd = nullptr;
    }

    inline void OnMenuToggled(HWND hWnd, bool active)
    {
        if (active)
        {
            InterlockedExchange(&s_ptrValid, 0); // fresh pointer source each session
            InterlockedExchange(&s_wheel, 0);
        }
        s_menuActive = active;
        if (active) HookWndProc(hWnd);
        else        UnhookWndProc(hWnd);
    }

    inline void PerFrame(HWND hWnd, bool menuOpen)
    {
        SyncPlayerInputBlock(menuOpen);
        if (!menuOpen) return;
        // Release any Win32 cursor clip rect the game applied. Called every
        // frame so it wins the race if ARK re-applies it the same frame.
        ClipCursor(nullptr);
        // Only on the controller we blocked (and saved the cursor of) - never
        // on a new one that appeared mid-menu, which would keep it afterwards.
        APlayerController* pc = ResolvePlayerController();
        if (pc && pc == s_blockedPc) SetGameMouseCursor(pc, true);

        ImGuiIO& io = ImGui::GetIO();

        const LONG wheel = InterlockedExchange(&s_wheel, 0);
        if (wheel) io.AddMouseWheelEvent(0.0f, (float)wheel / (float)WHEEL_DELTA);

        // One position per frame, from one source: the real pointer position
        // once WM_POINTERUPDATE has delivered one, otherwise GetCursorPos.
        // Mixing both made the cursor jump between two spots.
        if (s_ptrValid)
        {
            const LONG64 pos  = InterlockedCompareExchange64(&s_ptrClient, 0, 0);
            const LONG64 size = InterlockedCompareExchange64(&s_ptrSize, 0, 0);
            const int x = (int)(int32_t)(pos & 0xFFFFFFFF), y = (int)(int32_t)(pos >> 32);
            const int w = (int)(int32_t)(size & 0xFFFFFFFF), h = (int)(int32_t)(size >> 32);
            if (w > 0 && h > 0)
                io.AddMousePosEvent(float(x) * io.DisplaySize.x / float(w), float(y) * io.DisplaySize.y / float(h));
            return;
        }

        POINT p;
        if (::GetCursorPos(&p))
        {
            // Cache the window rect — it only changes on move/resize, so
            // re-query at 4Hz instead of paying GetWindowRect every frame.
            static RECT  s_wr{};
            static ULONGLONG s_wrTick = 0;
            const ULONGLONG now = GetTickCount64();
            if (!s_wrTick || now - s_wrTick >= 250)
            {
                if (hWnd && ::GetWindowRect(hWnd, &s_wr))
                    s_wrTick = now;
                else
                    s_wr = RECT{};
            }
            const int ww = s_wr.right - s_wr.left;
            const int wh = s_wr.bottom - s_wr.top;
            if (ww > 0 && wh > 0)
            {
                const float sx = io.DisplaySize.x / float(ww);
                const float sy = io.DisplaySize.y / float(wh);
                io.AddMousePosEvent((p.x - s_wr.left) * sx, (p.y - s_wr.top) * sy);
            }
            else
            {
                io.AddMousePosEvent(float(p.x), float(p.y));
            }
        }
    }

    inline void Shutdown(HWND hWnd)
    {
        UnhookWndProc(hWnd ? hWnd : s_hookedWnd);
        SyncPlayerInputBlock(false);
        // Give the game thread (DrawHUD hook, still installed) time to hand
        // input back before the hooks go away.
        for (int i = 0; i < 50 && s_blocked; i++) Sleep(10);
        s_menuActive = false;
    }
}

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "user32.lib")

// ---------------------------------------------------------------------------
// Exported status
// ---------------------------------------------------------------------------
extern "C" __declspec(dllexport) volatile DWORD g_status = 0;

// ---------------------------------------------------------------------------
// Globals
// ---------------------------------------------------------------------------
typedef HRESULT(__stdcall* Present_t)(IDXGISwapChain*, UINT, UINT);

static Present_t               oPresent    = nullptr;

static HMODULE                 g_hModule   = nullptr;
static HWND                    g_hWnd      = nullptr;   // ARK CoreWindow
static ID3D11Device*           g_pDevice   = nullptr;
static ID3D11DeviceContext*    g_pContext  = nullptr;
static ID3D11RenderTargetView* g_pRTV      = nullptr;
static IDXGISwapChain*         g_pSwapChain = nullptr;
static bool                    g_bInit     = false;
static volatile bool           g_bMenuOpen = true;  // auto-open on inject
static UINT                    g_scWidth   = 0;
static UINT                    g_scHeight  = 0;

// Input state, produced by InputThread (attached to ARK's UI thread),
// consumed by the Present hook. mb order: L, R, M, X1, X2.
static volatile bool           g_mb[5]     = {};
static volatile bool           g_delSeen   = false; // last-known DELETE physical state (debug)
static volatile bool           g_bEject    = false; // set true to trigger full unload
static volatile LONG           g_inRender  = 0;     // >0 while a Present call is inside RenderOverlay()

// RAII guard: held for the lifetime of hkPresent's render work. EjectThread
// spins on g_inRender before tearing down D3D/ImGui, so no in-flight
// RenderOverlay() call can ever be use-after-freed out from under it.
struct RenderGuard
{
    RenderGuard()  { InterlockedIncrement(&g_inRender); }
    ~RenderGuard() { InterlockedDecrement(&g_inRender); }
};

// ---------------------------------------------------------------------------
// Local diagnostics: own file (render.log), no sharing games with the log
// the injector holds open. Heartbeat + menu toggles + render faults.
// ---------------------------------------------------------------------------
static void DllLog(const char* line)
{
    static wchar_t path[MAX_PATH] = {};
    if (!path[0])
    {
        wchar_t* appdata = nullptr;
        size_t len = 0;
        std::wstring base = (_wdupenv_s(&appdata, &len, L"LOCALAPPDATA") == 0 && appdata)
            ? appdata : L"C:\\Temp";
        free(appdata);
        std::wstring p = base + L"\\Packages\\StudioWildcard.4558480580BB9_1w2mm55455e38\\AC\\paidini\\render.log";
        wcsncpy_s(path, p.c_str(), _TRUNCATE);
    }
    HANDLE h = CreateFileW(path, FILE_APPEND_DATA,
                           FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return;
    char buf[256];
    int n = sprintf_s(buf, "%s\n", line);
    DWORD w = 0;
    WriteFile(h, buf, (DWORD)n, &w, nullptr);
    CloseHandle(h);
}

// Crash guard: swallows FError::LowLevelFatal so transient engine fatals
// (level transitions, uncooked cross-map packages) don't kill the game.
static LowLevelFatal             g_lowLevelFatal;

// Syncs the framework cfg option map → Settings::Ini bools every frame so
// IniPresets::Apply() sees the values the user set in the Past Owl GUI.
// Isolated into its own function so its C++ temporaries don't share scope
// with RenderOverlay's __try/__except blocks (MSVC C2712).
static void SyncCfgToSettings()
{
    if (auto* v = cfg->fill<checkbox_t>("Normal INI"))     Settings::Ini::Normal         = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Hard INI"))       Settings::Ini::Hard           = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("FPS+ (Potato)")) Settings::Ini::Potato         = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Fullbright"))     Settings::Ini::FullBright     = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("NO XYZ"))        Settings::Ini::NoXZ           = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("No Trees/Rocks")) Settings::Ini::NoRockTrees   = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Remove Particles")) Settings::Ini::RemoveParticles = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("No Water"))       Settings::Ini::NoWater        = v->enabled;

    if (auto* v = cfg->fill<checkbox_t>("Stalker Vision")) Settings::Ini::StalkerVision  = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Stalker Range"))    Settings::Ini::StalkerDist    = v->callback;

    if (auto* v = cfg->fill<checkbox_t>("Info HUD"))       Settings::Hud::InfoHud         = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Info HUD Scale"))   Settings::Hud::InfoHudScale    = v->callback;
    if (auto* v = cfg->fill<checkbox_t>("Rainbow Colour")) Settings::Hud::Rainbow         = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Rainbow Speed"))    Settings::Hud::RainbowSpeed    = v->callback;
    if (auto* v = cfg->fill<checkbox_t>("Watermark"))      Settings::Hud::Watermark       = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("FPS"))            Settings::Hud::ShowFPS         = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Ping"))           Settings::Hud::Ping            = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Server FPS"))     Settings::Hud::ServerFPS       = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Connected Players")) Settings::Hud::ConnectedPlayers = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Nearby Turrets")) Settings::Hud::TurretsInRange  = v->enabled;

    if (auto* v = cfg->fill<checkbox_t>("Awesome Spyglass"))     Settings::Hud::Spyglass      = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Spyglass Scale"))         Settings::Hud::SpyglassScale = v->callback;
    if (auto* v = cfg->fill<slider_t>("Spyglass X"))             Settings::Hud::SpyglassX     = v->callback;
    if (auto* v = cfg->fill<slider_t>("Spyglass Y"))             Settings::Hud::SpyglassY     = v->callback;
    if (auto* v = cfg->fill<checkbox_t>("ARK Background"))      Settings::Hud::SpyglassArkBg = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Spyglass Lock Key"))      Settings::Hud::SpyglassLockKey = (int)v->callback;

    if (auto* v = cfg->fill<checkbox_t>("Tek Rifle Indicator"))  Settings::Hud::TekIndicator = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Show With Any Weapon")) Settings::Hud::TekAnyWeapon = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Tek Range"))              Settings::Hud::TekRange     = v->callback;
    if (auto* v = cfg->fill<slider_t>("Indicator Scale"))        Settings::Hud::TekScale     = v->callback;
    if (auto* v = cfg->fill<slider_t>("Indicator X"))            Settings::Hud::TekOffsetX   = v->callback;
    if (auto* v = cfg->fill<slider_t>("Indicator Y"))            Settings::Hud::TekOffsetY   = v->callback;

    if (auto* v = cfg->fill<checkbox_t>("Custom Crosshair"))  Settings::Hud::Crosshair    = v->enabled;
    if (auto* v = cfg->fill<dropdown_t>("Crosshair Style"))   Settings::Hud::CrossStyle   = v->callback;
    if (auto* v = cfg->fill<slider_t>("Crosshair Size"))      Settings::Hud::CrossSize    = v->callback;
    if (auto* v = cfg->fill<slider_t>("Crosshair Gap"))       Settings::Hud::CrossGap     = v->callback;
    if (auto* v = cfg->fill<slider_t>("Crosshair Opacity"))   Settings::Hud::CrossOpacity = v->callback;
    if (auto* v = cfg->fill<slider_t>("Crosshair Thickness")) Settings::Hud::CrossThickness = v->callback;
    {
        auto it = cfg->texts.find("Crosshair Colour");
        float r, g, b;
        if (it != cfg->texts.end() && sscanf_s(it->second.c_str(), "%f,%f,%f", &r, &g, &b) == 3)
        {
            Settings::Hud::CrossColor[0] = r < 0.f ? 0.f : (r > 1.f ? 1.f : r);
            Settings::Hud::CrossColor[1] = g < 0.f ? 0.f : (g > 1.f ? 1.f : g);
            Settings::Hud::CrossColor[2] = b < 0.f ? 0.f : (b > 1.f ? 1.f : b);
        }
    }
    if (auto* v = cfg->fill<checkbox_t>("Show Friendly Turrets")) Settings::Hud::FriendlyTurrets = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Inventory Slots")) Settings::Hud::InventorySlots = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Server Name"))    Settings::Hud::ServerName      = v->enabled;

    if (auto* v = cfg->fill<checkbox_t>("Game Filter"))    Settings::Filter::Enabled      = v->enabled;
    {
        auto& f = Settings::Filter::Values;
        if (auto* v = cfg->fill<slider_t>("Vibrance"))    f.vibrance    = v->callback;
        if (auto* v = cfg->fill<slider_t>("Saturation"))  f.saturation  = v->callback;
        if (auto* v = cfg->fill<slider_t>("Contrast"))    f.contrast    = v->callback;
        if (auto* v = cfg->fill<slider_t>("Brightness"))  f.brightness  = v->callback;
        if (auto* v = cfg->fill<slider_t>("Gamma"))       f.gamma       = v->callback;
        if (auto* v = cfg->fill<slider_t>("Temperature")) f.temperature = v->callback;
        if (auto* v = cfg->fill<slider_t>("Sharpen"))     f.sharpen     = v->callback;
    }

    if (auto* v = cfg->fill<checkbox_t>("Quick Pickup"))   Settings::Misc::QuickPickup    = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Quick Pickup Key")) Settings::Misc::QuickPickupKey = (int)v->callback;

    if (auto* v = cfg->fill<checkbox_t>("Better Input"))   Settings::Misc::BetterInput    = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Chat Bypass"))    Settings::Misc::ChatBypass     = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Take All"))       Settings::Misc::TakeAll        = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Take All Key"))     Settings::Misc::TakeAllKey     = (int)v->callback;
    if (auto* v = cfg->fill<checkbox_t>("Turret Filler"))     Settings::Misc::TurretFiller       = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Heavy Turret Ammo"))   Settings::Misc::TurretFillHeavy    = v->callback;
    if (auto* v = cfg->fill<slider_t>("Tek Turret Ammo"))     Settings::Misc::TurretFillTek      = v->callback;
    if (auto* v = cfg->fill<checkbox_t>("Show Turret Fill"))  Settings::Misc::ShowTurretFill     = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Turret Fill Range"))   Settings::Misc::ShowTurretFillDist = v->callback;

    if (auto* v = cfg->fill<checkbox_t>("Auto Forge"))            Settings::Misc::AutoForge         = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Deposit Gas"))           Settings::Misc::AutoForgeGas      = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Deposit Metal"))         Settings::Misc::AutoForgeMetal    = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Pull Metal"))            Settings::Misc::AutoForgePull     = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Pull Metal To Dedi"))    Settings::Misc::AutoForgePullDedi = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Turn On Forges"))        Settings::Misc::AutoForgeTurnOn   = v->enabled;

    {
        using D = Settings::Dino;
        if (auto* v = cfg->fill<checkbox_t>("Auto Saddle"))        D::AutoSaddle        = v->enabled;
        if (auto* v = cfg->fill<slider_t>("Saddle Range"))         D::AutoSaddleReach   = v->callback;
        if (auto* v = cfg->fill<checkbox_t>("Auto Imprint"))       D::AutoImprint       = v->enabled;
        if (auto* v = cfg->fill<checkbox_t>("Auto Name"))          D::AutoNameDino      = v->enabled;
        if (auto* v = cfg->fill<slider_t>("Name Range"))           D::AutoNameRange     = v->callback;
        if (auto* v = cfg->fill<checkbox_t>("Rename Named Dinos")) D::AutoNameOverwrite = v->enabled;
        {
            auto it = cfg->texts.find("Auto Name Text");
            if (it != cfg->texts.end() && strcmp(D::AutoNameText, it->second.c_str()) != 0)
                strncpy_s(D::AutoNameText, it->second.c_str(), _TRUNCATE);
        }
        if (auto* v = cfg->fill<checkbox_t>("Auto Claim"))         D::AutoClaim         = v->enabled;
        if (auto* v = cfg->fill<checkbox_t>("Auto Neuter"))        D::AutoNeuter        = v->enabled;
        if (auto* v = cfg->fill<slider_t>("Neuter Range"))         D::AutoNeuterRange   = v->callback;
        if (auto* v = cfg->fill<checkbox_t>("Auto Level"))         D::AutoLevel         = v->enabled;
        static const char* kPoints[8] = { "Health Points", "Stamina Points", "Oxygen Points", "Food Points",
                                          "Weight Points", "Melee Points", "Speed Points", "Crafting Points" };
        for (int i = 0; i < 8; i++)
            if (auto* v = cfg->fill<slider_t>(kPoints[i])) D::AutoLevelPoints[i] = (int)(v->callback + 0.5f);
        if (auto* v = cfg->fill<checkbox_t>("Auto Clone"))         D::AutoClone         = v->enabled;
        if (auto* v = cfg->fill<slider_t>("Clone Range"))          D::AutoCloneRange    = v->callback;
        if (auto* v = cfg->fill<checkbox_t>("Auto Fill Cloning Chamber")) D::AutoFillCloning = v->enabled;
        if (auto* v = cfg->fill<checkbox_t>("Auto Pickup Eggs"))   D::AutoPickupEggs    = v->enabled;
        if (auto* v = cfg->fill<checkbox_t>("Auto Transfer Eggs")) D::TransferEggsIncubator = v->enabled;
        if (auto* v = cfg->fill<checkbox_t>("Auto Hatch Eggs"))    D::HatchIncubatorEggs = v->enabled;
        var->dino.hatch_learned = Breeding::HatchLearned();
    }
    if (auto* v = cfg->fill<checkbox_t>("Structure Snapping")) Settings::Misc::StructureSnapping = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Snap Spacing"))
    {
        // Two-way: the arrow keys change the setting in game, the slider in the menu.
        static float s_last = v->callback;
        if (Settings::Misc::SnapSpacing != s_last) v->callback = Settings::Misc::SnapSpacing;
        else                                       Settings::Misc::SnapSpacing = v->callback;
        s_last = Settings::Misc::SnapSpacing;
    }

    if (auto* v = cfg->fill<checkbox_t>("Custom FOV"))     Settings::Ini::CustomFOV      = v->enabled;
    if (auto* v = cfg->fill<slider_t>("FOV Value"))        Settings::Ini::FOVValue       = v->callback;

    if (auto* v = cfg->fill<checkbox_t>("Draw Armor"))      Settings::Ini::DrawArmor           = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Show Durability")) Settings::Ini::DrawArmorDurability = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Show Count"))      Settings::Ini::DrawArmorCount      = v->enabled;
    if (auto* v = cfg->fill<checkbox_t>("Show Percent"))    Settings::Ini::DrawArmorPercent    = v->enabled;
    if (auto* v = cfg->fill<slider_t>("Armor HUD Scale"))   Settings::Ini::ArmorHudScale       = v->callback;
    if (auto* v = cfg->fill<slider_t>("Armor HUD Y Offset")) Settings::Ini::ArmorHudYOffset    = v->callback;
    if (auto* v = cfg->fill<slider_t>("Armor Text Scale"))   Settings::Ini::ArmorTextScale     = v->callback;
    if (auto* v = cfg->fill<slider_t>("Armor Text X"))       Settings::Ini::ArmorTextOffsetX   = v->callback;
    if (auto* v = cfg->fill<slider_t>("Armor Text Y"))       Settings::Ini::ArmorTextOffsetY   = v->callback;
}

// Per-frame game-memory features, run on the GAME thread (DrawHUD hook) so
// the engine never reads viewport/camera fields mid-write. Each is
// SEH-guarded so a stale pointer (respawn, map transfer, loading screen)
// skips a frame instead of crashing.
static void RunGameFeatures()
{
    __try { IniPresets::Apply(); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
    __try { CustomFov::Apply(); }
    __except (EXCEPTION_EXECUTE_HANDLER) { CustomFov::s_active = false; CustomFov::s_cam = nullptr; }
    static bool s_stalkerFaultLogged = false;
    __try { StalkerVision::Tick(); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        StalkerVision::s_mid = nullptr;
        StalkerVision::s_volume = nullptr;
        if (!s_stalkerFaultLogged)
        {
            s_stalkerFaultLogged = true;
            Logger::Log("[StalkerVision] exception 0x%08X in Tick", GetExceptionCode());
        }
    }
}

// Eject: take the material out of the volume and restore the camera flag,
// on the game thread (called from the DrawHUD hook while ejecting).
static void StalkerDisableSafe()
{
    __try { StalkerVision::Disable(); }
    __except (EXCEPTION_EXECUTE_HANDLER) { StalkerVision::s_volume = nullptr; StalkerVision::s_camOrig = 0xFF; }
}

static void ReleaseGameFeatures()
{
    __try { CustomFov::Release(); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
}

// ---------------------------------------------------------------------------
// AShooterHUD::DrawHUD hook (game thread) - engine-canvas drawing (armor HUD).
// g_inDrawHud lets EjectThread wait out an in-flight call before unloading.
// ---------------------------------------------------------------------------
typedef void(__fastcall* DrawHUD_t)(AHUD*);
static DrawHUD_t     oDrawHUD    = nullptr;
static void*         pDrawHUD    = nullptr;
static volatile LONG g_inDrawHud = 0;

static void ApplyInputBlockSafe()
{
    static bool s_faultLogged = false;
    __try { CursorFix::ApplyInputBlock(); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged)
        {
            s_faultLogged = true;
            Logger::Log("[InputBlock] exception 0x%08X", GetExceptionCode());
        }
    }
}

static void QuickPickupSafe(AHUD* hud, bool restore)
{
    static bool s_faultLogged = false;
    __try
    {
        if (restore)
            QuickPickup::Restore();
        else
        {
            ULocalPlayer* lp = ULocalPlayer::Get();
            QuickPickup::Tick(reinterpret_cast<UObject*>(hud), lp ? lp->PlayerController : nullptr, g_bMenuOpen);
        }
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (restore) QuickPickup::g_Orig = -1.f;
        if (!s_faultLogged)
        {
            s_faultLogged = true;
            Logger::Log("[QuickPickup] exception 0x%08X", GetExceptionCode());
        }
    }
}

// ---------------------------------------------------------------------------
// UObject::ProcessEvent hook (game thread) - Structure Snap moves the placement
// ghost after BPIsAllowedToBuild and rewrites ServerRequestPlaceStructure
// before it is sent. g_inProcessEvent lets EjectThread wait out calls in flight.
// ---------------------------------------------------------------------------
static volatile LONG g_inProcessEvent = 0;

// Forward declarations (defined after RenderOverlay section).

static void SnapPreSafe(void* obj, UFunction* fn, void* parms)
{
    static bool s_faultLogged = false;
    __try { StructureSnap::OnPreEvent(obj, fn, parms); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[StructureSnap] exception 0x%08X in pre-event", GetExceptionCode()); }
    }
}

static void SnapPostSafe(void* obj, UFunction* fn, void* parms)
{
    static bool s_faultLogged = false;
    __try { StructureSnap::OnPostEvent(obj, fn, parms); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        StructureSnap::g_snap.valid = false;
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[StructureSnap] exception 0x%08X in post-event", GetExceptionCode()); }
    }
}

// Breeding: learns a hand clone / hatch, and drops the "Name your dino" box
// after an Auto Claim (returns true to skip the original).
static bool BreedingPreSafe(void* obj, UFunction* fn, void* parms)
{
    static bool s_faultLogged = false;
    __try { return Breeding::OnPreEvent(obj, fn, parms); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[Breeding] exception 0x%08X in pre-event", GetExceptionCode()); }
        return false;
    }
}

static void TakeAllPreSafe(UFunction* fn, void* parms)
{
    __try { TakeAll::OnPreEvent(fn, parms); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
}

static void TakeAllTickSafe(AHUD* hud)
{
    static bool s_faultLogged = false;
    __try { TakeAll::Tick(hud, g_bMenuOpen); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        TakeAll::g_pending = nullptr;
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[TakeAll] exception 0x%08X", GetExceptionCode()); }
    }
}

static void SmeltTickSafe(AHUD* hud)
{
    static bool s_faultLogged = false;
    __try
    {
        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        AActor* me = ULocalPlayer::GetActor();
        if (pc && me) AutoForge::Tick(pc, me);
        else if (!Settings::Misc::AutoForge) AutoForge::Reset();
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[AutoForge] exception 0x%08X", GetExceptionCode()); }
    }
}

// ARK crash guard (Modules/Engine/CrashGuard.h). UI functions - anything on a
// UMG widget class - run under SEH: ARK's own stale-widget bugs (an entry
// whose item just moved, a list entry no longer in the window: crash dumps of
// 28/30 Sep and 1/3 Oct) drop that one UI action instead of the game.
__declspec(noinline) static void GuardedProcessEvent(void* obj, UFunction* fn, void* parms)
{
    __try { UObject::oProcessEvent(obj, fn, parms); }
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH)
    {
        if (InterlockedIncrement(&CrashGuard::g_caught) <= 10)
            Logger::Log("[CrashGuard] ARK faulted in UI %s.%s - that action was dropped, game kept running",
                        CrashGuard::NameOf(reinterpret_cast<UObject*>(fn)->Outer), CrashGuard::NameOf(fn));
    }
}

// The original, with the UI guard and the crash log's "what was running".
static void CallOriginalProcessEvent(void* obj, UFunction* fn, void* parms)
{
    const DWORD tid = GetCurrentThreadId();
    const void* prevFn = CrashGuard::g_peFn;
    const void* prevObj = CrashGuard::g_peObj;
    const DWORD prevTid = CrashGuard::g_peThread;
    CrashGuard::g_peThread = tid; CrashGuard::g_peFn = fn; CrashGuard::g_peObj = obj;
    if (!g_bEject && CrashGuard::IsUiFunction(fn)) GuardedProcessEvent(obj, fn, parms);
    else UObject::oProcessEvent(obj, fn, parms);
    if (prevTid == tid) { CrashGuard::g_peFn = prevFn; CrashGuard::g_peObj = prevObj; }
}

static void hkProcessEvent(void* obj, UFunction* fn, void* parms)
{
    InterlockedIncrement(&g_inProcessEvent);
    if (!g_bEject && Settings::Misc::TakeAll) TakeAllPreSafe(fn, parms);
    const bool snap  = !g_bEject && Settings::Misc::StructureSnapping;
    const bool breed = !g_bEject && Breeding::WantsEvents();
    if (breed && BreedingPreSafe(obj, fn, parms))
    {
        InterlockedDecrement(&g_inProcessEvent);
        return;
    }
    if (snap) SnapPreSafe(obj, fn, parms);
    CallOriginalProcessEvent(obj, fn, parms);
    if (snap) SnapPostSafe(obj, fn, parms);
    InterlockedDecrement(&g_inProcessEvent);
}

static void SnapTickSafe(AHUD* hud)
{
    static bool s_faultLogged = false;
    __try { StructureSnap::Tick(hud, g_bMenuOpen); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        StructureSnap::g_ghost = nullptr;
        StructureSnap::g_snap.valid = false;
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[StructureSnap] exception 0x%08X in Tick", GetExceptionCode()); }
    }
}

// Eject: give the placement ghost its meshes back (game thread).
static void SnapReleaseSafe()
{
    __try { StructureSnap::Release(); }
    __except (EXCEPTION_EXECUTE_HANDLER) { StructureSnap::g_offsetOn = false; }
}

static void BetterInputSafe(bool reset)
{
    static bool s_faultLogged = false;
    __try
    {
        if (reset) BetterInput::Reset();
        else
        {
            ULocalPlayer* lp = ULocalPlayer::Get();
            APlayerController* pc = lp ? lp->PlayerController : nullptr;
            BetterInput::Tick(pc ? reinterpret_cast<AActor*>(pc->AcknowledgedPawn) : nullptr, g_bMenuOpen);
        }
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        BetterInput::dropState = {}; BetterInput::transferState = {}; BetterInput::useState = {};
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[BetterInput] exception 0x%08X", GetExceptionCode()); }
    }
}

// Breeding tick: the player's own character (not the dino when riding), and
// its TargetingTeam as the tribe.
static void BreedingFlushSafe()
{
    __try { Breeding::Flush(); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
}

static void ForgeEjectSafe()
{
    __try { AutoForge::Reset(); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
}

static void BreedingTickSafe()
{
    static bool s_faultLogged = false;
    __try
    {
        ULocalPlayer* lp = ULocalPlayer::Get();
        APlayerController* pc = lp ? lp->PlayerController : nullptr;
        if (!pc) return;
        AActor* me = reinterpret_cast<AActor*>(pc->AcknowledgedPawn);
        if (!ArmorHud::Valid(me) || !ArmorHud::IsShooterCharacter(me))
            me = pc->LastControlledPlayerCharacter.Get();
        if (!ArmorHud::Valid(me)) return;
        const int32_t tribe = *reinterpret_cast<int32_t*>(reinterpret_cast<uintptr_t>(me) + 0x230);   // TargetingTeam
        Breeding::Tick(pc, me, tribe);
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[Breeding] exception 0x%08X in Tick", GetExceptionCode()); }
    }
}

static void DrawHudFeatures(AHUD* hud)
{
    SnapTickSafe(hud);
    BetterInputSafe(false);
    TakeAllTickSafe(hud);
    SmeltTickSafe(hud);
    BreedingTickSafe();

    static bool s_faultLogged = false;
    __try { ArmorHud::DrawOnHud(hud); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged)
        {
            s_faultLogged = true;
            Logger::Log("[ArmorHud] exception 0x%08X in DrawOnHud", GetExceptionCode());
        }
    }

    static bool s_infoFaultLogged = false;
    __try { InfoHud::Tick(); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_infoFaultLogged)
        {
            s_infoFaultLogged = true;
            Logger::Log("[InfoHud] exception 0x%08X in Tick", GetExceptionCode());
        }
    }
}

static void CrosshairHideSafe(AHUD* hud, bool begin)
{
    __try { if (begin) Crosshair::HideBegin(hud); else Crosshair::HideEnd(hud); }
    __except (EXCEPTION_EXECUTE_HANDLER) { Crosshair::g_hidden = false; }
}

static void CrosshairDrawSafe(AHUD* hud)
{
    static bool s_faultLogged = false;
    __try { Crosshair::Draw(hud, g_bMenuOpen); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[Crosshair] exception 0x%08X in Draw", GetExceptionCode()); }
    }
}

// Tek Rifle indicator: the game thread finds the target and fills a snapshot;
// the overlay draws it in the menu's style (see DrawTekPanelSafe).
static void TekIndicatorSafe(AHUD* hud)
{
    static bool s_faultLogged = false;
    __try { TekIndicator::Tick(hud, g_bMenuOpen); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        TekIndicator::g_lastTarget = nullptr;
        TekIndicator::g_snap.valid = false;
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[TekIndicator] exception 0x%08X", GetExceptionCode()); }
    }
}

static void SpyglassTickSafe(AHUD* hud)
{
    static bool s_faultLogged = false;
    __try { AwesomeSpyglass::Tick(hud, g_bMenuOpen); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        AwesomeSpyglass::Reset();
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[Spyglass] exception 0x%08X in Tick", GetExceptionCode()); }
    }
}

static void TurretFillerTickSafe()
{
    static bool s_faultLogged = false;
    __try { TurretFiller::Tick(g_bMenuOpen); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        TurretFiller::g_turrets.clear();
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[TurretFiller] exception 0x%08X in Tick", GetExceptionCode()); }
    }
}

static void TurretFillerDrawSafe(AHUD* hud)
{
    static bool s_faultLogged = false;
    __try { TurretFiller::Draw(hud); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[TurretFiller] exception 0x%08X in Draw", GetExceptionCode()); }
    }
}

static void __fastcall hkDrawHUD(AHUD* hud)
{
    InterlockedIncrement(&g_inDrawHud);
    ApplyInputBlockSafe();   // also runs during eject to hand input back
    if (!g_bEject)
    {
        RunGameFeatures();
        QuickPickupSafe(hud, false);
        DrawHudFeatures(hud);
    }
    else
    {
        StalkerDisableSafe();
        QuickPickupSafe(hud, true);
        SnapReleaseSafe();
        ForgeEjectSafe();
        BetterInputSafe(true);
        BreedingFlushSafe();
    }
    // Custom crosshair: ARK's own crosshair is blanked while ARK draws its
    // HUD, then ours is drawn on top through ARK's crosshair path.
    const bool cross = !g_bEject && Settings::Hud::Crosshair;
    if (cross) CrosshairHideSafe(hud, true);
    oDrawHUD(hud);
    if (cross)
    {
        CrosshairHideSafe(hud, false);
        CrosshairDrawSafe(hud);
    }
    if (!g_bEject) TekIndicatorSafe(hud);   // fills the panel snapshot (clears it when off)
    if (!g_bEject) SpyglassTickSafe(hud);   // same, for the spyglass panel
    if (!g_bEject) { TurretFillerTickSafe(); TurretFillerDrawSafe(hud); }
    InterlockedDecrement(&g_inDrawHud);
}

// forward declaration — defined after RenderOverlay
static DWORD WINAPI EjectThread(LPVOID);
static void DropInstance();   // defined near DllMain, called from EjectThread

// ---------------------------------------------------------------------------
// Find the ARK CoreWindow (UWP / Microsoft Store build)
// ---------------------------------------------------------------------------
static HWND FindArkWindow()
{
    HWND frame = FindWindowA("ApplicationFrameWindow", "ARK: Survival Evolved");
    if (frame)
    {
        HWND core = FindWindowExA(frame, nullptr, "Windows.UI.Core.CoreWindow",
                                  "ARK: Survival Evolved");
        if (core) return core;
    }
    // Fallback: any top-level CoreWindow belonging to our process.
    HWND h = nullptr;
    do {
        h = FindWindowExA(nullptr, h, "Windows.UI.Core.CoreWindow", nullptr);
        if (h)
        {
            DWORD pid = 0;
            GetWindowThreadProcessId(h, &pid);
            if (pid == GetCurrentProcessId()) return h;
        }
    } while (h);
    return nullptr;
}

// ---------------------------------------------------------------------------
// Input thread — the ONE place we read keyboard/mouse. Attaches to ARK's UI
// thread so GetAsyncKeyState returns valid data inside the AppContainer.
// ---------------------------------------------------------------------------
static DWORD WINAPI InputThread(LPVOID)
{
    // Wait for the CoreWindow to exist.
    HWND wnd = nullptr;
    for (int i = 0; i < 1200 && !wnd; i++) { wnd = FindArkWindow(); if (!wnd) Sleep(100); }
    if (!wnd) return 0;

    g_hWnd = wnd;

    const DWORD myTid   = GetCurrentThreadId();
    const DWORD gameTid = GetWindowThreadProcessId(wnd, nullptr);
    if (gameTid && gameTid != myTid)
        AttachThreadInput(myTid, gameTid, TRUE);

    static const int kMouseVk[5] = { VK_LBUTTON, VK_RBUTTON, VK_MBUTTON, VK_XBUTTON1, VK_XBUTTON2 };

    bool wasDel = false;
    for (;;)
    {
        // Re-find the window if it went away (resolution / fullscreen swaps).
        if (!IsWindow(g_hWnd))
        {
            HWND w2 = FindArkWindow();
            if (w2 && w2 != g_hWnd)
            {
                g_hWnd = w2;
                const DWORD t2 = GetWindowThreadProcessId(w2, nullptr);
                if (t2 && t2 != myTid) AttachThreadInput(myTid, t2, TRUE);
            }
        }

        if (g_bEject) break;

        for (int i = 0; i < 5; i++)
            g_mb[i] = (GetAsyncKeyState(kMouseVk[i]) & 0x8000) != 0;

        const bool delNow = (GetAsyncKeyState(VK_DELETE) & 0x8000) != 0;
        g_delSeen = delNow;
        if (delNow && !wasDel)
        {
            g_bMenuOpen = !g_bMenuOpen;
            DllLog(g_bMenuOpen ? "menu opened" : "menu closed");
            CursorFix::OnMenuToggled(g_hWnd, g_bMenuOpen);
        }
        wasDel = delNow;

        // Keyboard/char poll — must run here (AttachThreadInput thread).
        // Present thread reads 0 for all keys in UWP. Feeds text fields.
        InputBridge::Poll(g_bMenuOpen);

        Sleep(8);
    }
    return 0;
}

// ---------------------------------------------------------------------------
// Init on first Present call
// ---------------------------------------------------------------------------
static bool InitFromSwapChain(IDXGISwapChain* pSwapChain)
{
    if (FAILED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&g_pDevice)))
        return false;
    g_status = 101;

    g_pDevice->GetImmediateContext(&g_pContext);

    DXGI_SWAP_CHAIN_DESC sd = {};
    pSwapChain->GetDesc(&sd);
    g_scWidth  = sd.BufferDesc.Width;
    g_scHeight = sd.BufferDesc.Height;

    // Prefer the CoreWindow found by InputThread; fall back to a fresh find.
    if (!g_hWnd || !IsWindow(g_hWnd)) g_hWnd = FindArkWindow();
    if (!g_hWnd) g_hWnd = sd.OutputWindow;   // last resort (classic-window builds)
    g_status = 102;

    ID3D11Texture2D* pBB = nullptr;
    if (SUCCEEDED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&pBB)) && pBB)
    {
        g_status = 103;
        g_pDevice->CreateRenderTargetView(pBB, nullptr, &g_pRTV);
        pBB->Release();
    }
    if (!g_pRTV) return false;
    g_status = 104;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename  = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
    ImGui::StyleColorsDark();
    ImGui_ImplWin32_Init(g_hWnd);
    ImGui_ImplDX11_Init(g_pDevice, g_pContext);
    g_status = 106;

    // Past Owl framework wiring: hand it the game device, build its fonts,
    // upload its embedded artwork (no external files inside the game)
    g_pSwapChain = pSwapChain;
    var->dx.device = g_pDevice;
    var->dx.ctx = g_pContext;
    var->dx.swap_chain = pSwapChain;
    font->update();
    load_embedded_images();

    // Menu auto-opens on inject (g_bMenuOpen starts true) — apply the same
    // edge the DELETE toggle would, so the WndProc subclass is installed
    // from the very first frame instead of only after the first toggle.
    if (g_bMenuOpen) CursorFix::OnMenuToggled(g_hWnd, true);

    return true;
}

// ---------------------------------------------------------------------------
// Menu cursor fix: UWP CoreWindow only sends WM_POINTER*, never
// WM_LBUTTONDOWN, and this backend ignores POINTER. So WndProc alone gives
// zero clicks. Buttons MUST come from InputThread poll (g_mb, attached to
// ARK's UI thread). Pos comes from CursorFix::PerFrame. This is the sole
// button source, not a double-feed.
// ---------------------------------------------------------------------------
// Every key transition is fed to ImGui (Keybinds::VkToImGuiKey) so the keybind
// popup can capture any key. Printable characters arrive separately as
// ToUnicodeEx characters (layout / shift / caps correct).
static void UpdateImGuiInput()
{
    ImGuiIO& io = ImGui::GetIO();
    for (int i = 0; i < 5; i++)
        io.AddMouseButtonEvent(i, g_mb[i]);

    // KEYBOARD — this is why nothing could be typed. InputBridge::Poll
    // produces g_keys/g_chars on the input thread; drain them here.
    std::lock_guard<std::mutex> lk(InputBridge::g_mtx);

    io.AddKeyEvent(ImGuiMod_Ctrl,  InputBridge::g_ctrl);
    io.AddKeyEvent(ImGuiMod_Shift, InputBridge::g_shift);
    io.AddKeyEvent(ImGuiMod_Alt,   InputBridge::g_alt);

    for (const auto& e : InputBridge::g_keys)
    {
        const ImGuiKey k = Keybinds::VkToImGuiKey(e.vk);
        if (k != ImGuiKey_None) io.AddKeyEvent(k, e.down);
    }
    InputBridge::g_keys.clear();

    for (unsigned int c : InputBridge::g_chars)
        io.AddInputCharacter(c);
    InputBridge::g_chars.clear();
}

static bool g_firstFrameDone = false; // first full overlay frame (options registered)

// Menu closed and no toasts: nothing to draw. The per-frame logic still runs,
// but the ImGui frame, back-buffer view, draw submit and D3D state
// save/restore are skipped. Input is not queued either, so no backlog of
// mouse events builds up while idle.
static bool OverlayIdle()
{
    return !g_bMenuOpen && g_firstFrameDone && !Notifications::Any() && !Settings::Hud::InfoHud &&
           !TekIndicator::Active();
}

static void IdleFrame()
{
    CursorFix::PerFrame(g_hWnd, false);
    Keybinds::Evaluate(false);
    SyncCfgToSettings();
}

static void DrawInfoHudSafe()
{
    static bool s_faultLogged = false;
    __try { InfoHud::Draw(font->hud_font); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged)
        {
            s_faultLogged = true;
            Logger::Log("[InfoHud] exception 0x%08X in Draw", GetExceptionCode());
        }
    }
}

// The Tek Rifle panel, drawn like the menu: its fonts and theme colours.
static void DrawTekPanel()
{
    auto u32 = [](const c_col& c, float a = 1.f) {
        return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w * a));
    };
    TekIndicator::Palette p;
    p.panel  = u32(clr->child, 0.96f);
    p.border = u32(clr->border);
    p.track  = u32(clr->widget);
    p.text   = u32(clr->text);
    p.white  = u32(clr->white);
    p.green  = IM_COL32(92, 214, 140, 255);
    p.red    = u32(clr->red);
    TekIndicator::Render(ImGui::GetBackgroundDrawList(), font->get(sf_pro, 12), font->get(sf_pro, 11), p);
}

static void DrawTekPanelSafe()
{
    static bool s_faultLogged = false;
    __try { DrawTekPanel(); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        if (!s_faultLogged) { s_faultLogged = true; Logger::Log("[TekIndicator] exception 0x%08X in Render", GetExceptionCode()); }
    }
}

static void RenderOverlay()
{
    static int s_frame = 0;
    static int s_renderFails = 0;
    s_frame++;

    // NOTE: no per-frame file logging here. The old RLOG() did 10+
    // CreateFile/WriteFile/Close per frame on the render thread — that
    // file I/O blocked Present and made the whole menu feel framy.
    // Crashes below still bump s_renderFails and get logged once.

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();

    ImGuiIO& io = ImGui::GetIO();

    // A long frame (game pause menu, alt-tab, or the first frame after the
    // idle overlay skipped ImGui) must not reach ImGui as one huge step: it
    // drags io.Framerate down and destabilises the menu's animations.
    if (!(io.DeltaTime > 0.f)) io.DeltaTime = 1.f / 60.f;
    if (io.DeltaTime > 1.f / 20.f) io.DeltaTime = 1.f / 20.f;

    if (g_scWidth > 0 && g_scHeight > 0)
    {
        const ImVec2 want{ float(g_scWidth), float(g_scHeight) };
        if (io.DisplaySize.x != want.x || io.DisplaySize.y != want.y)
            io.DisplaySize = want;
    }

    // World change (disconnect, server transfer, loading into a map): the
    // controller the menu blocked is being torn down. Close the menu cleanly -
    // WndProc unhooked, cursor hooks off - and forget the old block so nothing
    // is "undone" on the main menu's controller (that hid the mouse).
    {
        static UWorld* s_world = nullptr;
        UWorld* w = UWorld::Get();
        if (w != s_world)
        {
            const bool first = s_world == nullptr;
            s_world = w;
            if (!first)
            {
                CursorFix::DropStaleBlock();
                if (g_bMenuOpen)
                {
                    g_bMenuOpen = false;
                    CursorFix::OnMenuToggled(g_hWnd, false);
                    DllLog("menu closed: world changed (disconnect / transfer / load)");
                }
            }
        }
    }

    io.MouseDrawCursor = g_bMenuOpen;

    UpdateImGuiInput();
    CursorFix::PerFrame(g_hWnd, g_bMenuOpen);
    Keybinds::Evaluate(g_bMenuOpen);
    SyncCfgToSettings();

    ImGui::NewFrame();

    DrawInfoHudSafe();
    DrawTekPanelSafe();
    Notifications::Draw();
    {   // Auto Forge status lines (top-center), SEH-guarded like the rest.
        static bool s_forgeFaultLogged = false;
        __try { AutoForge::Render(ImGui::GetBackgroundDrawList(), font->get(sf_pro, 12), g_bMenuOpen); }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            if (!s_forgeFaultLogged) { s_forgeFaultLogged = true; Logger::Log("[AutoForge] exception 0x%08X in Render", GetExceptionCode()); }
        }
    }

    if (g_bMenuOpen && s_renderFails <= 5)
    {
        __try { gui->render(); }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            s_renderFails++;
            char b[80];
            sprintf_s(b, "CRASH in gui->render() 0x%08X frame %d", GetExceptionCode(), s_frame);
            DllLog(b);
        }

        if (var->gui.eject_requested)
        {
            var->gui.eject_requested = false;
            g_bEject = true;
            HANDLE h = CreateThread(nullptr, 0, EjectThread, nullptr, 0, nullptr);
            if (h) CloseHandle(h);
        }
    }

    // Settings start at their defaults every inject; they only change when the
    // user loads a config. (The first full frame registers all options via
    // gui->initialize(); only after that may the overlay go idle.)
    g_firstFrameDone = true;

    ImGui::Render();

    // --- Save ARK's full render state before we touch anything ---
    ID3D11RenderTargetView* old_rtv     = nullptr;
    ID3D11DepthStencilView* old_dsv     = nullptr;
    UINT                    old_vp_count = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
    D3D11_VIEWPORT          old_vp[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE] = {};
    ID3D11RasterizerState*  old_rs      = nullptr;

    g_pContext->OMGetRenderTargets(1, &old_rtv, &old_dsv);
    g_pContext->RSGetViewports(&old_vp_count, old_vp);
    g_pContext->RSGetState(&old_rs);

    // --- Set our overlay RTV + a clean standard viewport ---
    g_pContext->OMSetRenderTargets(1, &g_pRTV, nullptr);
    {
        D3D11_VIEWPORT vp = {};
        vp.Width    = (float)g_scWidth;
        vp.Height   = (float)g_scHeight;
        vp.MinDepth = 0.0f;
        vp.MaxDepth = 1.0f;
        vp.TopLeftX = 0.0f;
        vp.TopLeftY = 0.0f;
        g_pContext->RSSetViewports(1, &vp);
    }

    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

    // --- Restore ARK's render state exactly as we found it ---
    g_pContext->OMSetRenderTargets(1, &old_rtv, old_dsv);
    g_pContext->RSSetViewports(old_vp_count, old_vp);
    g_pContext->RSSetState(old_rs);
    if (old_rtv) old_rtv->Release();
    if (old_dsv) old_dsv->Release();
    if (old_rs)  old_rs->Release();

    // font->update() MUST run AFTER RenderDrawData, never before ImGui::Render.
    // When dpi_changed is true it calls ImGui_ImplDX11_CreateDeviceObjects() which
    // invalidates the font SRV — safe here (frame is fully submitted to the GPU),
    // fatal mid-frame (causes the menu-vanish on scale change).
    // Re-bake the Info HUD face when its scale settles on a new pixel size
    // (not mid-drag: ImGui scales the old bake until the mouse is released).
    {
        const float want = InfoHud::FontPx();
        font->hud_font_want = want;
        if (g_bMenuOpen && want != font->hud_font_px && !g_mb[0])
            var->gui.dpi_changed = true;
    }

    if (g_bMenuOpen && s_renderFails <= 5)
    {
        __try { font->update(); }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            s_renderFails++;
            char b[80];
            sprintf_s(b, "CRASH in font->update() 0x%08X frame %d", GetExceptionCode(), s_frame);
            DllLog(b);
        }
    }

}

static void ApplyFilterSafe(IDXGISwapChain* sc)
{
    static bool s_faultLogged = false;
    __try { ColorFilter::Apply(g_pDevice, g_pContext, sc, g_pRTV); }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        ColorFilter::g_failed = true; // stop trying this session
        if (!s_faultLogged)
        {
            s_faultLogged = true;
            Logger::Log("[ColorFilter] exception 0x%08X - filter disabled", GetExceptionCode());
        }
    }
}

// ---------------------------------------------------------------------------
// Present hook
// ---------------------------------------------------------------------------
static HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
    if (g_status < 100) g_status = 100;

    // Eject requested — stop touching D3D/ImGui state entirely. EjectThread
    // waits out any render already past this check via g_inRender before it
    // tears anything down, so once we're past this line it's safe.
    if (g_bEject)
        return oPresent(pSwapChain, SyncInterval, Flags);

    RenderGuard renderGuard;

    if (!g_bInit)
    {
        if (InitFromSwapChain(pSwapChain))
            g_bInit = true;
        else
            return oPresent(pSwapChain, SyncInterval, Flags);
    }

    // Keep dimensions up to date — only touch the cached values (and the
    // ImGui DisplaySize derived from them) when something actually changed.
    {
        DXGI_SWAP_CHAIN_DESC sd = {};
        if (SUCCEEDED(pSwapChain->GetDesc(&sd)) && sd.BufferDesc.Width > 0 &&
            (sd.BufferDesc.Width != g_scWidth || sd.BufferDesc.Height != g_scHeight))
        { g_scWidth = sd.BufferDesc.Width; g_scHeight = sd.BufferDesc.Height; }
    }

    // Menu closed + no toasts + no game filter: nothing to draw at all.
    const bool idle = OverlayIdle();
    if (idle && !ColorFilter::Active())
    {
        IdleFrame();
        return oPresent(pSwapChain, SyncInterval, Flags);
    }

    // Flip swap chain: back buffer rotates each Present — recreate RTV every frame
    if (g_pRTV) { g_pRTV->Release(); g_pRTV = nullptr; }

    ID3D11Texture2D* pBB = nullptr;
    if (SUCCEEDED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&pBB)) && pBB)
    {
        g_pDevice->CreateRenderTargetView(pBB, nullptr, &g_pRTV);
        pBB->Release();
    }

    if (g_pRTV)
    {
        g_status = 200;
        // Game filter first (on the game image only), then the menu on top.
        ApplyFilterSafe(pSwapChain);
        if (idle) IdleFrame();
        else      RenderOverlay();
        // Drop the back-buffer reference before the game can call
        // ResizeBuffers (alt-tab / fullscreen / resolution change), which
        // fails while any view of the back buffer is still alive.
        g_pRTV->Release();
        g_pRTV = nullptr;
    }

    return oPresent(pSwapChain, SyncInterval, Flags);
}

// ---------------------------------------------------------------------------
// Grab Present ptr from throwaway swapchain vtable
// ---------------------------------------------------------------------------
static void* GetSwapChainPresentPtr()
{
    WNDCLASSEXA wc = { sizeof(wc) };
    wc.lpfnWndProc   = DefWindowProcA;
    wc.hInstance     = GetModuleHandleA(nullptr);
    wc.lpszClassName = "nab_d";
    RegisterClassExA(&wc);

    g_status = 3;
    HWND hDummy = CreateWindowExA(0, "nab_d", "d", WS_OVERLAPPEDWINDOW,
        0, 0, 8, 8, nullptr, nullptr, wc.hInstance, nullptr);
    if (!hDummy) { UnregisterClassA(wc.lpszClassName, wc.hInstance); return nullptr; }

    DXGI_SWAP_CHAIN_DESC scd = {};
    scd.BufferCount       = 1;
    scd.BufferDesc.Width  = 8; scd.BufferDesc.Height = 8;
    scd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    scd.BufferUsage       = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    scd.OutputWindow      = hDummy;
    scd.SampleDesc.Count  = 1;
    scd.Windowed          = TRUE;
    scd.SwapEffect        = DXGI_SWAP_EFFECT_DISCARD;

    const D3D_FEATURE_LEVEL lvls[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
    D3D_FEATURE_LEVEL        got;
    IDXGISwapChain*      pSwap = nullptr;
    ID3D11Device*        pDev  = nullptr;
    ID3D11DeviceContext* pCtx  = nullptr;

    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
        lvls, ARRAYSIZE(lvls), D3D11_SDK_VERSION, &scd, &pSwap, &pDev, &got, &pCtx);

    void* pPresent = nullptr;
    if (SUCCEEDED(hr) && pSwap)
    {
        g_status = 4;
        pPresent = (*reinterpret_cast<void***>(pSwap))[8];
    }

    if (pSwap) pSwap->Release();
    if (pDev)  pDev->Release();
    if (pCtx)  pCtx->Release();
    DestroyWindow(hDummy);
    UnregisterClassA(wc.lpszClassName, wc.hInstance);
    return pPresent;
}

// ---------------------------------------------------------------------------
// Eject thread — full cleanup and FreeLibrary. Must NOT run on the Present
// hook thread (deadlocks). Spawned by the Eject button click.
// ---------------------------------------------------------------------------
static DWORD WINAPI EjectThread(LPVOID)
{
    // g_bEject is already true (set by the button handler before this thread
    // was created), so hkPresent will not START any new RenderOverlay() call
    // from here on. This only has to wait out the ONE render already in
    // flight — the very call whose Eject click spawned this thread — which
    // g_inRender tracks precisely. A flat Sleep() here raced this: the
    // in-flight call could still be touching g_pDevice/g_pContext/ImGui
    // right as EjectThread destroyed them on another thread.
    for (int guard = 0; guard < 2000 && g_inRender != 0; guard++)
        Sleep(1);
    Sleep(50);   // small grace period for the GPU to finish presenting

    // Render hook stops running after this point, so put any Ini Presets
    // toggle back the way we found it before we stop re-applying it.
    IniPresets::Restore();
    ReleaseGameFeatures();

    // Render hook stops running after this point, so do the final
    // WndProc-unhook / bShowMouseCursor hand-back here on the edge.
    CursorFix::Shutdown(g_hWnd);

    g_lowLevelFatal.Unhook();   // disarm crash guard first (logs swallowed count)
    CrashGuard::Uninstall();
    SpyglassBackground::Release();   // un-root the panel material instance
    Notifications::Clear();

    // Let the game thread (DrawHUD hook, still installed) pull Stalker Vision's
    // material out of the post-process volume and restore the camera flag.
    for (int guard = 0; guard < 500 && (!StalkerVision::IsRestored() || !QuickPickup::IsRestored() || StructureSnap::g_offsetOn || StructureSnap::g_arrowsBlocked); guard++)
        Sleep(1);

    MH_DisableHook(MH_ALL_HOOKS);
    // DrawHUD runs on the game thread: wait out a call already inside our
    // detour, and the background resolver threads, before unloading.
    for (int guard = 0; guard < 2000 && (g_inDrawHud != 0 || g_inProcessEvent != 0 || AutoDupe::s_initBusy != 0 || TransmitterInventoryModule::s_clsBusy != 0 || !BetterInput::IsIdle() || EngineRefs::g_state == 1 || EngineRefs::g_retryBusy); guard++)
        Sleep(1);
    MH_Uninitialize();

    delete Memory;
    Memory = nullptr;

    if (g_bInit)
    {
        ColorFilter::Shutdown();
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
    }

    if (g_pRTV)    { g_pRTV->Release();    g_pRTV    = nullptr; }
    if (g_pContext) { g_pContext->Release(); g_pContext = nullptr; }
    if (g_pDevice)  { g_pDevice->Release();  g_pDevice  = nullptr; }

    Logger::Uninitialize();
    DropInstance();   // detach may never run for a manual map: free the slot here
    FreeLibraryAndExitThread(g_hModule, 0);
}

// ---------------------------------------------------------------------------
// Worker thread
// ---------------------------------------------------------------------------
static DWORD WINAPI MainThread(LPVOID)
{
    g_status = 2;
    Logger::Initialize();
    Sleep(3000);

    // Game SDK (GObjects/GNames/GWorld/ProcessEvent) — signature-scanned, so
    // this works regardless of load order; only the WndProc/SetCursor side
    // of CursorFix depends on it, so a scan failure here is logged and
    // otherwise non-fatal.
    if (CursorFix::InitGameSdk())
        EngineRefs::Start();   // background: every UFunction/font this DLL calls
    g_status = 50; // InitSDK returned (check debug.log for NOT FOUND lines)

    // Dedicated input thread (attaches to ARK's UI thread for valid key state)
    CreateThread(nullptr, 0, InputThread, nullptr, 0, nullptr);
    g_status = 51; // input thread spawned

    void* pPresent = GetSwapChainPresentPtr();
    if (!pPresent) return 0;

    g_status = 5;
    if (MH_Initialize() != MH_OK) return 0;

    // Pattern-scan memory + arm the LowLevelFatal crash guard. Non-fatal if
    // the signatures don't match this engine build — overlay still works.
    Memory = new MemoryManager();
    g_lowLevelFatal.Hook();

    g_status = 6;
    if (MH_CreateHook(pPresent, &hkPresent,
                      reinterpret_cast<void**>(&oPresent)) != MH_OK) return 0;

    CursorFix::CreateHooks();   // SetCursor/SetCursorPos hooks, enabled below

    // AShooterHUD::DrawHUD (armor HUD). Optional: the overlay works without it.
    {
        auto hits = Memory->PatternScan("48 8B C4 55 41 54 41 55 41 56 41 57 48 8D A8 48 F9");
        pDrawHUD = hits.empty() ? nullptr : hits[0];
        if (pDrawHUD && MH_CreateHook(pDrawHUD, &hkDrawHUD, reinterpret_cast<void**>(&oDrawHUD)) == MH_OK)
            Logger::Log("DrawHUD hook at %p", pDrawHUD);
        else
            Logger::Log("DrawHUD hook FAILED (site %p) - armor HUD disabled", pDrawHUD);
    }

    // UWPProfanityCheck_IsTextOK (Chat Bypass). Optional.
    {
        auto hits = Memory->PatternScan(ChatBypass::kSignature);
        if (!hits.empty() && ChatBypass::Create(hits[0]))
            Logger::Log("ChatBypass hook at %p", hits[0]);
        else
            Logger::Log("ChatBypass hook FAILED (%zu matches) - chat bypass disabled", hits.size());
    }

    // UObject::ProcessEvent (Structure Snap). Optional.
    if (UObject::pProcessEvent &&
        MH_CreateHook(reinterpret_cast<void*>(UObject::pProcessEvent), &hkProcessEvent,
                      reinterpret_cast<void**>(&UObject::oProcessEvent)) == MH_OK)
        Logger::Log("ProcessEvent hook at %p", reinterpret_cast<void*>(UObject::pProcessEvent));
    else
        Logger::Log("ProcessEvent hook FAILED - structure snap disabled");
    CrashGuard::Install();


    g_status = 7;
    if (MH_EnableHook(MH_ALL_HOOKS) != MH_OK) return 0;
    DllLog("hooks on - overlay live");

    return 0;
}

// ---------------------------------------------------------------------------
// Single instance: exactly one paidini per game process. A second inject
// (double-clicked loader, double LoadLibrary, stacked manual maps) would
// otherwise install every hook twice and take the game down with it.
// The mutex is taken before anything initializes and released on eject and
// on detach, so eject-then-reinject keeps working.
// ---------------------------------------------------------------------------
static HANDLE g_instanceMutex = nullptr;
static constexpr wchar_t kInstanceMutex[] = L"Local\\paidini-single-instance-9f3c";

static bool TakeInstance()
{
    g_instanceMutex = CreateMutexW(nullptr, TRUE, kInstanceMutex);
    if (!g_instanceMutex || GetLastError() == ERROR_ALREADY_EXISTS)
    {
        if (g_instanceMutex) { ReleaseMutex(g_instanceMutex); CloseHandle(g_instanceMutex); g_instanceMutex = nullptr; }
        return false;
    }
    return true;
}

static void DropInstance()
{
    if (g_instanceMutex) { ReleaseMutex(g_instanceMutex); CloseHandle(g_instanceMutex); g_instanceMutex = nullptr; }
}

// ---------------------------------------------------------------------------
// DllMain
// ---------------------------------------------------------------------------
BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        if (!TakeInstance()) return FALSE;   // already inside: refuse this load
        g_hModule = hModule;
        DisableThreadLibraryCalls(hModule);
        g_status = 1;
        HANDLE h = CreateThread(nullptr, 0, MainThread, nullptr, 0, nullptr);
        if (h) CloseHandle(h);
    }
    else if (reason == DLL_PROCESS_DETACH)
    {
        DropInstance();
    }
    return TRUE;
}
